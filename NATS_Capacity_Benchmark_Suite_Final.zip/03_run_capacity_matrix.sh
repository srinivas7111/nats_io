#!/usr/bin/env bash
# Capacity matrix runner for NATS in Kind/Podman.
# Discovers current resources; never changes Podman/Kubernetes resource limits.
#
# Required: kubectl, podman, jq, nats CLI; existing scripts in same directory.
# Optional JetStream run: set STREAM and SUBJECT_PREFIX.
#
# Example:
#   NATS_URL=nats://localhost:4222 K8S_NAMESPACE=nats \
#     K8S_SELECTOR='app.kubernetes.io/name=nats' ./03_run_capacity_matrix.sh
#
# Tune profiles with comma-separated variables:
#   PUBLISHER_STEPS=1,2,5,10 CONSUMER_STEPS=1,2,5,10
#   MESSAGE_STEPS=10000,25000,50000
#   RUN_CORE=true RUN_JETSTREAM=false
#
# If using kubectl port-forward for client access, establish it separately and
# set NATS_URL to its local endpoint. This script does not alter cluster networking.

set -o pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NATS_URL="${NATS_URL:-nats://localhost:4222}"
K8S_NAMESPACE="${K8S_NAMESPACE:-nats}"
K8S_SELECTOR="${K8S_SELECTOR:-app.kubernetes.io/name=nats}"
K8S_CONTEXT="${K8S_CONTEXT:-}"
LOG_DIR="${LOG_DIR:-./nats-capacity-results}"
PUBLISHER_STEPS="${PUBLISHER_STEPS:-1,2,5,10}"
CONSUMER_STEPS="${CONSUMER_STEPS:-1,2,5,10}"
MESSAGE_STEPS="${MESSAGE_STEPS:-10000,50000}"
SIZE_STEPS="${SIZE_STEPS:-1024}"
RUN_CORE="${RUN_CORE:-true}"
RUN_JETSTREAM="${RUN_JETSTREAM:-false}"
STAGE_TIMEOUT="${STAGE_TIMEOUT:-300}"
WARMUP_SEC="${WARMUP_SEC:-3}"
JS_STREAM="${STREAM:-}"
JS_SUBJECT_PREFIX="${SUBJECT_PREFIX:-bench.capacity}"
RUN_ID="$(date +%Y%m%d-%H%M%S)-$$"

KC=(kubectl)
[[ -n "$K8S_CONTEXT" ]] && KC+=(--context "$K8S_CONTEXT")
KC+=(-n "$K8S_NAMESPACE")

mkdir -p "$LOG_DIR"
RUN_DIR="$LOG_DIR/$RUN_ID"
mkdir -p "$RUN_DIR"
SUMMARY="$RUN_DIR/capacity-summary.csv"
DISCOVERY="$RUN_DIR/environment-discovery.txt"
echo 'stage,test,publishers,consumers,messages,size_bytes,exit_code,started_at,finished_at' > "$SUMMARY"

log() { printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*" | tee -a "$DISCOVERY"; }
die() { echo "ERROR: $*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || die "Required command not found: $1"; }

need kubectl
need podman
need jq
need nats
[[ -x "$DIR/nats-bench-core.sh" ]] || die "Missing $DIR/nats-bench-core.sh"
[[ -x "$DIR/nats-bench-js.sh" ]] || die "Missing $DIR/nats-bench-js.sh"

validate_list() {
  local label="$1" list="$2" item
  IFS=',' read -r -a vals <<< "$list"
  for item in "${vals[@]}"; do
    [[ "$item" =~ ^[0-9]+$ ]] && (( item > 0 )) || die "$label contains invalid positive integer: $item"
  done
}
validate_list PUBLISHER_STEPS "$PUBLISHER_STEPS"
validate_list CONSUMER_STEPS "$CONSUMER_STEPS"
validate_list MESSAGE_STEPS "$MESSAGE_STEPS"
validate_list SIZE_STEPS "$SIZE_STEPS"

snapshot_environment() {
  local label="$1" f="$RUN_DIR/${label}-discovery.txt"
  {
    echo "Timestamp: $(date -Is 2>/dev/null || date)"
    echo "NATS_URL=$NATS_URL"
    echo "Kubernetes namespace=$K8S_NAMESPACE selector=$K8S_SELECTOR"
    echo
    echo '--- Podman host info ---'
    podman info --format json 2>&1 | jq -r '
      "host.arch=\(.host.arch // "unknown")",
      "host.cpus=\(.host.cpus // "unknown")",
      "host.memTotal=\(.host.memTotal // "unknown")",
      "host.os=\(.host.os // "unknown")"
    ' 2>/dev/null || podman info 2>&1
    echo
    echo '--- Kind node containers (detected by name/label) ---'
    local names name inspect
    names=$(podman ps --format '{{.Names}}' 2>/dev/null | grep -E '(^|-)kind-(control-plane|worker)' || true)
    if [[ -z "$names" ]]; then
      echo 'No running Kind node containers matched the standard Kind names.'
    else
      while IFS= read -r name; do
        [[ -z "$name" ]] && continue
        inspect=$(podman inspect "$name" 2>/dev/null) || continue
        jq -r --arg n "$name" '
          .[0] as $x |
          "container=\($n) status=\($x.State.Status // "unknown") " +
          "NanoCpus=\($x.HostConfig.NanoCpus // 0) MemoryBytes=\($x.HostConfig.Memory // 0) " +
          "CpuQuota=\($x.HostConfig.CpuQuota // 0) CpuPeriod=\($x.HostConfig.CpuPeriod // 0)"
        ' <<<"$inspect"
      done <<<"$names"
    fi
    echo
    echo '--- NATS Kubernetes pods and declared resources ---'
    local pods
    pods=$("${KC[@]}" get pods -l "$K8S_SELECTOR" -o json 2>&1) || {
      echo "$pods"
      return
    }
    jq -r '
      .items[] |
      "pod=\(.metadata.name) phase=\(.status.phase // "unknown") node=\(.spec.nodeName // "unknown")",
      (.spec.containers[] |
        "  container=\(.name) requests_cpu=\(.resources.requests.cpu // "unset") requests_memory=\(.resources.requests.memory // "unset") limits_cpu=\(.resources.limits.cpu // "unset") limits_memory=\(.resources.limits.memory // "unset")")
    ' <<<"$pods"
    echo
    echo '--- Kubernetes observed pod usage (requires metrics-server) ---'
    "${KC[@]}" top pods -l "$K8S_SELECTOR" 2>&1 || echo 'kubectl top unavailable; metrics-server may not be installed.'
    echo
    echo '--- NATS server/cluster checks ---'
    nats --server "$NATS_URL" server check connection 2>&1 || nats --server "$NATS_URL" rtt 2>&1 || true
    nats --server "$NATS_URL" server list 2>&1 || true
    nats --server "$NATS_URL" stream ls 2>&1 || true
    echo
    echo '--- Podman container snapshot ---'
    podman stats --no-stream 2>&1 || true
  } > "$f"
  cat "$f" >> "$DISCOVERY"
  log "Environment snapshot saved: $f"
}

record_stage() {
  local stage="$1" test="$2" pub="$3" con="$4" msgs="$5" size="$6" rc="$7" start="$8" finish="$9"
  printf '"%s","%s",%s,%s,%s,%s,%s,"%s","%s"\n' \
    "$stage" "$test" "$pub" "$con" "$msgs" "$size" "$rc" "$start" "$finish" >> "$SUMMARY"
}

run_one() {
  local test="$1" stage="$2" pub="$3" con="$4" msgs="$5" size="$6" subject="$7"
  local start finish rc logfile
  logfile="$RUN_DIR/${stage}-${test}-p${pub}-c${con}-m${msgs}-s${size}.log"
  start=$(date -Is 2>/dev/null || date)
  log "START stage=$stage test=$test publishers=$pub consumers=$con messages=$msgs size=$size"
  snapshot_environment "before-${stage}-${test}"
  if [[ "$test" == core ]]; then
    NATS_URL="$NATS_URL" MESSAGES="$msgs" SIZE="$size" PUBLISHERS="$pub" CONSUMERS="$con" \
      TIMEOUT="$STAGE_TIMEOUT" SUB_WARMUP="$WARMUP_SEC" LOG_DIR="$RUN_DIR/bench-logs" \
      MONITORING=auto "$DIR/nats-bench-core.sh" >"$logfile" 2>&1
    rc=$?
  else
    NATS_URL="$NATS_URL" STREAM="$JS_STREAM" SUBJECT="$subject" MESSAGES="$msgs" SIZE="$size" \
      PUBLISHERS="$pub" CONSUMERS="$con" TIMEOUT="$STAGE_TIMEOUT" \
      LOG_DIR="$RUN_DIR/bench-logs" MONITORING=auto "$DIR/nats-bench-js.sh" >"$logfile" 2>&1
    rc=$?
  fi
  finish=$(date -Is 2>/dev/null || date)
  record_stage "$stage" "$test" "$pub" "$con" "$msgs" "$size" "$rc" "$start" "$finish"
  snapshot_environment "after-${stage}-${test}"
  log "END stage=$stage test=$test exit_code=$rc log=$logfile"
  return 0
}

log "Capacity run ID: $RUN_ID"
log "Output directory: $RUN_DIR"
log "Discovery is dynamic; no CPU/RAM size is assumed or changed."
snapshot_environment initial

# Cartesian product: publisher x consumer x message count x payload size.
stage=0
IFS=',' read -r -a pubs <<< "$PUBLISHER_STEPS"
IFS=',' read -r -a cons <<< "$CONSUMER_STEPS"
IFS=',' read -r -a msgs_list <<< "$MESSAGE_STEPS"
IFS=',' read -r -a sizes <<< "$SIZE_STEPS"

for pub in "${pubs[@]}"; do
  for con in "${cons[@]}"; do
    for msgs in "${msgs_list[@]}"; do
      for size in "${sizes[@]}"; do
        stage=$((stage+1))
        if [[ "$RUN_CORE" == true ]]; then
          run_one core "stage$(printf '%03d' "$stage")" "$pub" "$con" "$msgs" "$size" ""
        fi
        if [[ "$RUN_JETSTREAM" == true ]]; then
          [[ -n "$JS_STREAM" ]] || die "RUN_JETSTREAM=true requires STREAM=<existing dedicated stream>"
          js_subject="${JS_SUBJECT_PREFIX}.${RUN_ID}.s${stage}"
          run_one jetstream "stage$(printf '%03d' "$stage")" "$pub" "$con" "$msgs" "$size" "$js_subject"
        fi
      done
    done
  done
done

log "Capacity matrix completed."
log "Summary CSV: $SUMMARY"
log "Review per-stage before/after discovery snapshots for actual resource consumption."
log "No automatic 'breaking point' is declared from CPU alone; correlate throughput, latency, errors, backlog and resource pressure."
