#!/usr/bin/env bash
# Summarize a capacity runner's stage CSV and benchmark results.
# Usage: ./04_analyze_capacity_results.sh <run-directory>
set -o pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUN_DIR="${1:-}"
[[ -n "$RUN_DIR" && -d "$RUN_DIR" ]] || {
  echo "Usage: $0 <run-directory>" >&2
  exit 2
}
SUMMARY="$RUN_DIR/capacity-summary.csv"
[[ -f "$SUMMARY" ]] || { echo "Missing $SUMMARY" >&2; exit 1; }

if command -v python3 >/dev/null 2>&1; then
python3 - "$RUN_DIR" <<'PY'
import csv, glob, os, sys
run_dir = sys.argv[1]
path = os.path.join(run_dir, "capacity-summary.csv")
rows = list(csv.DictReader(open(path, newline="", encoding="utf-8")))
print("\nCAPACITY MATRIX SUMMARY")
print("=" * 100)
print(f"{'Stage':<12} {'Test':<10} {'Pub':>5} {'Con':>5} {'Messages':>10} {'Size':>8} {'Exit':>6}")
for r in rows:
    print(f"{r['stage']:<12} {r['test']:<10} {r['publishers']:>5} {r['consumers']:>5} "
          f"{r['messages']:>10} {r['size_bytes']:>8} {r['exit_code']:>6}")
failed = [r for r in rows if r.get("exit_code") not in ("0", "")]
passed = [r for r in rows if r.get("exit_code") == "0"]
print("-" * 100)
print(f"Completed stages: {len(rows)} | Exit code 0: {len(passed)} | Non-zero: {len(failed)}")
print("\nBenchmark CSV files:")
for f in glob.glob(os.path.join(run_dir, "bench-logs", "results.csv")):
    print(" -", f)
print("\nInterpretation:")
print("- Exit code 0 means the script's own validation passed; it is not by itself a capacity/SLA certification.")
print("- Compare each stage's before/after discovery snapshots for Podman and Kubernetes resource usage.")
print("- A sustainable limit requires agreed latency/error/backlog thresholds and a sustained-load run.")
PY
else
  echo "python3 not found; showing raw stage CSV:"
  cat "$SUMMARY"
fi
