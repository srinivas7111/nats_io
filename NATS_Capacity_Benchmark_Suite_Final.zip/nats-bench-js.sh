#!/usr/bin/env bash
# JetStream publish/consume benchmark against an EXISTING, dedicated stream.
# The script never creates, edits, purges, or deletes the stream. It creates and
# removes only its temporary pull consumer.
#
# One-time stream example:
#   nats --server nats://lb:4222 stream add BENCH_TEST \
#     --subjects 'bench.js.>' --storage file --replicas 3 \
#     --retention limits --discard old --max-age 24h --max-bytes 5GB --defaults
#
# Run:
#   STREAM=BENCH_TEST SUBJECT=bench.js.run1 ./nats-bench-js.sh
#   STREAM=BENCH_TEST SUBJECT=bench.js.run2 MESSAGES=100000 PUB_MODE=async ./nats-bench-js.sh
#
# IMPORTANT:
# - Use a dedicated stream with no other writers during the test. Sequence delta
#   is the publish acceptance check; concurrent writes invalidate that check.
# - SUBJECT must be an explicit concrete subject covered by a stream filter.
# - CONSUMERS are competing pull clients on ONE consumer (work is shared).
# - Published messages remain in the stream until its configured limits expire them.

set -o pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$DIR/nats-bench-common.sh"

STREAM="${STREAM:-BENCH_TEST}"
SUBJECT="${SUBJECT:-}"
PUB_MODE="${PUB_MODE:-async}"
CONSUMER="bench-${RUN_ID}"
CONSUMER_CREATED=0

on_exit() {
  if [[ "$CONSUMER_CREATED" -eq 1 ]]; then
    if nats "${AUTH[@]}" consumer rm "$STREAM" "$CONSUMER" -f >/dev/null 2>&1; then
      log "Removed temporary consumer $CONSUMER"
    else
      log "WARN: could not remove temporary consumer $CONSUMER; inspect stream consumer list"
    fi
  fi
}
sinfo() { nats "${AUTH[@]}" stream info "$STREAM" -j 2>/dev/null; }

# NATS subject-filter match: '*' matches one token; terminal '>' matches one
# or more remaining tokens.
subject_is_covered() {
  local subject="$1" filter="$2"
  awk -v s="$subject" -v f="$filter" '
    BEGIN {
      ns=split(s,S,"."); nf=split(f,F,".");
      for (i=1; i<=nf; i++) {
        if (F[i]==">") exit (i<nf || ns<i ? 1 : 0);
        if (i>ns) exit 1;
        if (F[i]!="*" && F[i]!=S[i]) exit 1;
      }
      exit (ns==nf ? 0 : 1);
    }'
}

validate_uint_json() {
  local json="$1" filter="$2" value
  value=$(jq -er "$filter | select(type==\"number\" and .>=0 and floor==.)" <<<"$json" 2>/dev/null) || return 1
  [[ "$value" =~ ^[0-9]+$ ]]
}

bench_init js
PUB_LOG="${LOG%.log}-pub.log"
CON_LOG="${LOG%.log}-consume.log"

case "$PUB_MODE" in async|sync|batch) ;; *)
  log "ERROR: PUB_MODE must be async, sync, or batch (got '$PUB_MODE')"; exit 1 ;;
esac
[[ -n "$SUBJECT" ]] || { log "ERROR: set SUBJECT to a concrete subject covered by the stream"; exit 1; }

INFO0=$(sinfo)
if [[ -z "$INFO0" ]] || ! jq -e '.config.name and (.config.subjects|type=="array") and (.state.last_seq|type=="number") and (.state.bytes|type=="number")' >/dev/null 2>&1 <<<"$INFO0"; then
  log "ERROR: stream '$STREAM' not found or returned unexpected JSON. See $LOG"
  exit 1
fi

FILTERS=$(jq -r '.config.subjects[]?' <<<"$INFO0")
COVERED=0
while IFS= read -r filter; do
  [[ -z "$filter" ]] && continue
  if subject_is_covered "$SUBJECT" "$filter"; then COVERED=1; break; fi
done <<<"$FILTERS"
if [[ "$COVERED" -ne 1 ]]; then
  log "ERROR: subject '$SUBJECT' is not covered by any filter on stream '$STREAM': $FILTERS"
  exit 1
fi

SEQ0=$(jq -r '.state.last_seq' <<<"$INFO0")
BYTES0=$(jq -r '.state.bytes' <<<"$INFO0")
log "Stream=$STREAM subject=$SUBJECT filters=[$(echo "$FILTERS" | tr '\n' ' ')] last_seq=$SEQ0 bytes=$BYTES0"
log "Creating temporary pull consumer $CONSUMER"

if ! nats "${AUTH[@]}" consumer add "$STREAM" "$CONSUMER" \
  --pull --ack explicit --deliver new --filter "$SUBJECT" --replay instant \
  --max-pending 5000 --inactive-threshold 15m --defaults >>"$LOG" 2>&1; then
  log "ERROR: consumer creation failed; check CLI version/options and $LOG"
  exit 1
fi
CONSUMER_CREATED=1
start_sampler

log "Publishing $MESSAGES x ${SIZE}B ($PUB_MODE, publishers=$PUBLISHERS)"
T0=$(now)
run_tmo "$TIMEOUT" nats bench js pub "$PUB_MODE" "$SUBJECT" "${AUTH[@]}" \
  --stream "$STREAM" --msgs "$MESSAGES" --size "$SIZE" --clients "$PUBLISHERS" \
  --no-progress >"$PUB_LOG" 2>&1
PUB_RC=$?
T1=$(now)

INFO1=$(sinfo)
if [[ -z "$INFO1" ]] || ! validate_uint_json "$INFO1" '.state.last_seq' || ! validate_uint_json "$INFO1" '.state.bytes'; then
  log "ERROR: unable to validate stream info after publish; response was empty/invalid"
  SEQ1="$SEQ0"; BYTES1="$BYTES0"; INFO_VALID=0
else
  SEQ1=$(jq -r '.state.last_seq' <<<"$INFO1")
  BYTES1=$(jq -r '.state.bytes' <<<"$INFO1")
  INFO_VALID=1
fi
ACKED=$((SEQ1 - SEQ0))
if [[ "$INFO_VALID" -ne 1 ]]; then
  ACK_V="FAIL: post-publish stream info unavailable"
elif [[ "$PUB_RC" -ne 0 ]]; then
  ACK_V="FAIL: publisher rc=$PUB_RC; stream sequence delta=$ACKED"
elif [[ "$ACKED" -eq "$MESSAGES" ]]; then
  ACK_V="PASS: stream sequence advanced by $ACKED"
elif [[ "$ACKED" -lt "$MESSAGES" ]]; then
  ACK_V="FAIL: stream advanced by only $ACKED of $MESSAGES"
else
  ACK_V="FAIL: stream advanced by $ACKED (> $MESSAGES); concurrent writer or unexpected publish count"
fi
log "Publish validation: $ACK_V"

# Only consume when publishing succeeded and the isolated stream sequence check passed.
CON_RC=125
T2=$(now)
if [[ "$ACK_V" == PASS* ]]; then
  run_tmo "$TIMEOUT" nats bench js consume "${AUTH[@]}" \
    --stream "$STREAM" --consumer "$CONSUMER" --msgs "$MESSAGES" \
    --clients "$CONSUMERS" --no-progress >"$CON_LOG" 2>&1
  CON_RC=$?
else
  echo "Skipped because publish validation failed." >"$CON_LOG"
fi
T3=$(now)

# Poll consumer state, rejecting malformed/missing JSON instead of treating it as zero.
CI=""
CI_VALID=0
for attempt in 1 2 3 4 5 6 7 8 9 10; do
  CI=$(nats "${AUTH[@]}" consumer info "$STREAM" "$CONSUMER" -j 2>/dev/null)
  if [[ -n "$CI" ]] && jq -e '
    (.delivered.consumer_seq|type=="number") and
    (.ack_floor.consumer_seq|type=="number") and
    (.num_pending|type=="number") and
    (.num_ack_pending|type=="number")' >/dev/null 2>&1 <<<"$CI"; then
    CI_VALID=1
    DELIV=$(jq -r '.delivered.consumer_seq' <<<"$CI")
    ACKF=$(jq -r '.ack_floor.consumer_seq' <<<"$CI")
    PEND=$(jq -r '.num_pending' <<<"$CI")
    APEND=$(jq -r '.num_ack_pending' <<<"$CI")
    [[ "$ACKF" -eq "$MESSAGES" && "$PEND" -eq 0 && "$APEND" -eq 0 ]] && break
  fi
  sleep 1
done

if [[ "$ACK_V" != PASS* ]]; then
  DEL_V="SKIPPED: publish validation failed"
elif [[ "$CI_VALID" -ne 1 ]]; then
  DEL_V="FAIL: consumer info missing or malformed"
elif is_timeout "$CON_RC"; then
  DEL_V="FAIL: consume timed out after ${TIMEOUT}s (delivered=$DELIV ack_floor=$ACKF pending=$PEND ack_pending=$APEND)"
elif [[ "$CON_RC" -ne 0 ]]; then
  DEL_V="FAIL: consume command rc=$CON_RC (delivered=$DELIV ack_floor=$ACKF pending=$PEND ack_pending=$APEND)"
elif [[ "$DELIV" -eq "$MESSAGES" && "$ACKF" -eq "$MESSAGES" && "$PEND" -eq 0 && "$APEND" -eq 0 ]]; then
  DEL_V="PASS: delivered=$DELIV ack_floor=$ACKF pending=0 ack_pending=0"
else
  DEL_V="FAIL: delivered=$DELIV ack_floor=$ACKF pending=$PEND ack_pending=$APEND; expected $MESSAGES/$MESSAGES/0/0"
fi
log "Delivery validation: $DEL_V"

sampler_report
PUB_SEC=$(elapsed "$T0" "$T1")
CON_SEC=$(elapsed "$T2" "$T3")
E2E_SEC=$(elapsed "$T0" "$T3")
PUB_RATE=$(rate "$MESSAGES" "$PUB_SEC")
CON_RATE=$(rate "$MESSAGES" "$CON_SEC")
GROWTH=$((BYTES1 - BYTES0))
GROWTH_KB=$(awk -v b="$GROWTH" 'BEGIN{printf "%.1f",b/1024}')

{
  echo
  echo '================ JETSTREAM RESULT ================'
  echo "Server            : $NATS_URL"
  echo "Stream / subject  : $STREAM / $SUBJECT"
  echo "Messages / size   : $MESSAGES x ${SIZE}B (publishers=$PUBLISHERS [$PUB_MODE], pull clients=$CONSUMERS)"
  echo "Publish            : ${PUB_SEC}s, ${PUB_RATE} msgs/s"
  echo "Consume + ACK      : ${CON_SEC}s, ${CON_RATE} msgs/s"
  echo "Logical byte delta : ${GROWTH_KB} KiB (not physical replicated disk usage)"
  echo "Publish validation : $ACK_V"
  echo "Consume validation : $DEL_V"
  echo 'CLI summary        :'
  grep -Ehi 'msgs/sec|MiB/sec|MB/sec|min/avg/max|messages|received' "$PUB_LOG" "$CON_LOG" 2>/dev/null | tail -10 | sed 's/^/  /'
  echo "Logs               : $LOG $PUB_LOG $CON_LOG"
  echo 'Note               : messages remain in the stream under its own retention/size limits.'
  echo '==================================================='
} | tee -a "$LOG"

if [[ "$ACK_V" == PASS* && "$DEL_V" == PASS* ]]; then VERDICT="PASS"
else VERDICT="FAIL: publish=[$ACK_V]; consume=[$DEL_V]"; fi
record_result "$PUB_RATE" "$CON_RATE" "$VERDICT"
[[ "$VERDICT" == PASS ]]
