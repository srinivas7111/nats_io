#!/usr/bin/env bash
# Core NATS pub/sub benchmark. No persistence, ACK, replay, or durable cursor.
# Core subscribers on the same subject each receive a copy (fan-out).
#
# Usage:
#   NATS_URL=nats://localhost:4222 ./nats-bench-core.sh
#   MESSAGES=100000 PUBLISHERS=4 CONSUMERS=3 SIZE=1024 ./nats-bench-core.sh
#
# Optional: SUBJECT, SUB_WARMUP (default 3s), TIMEOUT, LOG_DIR, credentials,
# MON_URLS or K8S_* for optional monitoring. Set MONITORING=off to disable it.

set -o pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$DIR/nats-bench-common.sh"

SUBJECT="${SUBJECT:-bench.core.$RUN_ID}"
SUB_WARMUP="${SUB_WARMUP:-3}"

bench_init core
PUB_LOG="${LOG%.log}-pub.log"
SUB_LOG="${LOG%.log}-sub.log"
start_sampler

log "Starting $CONSUMERS Core subscriber client(s) on '$SUBJECT'"
run_tmo "$TIMEOUT" nats bench sub "$SUBJECT" "${AUTH[@]}" \
  --msgs "$MESSAGES" --clients "$CONSUMERS" --no-progress >"$SUB_LOG" 2>&1 &
SUB_PID=$!
BG_PIDS+=("$SUB_PID")

# The CLI has no portable readiness signal across versions; allow a configurable
# warm-up, then ensure the subscriber process has not already exited.
sleep "$SUB_WARMUP"
if ! kill -0 "$SUB_PID" 2>/dev/null; then
  wait "$SUB_PID"; SUB_RC=$?
  sampler_report
  log "ERROR: subscriber exited during startup (rc=$SUB_RC); see $SUB_LOG"
  record_result 0 0 "FAIL: subscriber startup rc=$SUB_RC"
  exit 1
fi

log "Publishing $MESSAGES messages of ${SIZE}B with $PUBLISHERS publisher client(s)"
T0=$(now)
run_tmo "$TIMEOUT" nats bench pub "$SUBJECT" "${AUTH[@]}" \
  --msgs "$MESSAGES" --size "$SIZE" --clients "$PUBLISHERS" --no-progress >"$PUB_LOG" 2>&1
PUB_RC=$?
T1=$(now)

if [[ "$PUB_RC" -ne 0 ]]; then
  log "Publisher failed/timed out (rc=$PUB_RC); stopping subscriber wait."
  kill "$SUB_PID" 2>/dev/null
fi
wait "$SUB_PID"; SUB_RC=$?
T2=$(now)

sampler_report
PUB_SEC=$(elapsed "$T0" "$T1")
E2E_SEC=$(elapsed "$T0" "$T2")
PUB_RATE=$(rate "$MESSAGES" "$PUB_SEC")

# NATS bench sub --clients starts independent subscribers. Each receives the
# full publication set, so expected aggregate deliveries = MESSAGES * CONSUMERS.
EXPECTED=$((MESSAGES * CONSUMERS))
E2E_RATE=$(rate "$EXPECTED" "$E2E_SEC")

if [[ "$PUB_RC" -ne 0 ]]; then
  VERDICT="FAIL: publisher rc=$PUB_RC"
elif is_timeout "$SUB_RC"; then
  VERDICT="FAIL: subscriber timed out after ${TIMEOUT}s"
elif [[ "$SUB_RC" -ne 0 ]]; then
  VERDICT="FAIL: subscriber rc=$SUB_RC"
else
  VERDICT="PASS: subscriber command completed; verify CLI summary reports expected fan-out ($EXPECTED deliveries)"
fi

{
  echo
  echo '================ CORE NATS RESULT ================'
  echo "Server            : $NATS_URL"
  echo "Subject           : $SUBJECT"
  echo "Publish           : $MESSAGES messages, $PUBLISHERS publisher(s), ${PUB_SEC}s, ${PUB_RATE} msgs/s"
  echo "Subscribers       : $CONSUMERS independent subscriber(s), expected aggregate deliveries=$EXPECTED"
  echo "End-to-end rate   : ${E2E_RATE} deliveries/s (wall-clock; includes subscriber startup)"
  echo "Publisher status  : rc=$PUB_RC"
  echo "Subscriber status : rc=$SUB_RC"
  echo "Validation        : $VERDICT"
  echo 'CLI summary       :'
  grep -Ehi 'msgs/sec|MiB/sec|MB/sec|min/avg/max|received|messages' "$PUB_LOG" "$SUB_LOG" 2>/dev/null | tail -10 | sed 's/^/  /'
  echo "Logs              : $LOG $PUB_LOG $SUB_LOG"
  echo 'Semantics         : Core NATS is at-most-once; no persistence or replay.'
  echo '==================================================='
} | tee -a "$LOG"

record_result "$PUB_RATE" "$E2E_RATE" "$VERDICT"
[[ "$VERDICT" == PASS* ]]
