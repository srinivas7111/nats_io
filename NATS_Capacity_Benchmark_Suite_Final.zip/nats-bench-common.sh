#!/usr/bin/env bash
# Shared helpers. Bash 3.2+ compatible (macOS/Linux).
# Optional resource sampling: MON_URLS=http://node1:8222,http://node2:8222
# or kubectl port-forward via K8S_NAMESPACE/K8S_SELECTOR.

NATS_URL="${NATS_URL:-nats://localhost:4222}"
MESSAGES="${MESSAGES:-1000}"
SIZE="${SIZE:-1024}"
PUBLISHERS="${PUBLISHERS:-1}"
CONSUMERS="${CONSUMERS:-1}"
TIMEOUT="${TIMEOUT:-120}"
LOG_DIR="${LOG_DIR:-./nats-bench-logs}"
SAMPLE_SEC="${SAMPLE_SEC:-2}"
K8S_NAMESPACE="${K8S_NAMESPACE:-nats}"
K8S_SELECTOR="${K8S_SELECTOR:-app.kubernetes.io/name=nats}"
RUN_ID="$(date +%Y%m%d-%H%M%S)-$$"

AUTH=(--server "$NATS_URL")
[[ -n "${NATS_USER:-}" ]] && AUTH+=(--user "$NATS_USER" --password "${NATS_PASS:-}")
[[ -n "${NATS_CREDS:-}" ]] && AUTH+=(--creds "$NATS_CREDS")
[[ -n "${NATS_TOKEN:-}" ]] && AUTH+=(--token "$NATS_TOKEN")

KC=(kubectl)
[[ -n "${K8S_CONTEXT:-}" ]] && KC+=(--context "$K8S_CONTEXT")
KC+=(-n "$K8S_NAMESPACE")

BG_PIDS=()
MON=()
SAMPLER_PID=""
MONITORING="${MONITORING:-auto}" # auto | off

log() { printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*" | tee -a "$LOG"; }

now() {
  local t
  t=$(date +%s.%N 2>/dev/null)
  if [[ -z "$t" || "$t" == *N* ]]; then
    if command -v python3 >/dev/null 2>&1; then
      python3 -c 'import time; print("%.6f" % time.time())'
    else
      perl -MTime::HiRes=time -e 'printf "%.6f\n", time'
    fi
  else
    echo "$t"
  fi
}
elapsed() { awk -v a="$1" -v b="$2" 'BEGIN{printf "%.3f", b-a}'; }
rate() { awk -v n="$1" -v t="$2" 'BEGIN{if(t>0) printf "%.0f",n/t; else print 0}'; }
mbps() { awk -v n="$1" -v s="$2" -v t="$3" 'BEGIN{if(t>0) printf "%.2f",n*s/1048576/t; else print 0}'; }
is_timeout() { [[ "$1" == 124 || "$1" == 137 || "$1" == 142 ]]; }

run_tmo() {
  local secs="$1"; shift
  if command -v timeout >/dev/null 2>&1; then
    timeout "$secs" "$@"
  elif command -v gtimeout >/dev/null 2>&1; then
    gtimeout "$secs" "$@"
  elif command -v python3 >/dev/null 2>&1; then
    python3 -c 'import subprocess,sys
try:
    result = subprocess.run(sys.argv[2:], timeout=float(sys.argv[1]), check=False)
    sys.exit(result.returncode)
except subprocess.TimeoutExpired:
    sys.exit(124)' "$secs" "$@"
  else
    echo "ERROR: install timeout/gtimeout or python3 for bounded commands" >&2
    return 125
  fi
}

bench_init() {
  BENCH_NAME="$1"
  local c
  for c in nats awk; do
    command -v "$c" >/dev/null 2>&1 || { echo "Missing dependency: $c" >&2; exit 1; }
  done
  if [[ "$MONITORING" != "off" ]]; then
    command -v jq >/dev/null 2>&1 || { echo "Missing dependency: jq (or set MONITORING=off)" >&2; exit 1; }
    command -v curl >/dev/null 2>&1 || { echo "Missing dependency: curl (or set MONITORING=off)" >&2; exit 1; }
  fi
  mkdir -p "$LOG_DIR" || exit 1
  LOG="$LOG_DIR/${BENCH_NAME}-${RUN_ID}.log"
  SAMPLES="$LOG_DIR/${BENCH_NAME}-${RUN_ID}-resources.csv"
  RESULTS="$LOG_DIR/results.csv"
  : > "$LOG"
  trap 'exit 130' INT
  trap 'exit 143' TERM
  trap bench_exit EXIT

  validate_positive_int MESSAGES "$MESSAGES"
  validate_positive_int SIZE "$SIZE"
  validate_positive_int PUBLISHERS "$PUBLISHERS"
  validate_positive_int CONSUMERS "$CONSUMERS"
  validate_positive_int TIMEOUT "$TIMEOUT"

  log "[$BENCH_NAME] server=$NATS_URL messages=$MESSAGES size=${SIZE}B publishers=$PUBLISHERS consumers=$CONSUMERS"
  log "Log: $LOG"
  if ! nats "${AUTH[@]}" rtt >>"$LOG" 2>&1; then
    log "ERROR: cannot connect to $NATS_URL; inspect $LOG"
    exit 1
  fi
  setup_monitoring
}

validate_positive_int() {
  local label="$1" value="$2"
  [[ "$value" =~ ^[0-9]+$ ]] && (( value > 0 )) || {
    echo "ERROR: $label must be a positive integer; got '$value'" >&2
    exit 1
  }
}

bench_exit() {
  trap - EXIT INT TERM
  if declare -F on_exit >/dev/null 2>&1; then on_exit; fi
  stop_sampler
  local p
  for p in "${BG_PIDS[@]}"; do
    [[ -n "$p" ]] && kill "$p" 2>/dev/null
  done
}

record_result() {
  local pub="$1" consume="$2" verdict="$3"
  if [[ ! -f "$RESULTS" ]]; then
    echo 'timestamp,test,messages,size_bytes,publishers,consumers,publish_msgs_per_sec,consume_or_e2e_msgs_per_sec,validation,log' > "$RESULTS"
  fi
  # CSV-quote text fields.
  local stamp; stamp=$(date +%FT%T)
  printf '"%s","%s",%s,%s,%s,%s,%s,%s,"%s","%s"\n' \
    "$stamp" "$BENCH_NAME" "$MESSAGES" "$SIZE" "$PUBLISHERS" "$CONSUMERS" \
    "$pub" "$consume" "${verdict//\"/\"\"}" "${LOG//\"/\"\"}" >> "$RESULTS"
}

setup_monitoring() {
  MON=()
  [[ "$MONITORING" == "off" ]] && { log "Resource sampling disabled"; return; }

  if [[ -n "${MON_URLS:-}" ]]; then
    local i=0 u oldifs="$IFS"
    IFS=','
    for u in $MON_URLS; do
      [[ -n "$u" ]] && MON+=("node$i|${u%/}")
      i=$((i+1))
    done
    IFS="$oldifs"
  elif command -v kubectl >/dev/null 2>&1 && "${KC[@]}" get pods -l "$K8S_SELECTOR" >/dev/null 2>&1; then
    local port=18222 p
    while read -r p; do
      [[ -z "$p" ]] && continue
      "${KC[@]}" port-forward "pod/$p" "$port:8222" >/dev/null 2>&1 &
      BG_PIDS+=("$!")
      MON+=("$p|http://127.0.0.1:$port")
      port=$((port+1))
    done < <("${KC[@]}" get pods -l "$K8S_SELECTOR" -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}')
    # Probe readiness rather than assuming port-forward is ready after a fixed sleep.
    local attempt ready
    for e in "${MON[@]}"; do
      url=${e#*|}; ready=0
      for attempt in 1 2 3 4 5 6 7 8 9 10; do
        if curl -fsS --max-time 1 "$url/varz" >/dev/null 2>&1; then ready=1; break; fi
        sleep 1
      done
      [[ "$ready" -eq 1 ]] || log "WARN: monitoring endpoint not ready: $url"
    done
  fi

  if [[ ${#MON[@]} -gt 0 ]]; then
    log "Resource sampling configured for ${#MON[@]} node(s)"
  else
    log "Resource sampling off (set MON_URLS or configure kubectl selector)"
  fi
}

sample_once() {
  local phase="$1" e name url v j cpu rss conns inm outm store mem
  for e in "${MON[@]}"; do
    name=${e%%|*}; url=${e#*|}
    v=$(curl -fsS --max-time 2 "$url/varz" 2>/dev/null) || continue
    j=$(curl -fsS --max-time 2 "$url/jsz" 2>/dev/null) || j='{}'
    jq -e 'type=="object"' >/dev/null 2>&1 <<<"$v" || continue
    jq -e 'type=="object"' >/dev/null 2>&1 <<<"$j" || j='{}'
    cpu=$(jq -r '.cpu // 0' <<<"$v")
    rss=$(jq -r '((.mem // 0)/1048576)|floor' <<<"$v")
    conns=$(jq -r '.connections // 0' <<<"$v")
    inm=$(jq -r '.in_msgs // 0' <<<"$v")
    outm=$(jq -r '.out_msgs // 0' <<<"$v")
    store=$(jq -r '((.storage // 0)/1048576)|floor' <<<"$j")
    mem=$(jq -r '((.memory // 0)/1048576)|floor' <<<"$j")
    printf '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n' \
      "$(date +%s)" "$phase" "$name" "$cpu" "$rss" "$conns" "$inm" "$outm" "$store" "$mem" >> "$SAMPLES"
  done
}

start_sampler() {
  [[ ${#MON[@]} -eq 0 ]] && return
  echo 'ts,phase,node,cpu_pct,rss_mb,conns,in_msgs,out_msgs,js_store_mb,js_mem_mb' > "$SAMPLES"
  sample_once before
  ( while :; do sleep "$SAMPLE_SEC"; sample_once during; done ) &
  SAMPLER_PID=$!
}

stop_sampler() {
  if [[ -n "$SAMPLER_PID" ]]; then
    kill "$SAMPLER_PID" 2>/dev/null
    wait "$SAMPLER_PID" 2>/dev/null
    SAMPLER_PID=""
  fi
}

sampler_report() {
  stop_sampler
  [[ ${#MON[@]} -eq 0 ]] && return
  sample_once after
  log "Resource samples: $SAMPLES (CPU is NATS-reported percentage; RSS/store values are MiB)"
  awk -F, 'NR>1 {
      n=$3; if (!(n in first)) {first[n]=$7; firsts[n]=$9}
      last[n]=$7; lasts[n]=$9
      if ($4+0>cpu[n]) cpu[n]=$4+0
      if ($5+0>rss[n]) rss[n]=$5+0
    }
    END {
      printf "%-28s %10s %10s %14s %16s\n","node","peak_cpu%","peak_rssMB","in_msgs_delta","js_store_delta"
      for (n in first) printf "%-28s %10.1f %10d %14d %16d\n",n,cpu[n],rss[n],last[n]-first[n],lasts[n]-firsts[n]
    }' "$SAMPLES" | tee -a "$LOG"
  log "For stable resource measurements, use a longer run (typically MESSAGES=100000 or more)."
}
