# NATS Capacity Benchmark Suite — Runbook

This suite benchmarks an existing NATS deployment running in Kubernetes/Kind on Podman.
It discovers the current environment at runtime. It does **not** resize Podman containers,
change Kubernetes resource requests/limits, create/delete NATS servers, or purge streams.

## 1. Files

| File | Purpose |
|---|---|
| `nats-bench-common.sh` | Shared logging, timeout, resource sampling and CSV helpers |
| `nats-bench-core.sh` | Core NATS publish/subscriber benchmark |
| `nats-bench-js.sh` | JetStream publish/consume/ACK benchmark |
| `03_run_capacity_matrix.sh` | Environment discovery and configurable load matrix |
| `04_analyze_capacity_results.sh` | Summarises a completed run |
| `README.md` | This runbook |

## 2. Prerequisites

Run from a terminal where the existing Kind/Podman environment is accessible.

Required commands:
- `bash` (Bash 3.2 or newer)
- `podman`
- `kubectl` configured for the target Kind cluster
- `nats` CLI
- `jq`
- `awk`
- `curl`
- `timeout` or `gtimeout`, or Python 3 for command timeouts

`kubectl top` additionally requires metrics-server. The suite reports when it is unavailable.
The NATS monitoring endpoint (usually port 8222) is needed for per-node `/varz` and `/jsz`
sampling. If it is not reachable from the host, configure `MON_URLS` or use the available
monitoring/port-forward arrangement.

Check tools and context before running:

```bash
podman version
kubectl config current-context
kubectl get nodes
nats --version
jq --version
```

Check the actual NATS CLI commands/options available in your installed version:

```bash
nats bench pub --help
nats bench sub --help
nats bench js pub --help
nats bench js consume --help
nats consumer add --help
```

The benchmark scripts use NATS CLI options that must be supported by your installed CLI.
If an option is not supported, do not start the matrix; reconcile the command with that
CLI version first.

## 3. Extract and prepare

Extract the ZIP, change into the extracted directory, and make scripts executable:

```bash
unzip NATS_Capacity_Benchmark_Suite_Final.zip -d nats-capacity-suite
cd nats-capacity-suite
chmod +x *.sh
```

## 4. Configure the environment

Set the NATS endpoint and Kubernetes selector to match your deployment:

```bash
export NATS_URL=nats://localhost:4222
export K8S_NAMESPACE=nats
export K8S_SELECTOR='app.kubernetes.io/name=nats'
```

If your NATS pods use a different namespace or label selector, change these values.
The selector must match the NATS server pods, not the Kind node containers.

For a non-default Kubernetes context:

```bash
export K8S_CONTEXT=<your-kind-context>
```

Authentication (choose the method used by your cluster):

```bash
# Username/password
export NATS_USER=<username>
export NATS_PASS=<password>

# OR credentials file
# export NATS_CREDS=/path/to/user.creds

# OR token
# export NATS_TOKEN=<token>
```

Do not put real credentials into shared logs or source control.

## 5. Run Core NATS capacity matrix

Start with a small matrix to verify connectivity and script compatibility:

```bash
export RUN_CORE=true
export RUN_JETSTREAM=false

export PUBLISHER_STEPS=1,2
export CONSUMER_STEPS=1,2
export MESSAGE_STEPS=10000
export SIZE_STEPS=1024

./03_run_capacity_matrix.sh
```

After the smoke run succeeds, increase the matrix gradually:

```bash
export PUBLISHER_STEPS=1,2,5,10
export CONSUMER_STEPS=1,2,5,10
export MESSAGE_STEPS=10000,50000
export SIZE_STEPS=1024,5120

./03_run_capacity_matrix.sh
```

The runner executes the Cartesian product of the configured values. For example,
4 publisher levels × 4 consumer levels × 2 message counts × 2 payload sizes gives
64 Core NATS stages. Start with fewer combinations and expand deliberately.

Core NATS subscribers are independent fan-out subscribers: each subscriber receives
a copy of each published message.

## 6. Run JetStream capacity matrix

Use an existing dedicated benchmark stream. Do not use a production stream or a stream
with concurrent publishers, because the benchmark validates publish acceptance using
the stream sequence delta.

Example stream creation (run once, only if you are authorised to create it):

```bash
nats --server "$NATS_URL" stream add BENCH_TEST \
  --subjects 'bench.capacity.>' \
  --storage file \
  --replicas 1 \
  --retention limits \
  --discard old \
  --max-age 24h \
  --max-bytes 1GB \
  --defaults
```

For the local Kind/Podman environment, use the replica count supported by your current
cluster. Do not assume a three-replica configuration if fewer NATS nodes are running.

Enable JetStream in the matrix:

```bash
export RUN_CORE=false
export RUN_JETSTREAM=true
export STREAM=BENCH_TEST
export SUBJECT_PREFIX=bench.capacity

export PUBLISHER_STEPS=1,2
export CONSUMER_STEPS=1,2
export MESSAGE_STEPS=10000
export SIZE_STEPS=1024

./03_run_capacity_matrix.sh
```

The runner generates a unique concrete subject per JetStream stage. The stream's subject
filter must cover that prefix (for example `bench.capacity.>`). The JetStream benchmark
creates and removes only its temporary consumer. It does not purge or delete the stream.
Messages remain subject to the stream's configured retention and size limits.

For a combined run, set both `RUN_CORE=true` and `RUN_JETSTREAM=true`. For clearer
comparison and less interference, separate Core and JetStream runs are recommended.

## 7. Analyse a completed run

The matrix runner prints the output directory at completion. It is normally:

```text
./nats-capacity-results/<run-id>/
```

Pass that exact directory to the analyzer:

```bash
./04_analyze_capacity_results.sh ./nats-capacity-results/<run-id>
```

Important output:
- `capacity-summary.csv`: stage-by-stage exit status and workload settings
- `environment-discovery.txt`: initial environment discovery
- `*-discovery.txt`: before/after resource snapshots for each stage
- `bench-logs/`: detailed benchmark logs and per-benchmark CSV results

## 8. How to determine the breaking point

Do not define the breaking point by CPU alone. Mark a stage as unsustainable when one or
more agreed service objectives are breached, for example:
- publish or consume throughput no longer reaches the offered target;
- p95/p99 latency exceeds the agreed limit or rises sharply between stages;
- publish/consume errors or timeouts appear;
- JetStream pending/ACK-pending backlog grows and does not drain;
- CPU remains saturated, memory pressure/OOM occurs, or disk/network becomes constrained;
- the system does not recover after load is reduced.

Run a sustained-load test at the highest apparently sustainable stage (for example
15–30 minutes), then repeat it. Use the highest repeatable sustainable result—not a
short burst—as the capacity baseline. Apply an explicit headroom margin before turning
that result into production resource requirements.

## 9. Measurement limitations

- Environment discovery reports Podman host details, matching Kind node container limits,
  Kubernetes NATS pod requests/limits, `kubectl top` when available, and Podman stats.
- Podman host capacity, Kind node container limits and Kubernetes pod limits are different
  layers. Interpret them separately; do not add them together as if they were independent.
- The runner takes before/after Podman stats snapshots. These are not a continuous
  per-second time series.
- NATS `/varz` and `/jsz` sampling is optional and depends on reachable monitoring endpoints.
- p95/p99 latency histograms are not yet produced by these shell scripts. Do not claim
  latency-percentile validation from the current CSV output.
- The analyzer summarises stage exit codes; it does not automatically certify a production
  capacity or calculate a reliable breaking point without defined latency/error/backlog
  objectives and sustained-load evidence.
- Shell syntax has been checked with `bash -n`. A live end-to-end run against your cluster
  is still required to validate connectivity, CLI option compatibility and runtime behavior.

## 10. Safe execution recommendations

1. Start with the small smoke matrix.
2. Confirm the selected Kubernetes namespace and label selector match only NATS pods.
3. Confirm the JetStream stream is dedicated and its filter matches the benchmark subject.
4. Avoid running other load tests or publishing to the same JetStream benchmark stream.
5. Watch Podman and Kubernetes resource usage during the run.
6. Stop the test if the local machine becomes unresponsive or the cluster is unstable.
7. Keep the run directory so results can be compared across different resource allocations.
