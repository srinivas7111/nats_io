#!/usr/bin/env bash
# CLI-only workload helpers for temporary use until Java clients are available.
# Source after lib.sh. No consumer/business side effects are claimed by these helpers.

workload_stream_state() {
  local label="$1" file="$REPORT_DIR/workload-${label}-stream.json"
  if ! nats_cli stream info "$STREAM" --json >"$file" 2>"${file%.json}.err"; then
    fail "Unable to capture stream state ($label)"; return 1
  fi
  python3 - "$file" "$label" <<'PY'
import json,sys
j=json.load(open(sys.argv[1])); s=j.get('state') or {}; c=j.get('cluster') or {}
r=c.get('replicas') or []
print(f"{sys.argv[2]}: messages={s.get('messages','?')} last_seq={s.get('last_seq','?')} leader={c.get('leader','?')} replicas_current={sum(x.get('current') is True for x in r)}/{len(r)}")
PY
}

# Publishes using the NATS CLI JetStream publish mode and parses the PubAck.
# A successful core NATS publish alone is not accepted as publish-verification evidence.
workload_publish() {
  local phase="${1:-normal}" expect="${2:-success}" event_id payload output_file ack_file rc=0
  if [[ -n "${EVENT_ID:-}" ]]; then
    event_id="${EVENT_ID}-${phase}"
  else
    event_id="${RUN_ID}-${phase}-$(date +%s)-${RANDOM}"
  fi
  payload="$(python3 - "$event_id" "$phase" <<'PY'
import json,sys
print(json.dumps({'eventId':sys.argv[1],'paymentId':'PAY-'+sys.argv[1][-16:],'type':'payment.created','phase':sys.argv[2],'amount':1250.75,'currency':'INR','status':'CREATED','createdAt':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'source':'cli-resilience-demo'},separators=(',',':')))
PY
)"
  output_file="$REPORT_DIR/workload-${phase}-publish.out"
  ack_file="$REPORT_DIR/workload-${phase}-ack.json"
  printf '%s\n' "$payload" >"$REPORT_DIR/workload-${phase}-payload.json"
  info "CLI workload: phase=$phase eventId=$event_id expected=$expect"

  # JetStream-aware publish; a core NATS publish is not sufficient evidence.
  # NATS CLI versions may use --js or --jetstream; override via NATS_JS_FLAG if needed.
  local js_flag="${NATS_JS_FLAG:---js}"
  if nats_cli pub "$js_flag" "$SUBJECT" "$payload" >"$output_file" 2>"$REPORT_DIR/workload-${phase}-publish.err"; then
    if python3 - "$output_file" "$ack_file" "$STREAM" <<'PYACK'
import json,re,sys
text=open(sys.argv[1],errors='replace').read(); expected=sys.argv[3]; obj=None
for line in text.splitlines():
 line=line.strip(); candidates=[line]
 if '{' in line: candidates.append(line[line.find('{'):])
 for candidate in candidates:
  try:
   x=json.loads(candidate)
   if isinstance(x,dict) and ('stream' in x or 'seq' in x or 'error' in x): obj=x; break
  except Exception: pass
 if obj is not None: break
if obj is not None:
 stream=obj.get('stream') or obj.get('stream_name'); seq=obj.get('seq') or obj.get('sequence')
 if not obj.get('error') and stream==expected and isinstance(seq,int):
  json.dump({'stream':stream,'seq':seq,'duplicate':obj.get('duplicate',False)},open(sys.argv[2],'w'),indent=2)
  print('JetStream PubAck: stream=%s seq=%s' % (stream,seq)); sys.exit(0)
# NATS CLI often prints a text acknowledgement, e.g. Published to stream "X" with sequence N.
patterns=[r"Published to stream ['\"]([^'\"]+)['\"] with sequence (\d+)",
          r"stream[=: ]+['\"]?([A-Za-z0-9_-]+)['\"]?.*?(?:sequence|seq)[=: ]+(\d+)"]
for pat in patterns:
 m=re.search(pat,text,re.I|re.S)
 if m and m.group(1)==expected:
  stream,seq=m.group(1),int(m.group(2))
  json.dump({'stream':stream,'seq':seq,'duplicate':False,'ack_format':'text'},open(sys.argv[2],'w'),indent=2)
  print('JetStream PubAck: stream=%s seq=%s (parsed CLI text)' % (stream,seq)); sys.exit(0)
sys.exit(1)
PYACK
    then
      if [[ "$expect" == success ]]; then pass "JetStream acknowledged event ($phase)"; return 0; fi
      fail "Unexpected publish success during $phase (expected failure)"; return 1
    fi
    if [[ "$expect" == failure ]]; then
      pass "No valid JetStream PubAck was observed during $phase (expected unavailable)"
      return 0
    fi
    fail "Publish command returned but a valid JetStream PubAck could not be parsed ($phase); inspect $output_file"
    return 1
  else
    rc=$?
    if [[ "$expect" == failure ]]; then pass "JetStream publish unavailable during $phase as expected (exit=$rc)"; return 0; fi
    fail "JetStream publish failed during $phase (exit=$rc)"; return 1
  fi
}

# Backward-compatible name used by scenario scripts.
workload_consumer_state() { workload_consumer_checkpoint "$@"; }

workload_consumer_checkpoint() {
  local durable="$1" phase="$2" dest="$REPORT_DIR/consumer-${durable}-${phase}.json"
  if ! nats_cli consumer info "$STREAM" "$durable" --json >"$dest" 2>"${dest%.json}.err"; then
    inconclusive "Cannot inspect $durable ($phase): durable not provisioned or unavailable"
    return 1
  fi
  python3 - "$dest" "$durable" "$phase" <<'PYCON'
import json,sys
j=json.load(open(sys.argv[1])); d=j.get('delivered') or {}; a=j.get('ack_floor') or {}
print(f"CONSUMER {sys.argv[2]} [{sys.argv[3]}]: delivered={d.get('stream_seq','?')} ack_floor={a.get('stream_seq','?')} pending={j.get('num_pending','?')} ack_pending={j.get('num_ack_pending','?')} redelivered={j.get('num_redelivered','?')}")
PYCON
}

# Verify a durable consumer's ACK floor did not regress. Does not claim delivery.
workload_consumer_nonregression() {
  local durable="$1" before="$2" after="$3"
  python3 - "$REPORT_DIR/consumer-${durable}-${before}.json" "$REPORT_DIR/consumer-${durable}-${after}.json" <<'PYCON'
import json,sys
try:
 b=json.load(open(sys.argv[1])); a=json.load(open(sys.argv[2]))
 for key in ('delivered','ack_floor'):
  x=(b.get(key) or {}).get('stream_seq'); y=(a.get(key) or {}).get('stream_seq')
  if not isinstance(x,int) or not isinstance(y,int) or y<x: raise ValueError(f'{key} unavailable or regressed: {x} -> {y}')
 print('Consumer cursor did not regress (not proof of processing)')
except Exception as e:
 print('Consumer cursor comparison failed:',e); sys.exit(1)
PYCON
}

# Publish a specified number of unique marker events; failure propagates.
workload_publish_batch() {
  local phase="$1" count="$2" i
  [[ "$count" =~ ^[1-9][0-9]*$ ]] || { fail 'Invalid publish batch count'; return 1; }
  for ((i=1;i<=count;i++)); do
    workload_publish "${phase}-${i}" success || return 1
  done
}

# Wait for the configured RF=3 stream to report both follower replicas current.
# This validates replication catch-up only; it does not prove application processing.
workload_replica_wait() {
  local seconds="${1:-60}" i file="$REPORT_DIR/workload-replica-wait.json"
  for ((i=0; i<seconds; i+=2)); do
    if nats_cli stream info "$STREAM" --json >"$file" 2>"${file%.json}.err" && python3 - "$file" <<'PYREPLICA'
import json,sys
try:
 d=json.load(open(sys.argv[1])); reps=(d.get('cluster') or {}).get('replicas') or []
 ok=len(reps)==2 and all(r.get('current') is True for r in reps)
 sys.exit(0 if ok else 1)
except Exception: sys.exit(1)
PYREPLICA
    then
      pass "Both stream replicas report current"
      return 0
    fi
    sleep 2
  done
  fail "Replica catch-up not confirmed within ${seconds}s"
  return 1
}


# Write a deterministic manifest for the events generated in a batch. Event IDs are
# captured from the payload files, allowing later consumer/output reconciliation.
workload_write_manifest() {
  local glob="$REPORT_DIR/workload-*-payload.json" dest="$REPORT_DIR/event-manifest.json"
  python3 - "$REPORT_DIR" "$dest" <<'PYMANIFEST'
import glob,json,os,sys
root,dest=sys.argv[1:]
rows=[]
for path in sorted(glob.glob(os.path.join(root,'workload-*-payload.json'))):
 try:
  d=json.load(open(path))
  rows.append({'eventId':d.get('eventId'),'paymentId':d.get('paymentId'),'phase':d.get('phase'),'payloadFile':os.path.basename(path)})
 except Exception: pass
with open(dest,'w') as f: json.dump({'eventCount':len(rows),'events':rows},f,indent=2)
print(f'Event manifest: {dest} ({len(rows)} event payload(s))')
PYMANIFEST
}

# Consume up to COUNT messages from a pre-provisioned pull durable using the NATS CLI.
# This is an actual CLI pull/ACK attempt, unlike inspecting consumer metadata only.
# CLI output is retained verbatim because formatting differs by nats CLI version.
workload_consume_pull() {
  local durable="${1:-$PROCESSOR_CONSUMER}" count="${2:-1}" phase="${3:-consume}"
  local out="$REPORT_DIR/workload-${phase}-consume.out" err="$REPORT_DIR/workload-${phase}-consume.err"
  [[ "$count" =~ ^[1-9][0-9]*$ ]] || { fail "Invalid consume count: $count"; return 1; }
  info "Pull consume: durable=$durable count=$count; CLI output will be retained"
  local rc=0 summary="$REPORT_DIR/workload-${phase}-consume-summary.json"
  if nats_cli consumer next "$STREAM" "$durable" --count "$count" --ack >"$out" 2>"$err"; then
    if python3 - "$out" "$summary" <<'PYCONSUME'
import json,re,sys
text=open(sys.argv[1],errors='replace').read()
# NATS CLI versions vary slightly; retain raw output and count known delivery/ACK markers.
received=len(re.findall(r"(?:---\s*received on|Received JetStream message:|Received message:)",text,re.I))
acks=len(re.findall(r"Acknowledged message|ack(?:nowledged)?[:= ]+true",text,re.I))
event_ids=[]
for line in text.splitlines():
 line=line.strip()
 if line.startswith('{'):
  try:
   d=json.loads(line)
   if isinstance(d,dict) and d.get('eventId'): event_ids.append(d['eventId'])
  except Exception: pass
json.dump({'received_markers':received,'ack_markers':acks,'eventIds':event_ids,'raw_output':sys.argv[1]},open(sys.argv[2],'w'),indent=2)
if received>0 and acks>0:
 print(f'Consumer CLI evidence: received markers={received}, ACK markers={acks}, parsed eventIds={len(event_ids)}')
 sys.exit(0)
sys.exit(1)
PYCONSUME
    then
      pass "NATS CLI showed delivery and ACK markers for $durable"
      printf 'CONSUME_OUTPUT=%s\nCONSUME_SUMMARY=%s\n' "$out" "$summary"
      return 0
    fi
    inconclusive "Consumer command returned but delivery/ACK markers were not recognized; inspect $out and $summary for CLI-version compatibility"
    return 1
  else
    rc=$?
  fi
  inconclusive "NATS CLI consumer next failed for $durable (exit=$rc); check durable type, pending messages, CLI flags and $err"
  return 1
}

# Wait until the consumer's delivered stream sequence reaches the target sequence.
# This proves the server cursor moved, not that application business logic succeeded.
workload_wait_consumer_delivered_seq() {
  local durable="$1" target_seq="$2" seconds="${3:-30}" i file="$REPORT_DIR/consumer-${durable}-wait.json"
  [[ "$target_seq" =~ ^[0-9]+$ ]] || { fail "Invalid target sequence: $target_seq"; return 1; }
  for ((i=0;i<seconds;i+=2)); do
    if nats_cli consumer info "$STREAM" "$durable" --json >"$file" 2>"${file%.json}.err" && python3 - "$file" "$target_seq" <<'PYWAIT'
import json,sys
try:
 d=json.load(open(sys.argv[1])); got=((d.get('delivered') or {}).get('stream_seq'))
 sys.exit(0 if isinstance(got,int) and got>=int(sys.argv[2]) else 1)
except Exception: sys.exit(1)
PYWAIT
    then
      pass "$durable delivered stream sequence reached target $target_seq (server cursor only)"
      return 0
    fi
    sleep 2
  done
  inconclusive "$durable did not report delivered stream sequence >= $target_seq within ${seconds}s"
  return 1
}

# Compare stream message count/sequence around a workload phase.
workload_assert_stream_advanced() {
  local before="$1" after="$2" expected_min="${3:-1}"
  python3 - "$before" "$after" "$expected_min" <<'PYADV'
import json,sys
try:
 b=json.load(open(sys.argv[1])).get('state') or {}; a=json.load(open(sys.argv[2])).get('state') or {}
 bm,am,bs,asq=(b.get('messages'),a.get('messages'),b.get('last_seq'),a.get('last_seq'))
 need=int(sys.argv[3])
 if not all(isinstance(x,int) for x in (bm,am,bs,asq)): raise ValueError('message/sequence fields unavailable')
 if am-bm < need or asq-bs < need: raise ValueError(f'expected >= {need} new messages; messages {bm}->{am}, sequence {bs}->{asq}')
 print(f'Stream advanced: messages {bm}->{am}; last_seq {bs}->{asq}; minimum expected={need}')
except Exception as e:
 print('Stream progression check failed:',e); sys.exit(1)
PYADV
}
