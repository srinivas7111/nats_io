#!/usr/bin/env bash
# Orchestrates safe workload checks by default; --all-disruptive runs every destructive scenario sequentially.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SCRIPTS="$ROOT/scripts"
MODE="${1:---safe}"
RUN_ID="${RUN_ID:-nats-comprehensive-$(date +%Y%m%d-%H%M%S)-$$}"
BASE_REPORT_DIR="${REPORT_DIR:-$ROOT/payment-factory-evidence-${RUN_ID}}"
mkdir -p "$BASE_REPORT_DIR"
RESULTS="$BASE_REPORT_DIR/comprehensive-results.tsv"
: > "$RESULTS"

case "$MODE" in
  --safe) ;;
  --all-disruptive)
    if [[ "${CONFIRM_DISRUPTIVE:-}" != "YES" ]]; then
      printf 'Refusing to run disruptive suite without explicit confirmation.\n'
      printf 'Use: CONFIRM_DISRUPTIVE=YES bash scripts/19_run_comprehensive_scenarios.sh --all-disruptive\n'
      exit 2
    fi
    ;;
  *) printf 'Usage: %s [--safe|--all-disruptive]\n' "$0"; exit 2 ;;
esac

printf '\n========== 19_run_comprehensive_scenarios.sh :: Comprehensive NATS/JetStream Test Run ==========\n'
printf 'RUN ID    : %s\nMODE      : %s\nEVIDENCE  : %s\n' "$RUN_ID" "$MODE" "$BASE_REPORT_DIR"
printf 'Objective : Run workload and resilience scenarios sequentially, preserving per-script evidence.\n'
printf 'Acceptance: Each invoked script writes a result summary; disruptive tests are never launched without explicit confirmation.\n\n'

run_one() {
  local script="$1" label="${1%.sh}" dir="$BASE_REPORT_DIR/$label" rc=0
  mkdir -p "$dir"
  printf '\n### RUN %s ###\n' "$script"
  if RUN_ID="$RUN_ID-$label" REPORT_DIR="$dir" bash "$SCRIPTS/$script"; then rc=0; else rc=$?; fi
  printf '%s\t%s\t%s\n' "$script" "$rc" "$dir" | tee -a "$RESULTS"
  if (( rc == 0 )); then printf 'RUNNER RESULT: PASS (%s)\n' "$script";
  elif (( rc == 2 )); then printf 'RUNNER RESULT: INCONCLUSIVE (%s)\n' "$script";
  else printf 'RUNNER RESULT: FAIL (%s, exit=%s)\n' "$script" "$rc"; fi
  return 0
}

# Safe suite: baseline, publish smoke, batch workload, then attempt pull/ACK validation.
run_one 01_baseline_infra.sh
run_one 01_01_publish_verify.sh
run_one 17_workload_publish_events.sh
run_one 18_workload_consume_events.sh

if [[ "$MODE" == "--all-disruptive" ]]; then
  printf '\nWARNING: Running destructive scenarios sequentially. Confirm each prompt and restore the environment before proceeding.\n'
  for script in 02_stream_leader_failover.sh 03_follower_failure_recovery.sh 04_stream_rejoin_catchup.sh 05_pull_cursor_resume.sh 06_pull_unacked_redelivery.sh 07_pull_consumer_leader_failover.sh 08_push_cursor_offline_catchup.sh 09_push_subscriber_reconnect.sh 10_push_consumer_leader_failover.sh 11_two_node_quorum_loss.sh 12_quorum_restoration.sh 13_haproxy_backend_failure.sh 14_haproxy_process_failure.sh 15_duplicate_idempotency.sh 16_end_to_end_one_node_failure.sh; do
    run_one "$script"
  done
fi

python3 - "$RESULTS" <<'PYRESULT'
import sys
rows=[]
for line in open(sys.argv[1]):
 p=line.rstrip('\n').split('\t')
 if len(p)>=3:
  try: rows.append((p[0],int(p[1]),p[2]))
  except ValueError: pass
print('\n========== COMPREHENSIVE RUN SUMMARY ==========')
print(f'Scripts executed: {len(rows)}')
print(f'Exit 0 (PASS): {sum(rc==0 for _,rc,_ in rows)}')
print(f'Exit 2 (INCONCLUSIVE): {sum(rc==2 for _,rc,_ in rows)}')
print(f'Other failures: {sum(rc not in (0,2) for _,rc,_ in rows)}')
print('Detailed results:',sys.argv[1])
print('Reminder: script exit codes are infrastructure/CLI results; they do not prove application business processing or exactly-once side effects.')
PYRESULT
