#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  exec bash "$0" "$@"
fi
# Scenario: HAProxy Backend Failure and Recovery
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh first. This stops one NATS backend while HAProxy remains running, attempts a CLI JetStream publish, then restores the backend.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "13_haproxy_backend_failure.sh" "HAProxy Backend Failure and Recovery" "Stop one NATS backend while HAProxy remains running, then restore it." "disruptive"
criterion "HAProxy remains running during backend outage."
criterion "Capture client-path status during outage."
criterion "Restore backend and inspect stream replicas."
show_connection

# JR-13: HAProxy backend failure
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=disruptive"
section "Baseline LB and cluster"; snapshot
TARGET="${TARGET_NODE:-${NODES[2]}}"
confirm "Stop backend $TARGET while Java/NATS clients use HAProxy." || { skip "Operator cancelled"; finish; exit 0; }
section "Stop backend and probe via LB"; stop_node "$TARGET"; sleep 5; print_lb_status; workload_publish "backend-down" success; snapshot
section "Restore backend"; start_node "$TARGET"; wait_node "$TARGET"; sleep 10; snapshot
inconclusive "Backend recovery steps completed; inspect saved HAProxy stats to confirm backend state."
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
