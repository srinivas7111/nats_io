#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  exec bash "$0" "$@"
fi
# FULL-FLOW GUIDE: RELATED FLOW: Run after 01_baseline_infra.sh. This is the reusable baseline publish smoke test; later scenarios call workload_publish directly when their acceptance criteria require traffic. It does not replace scenario-specific validation.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "01_01_publish_verify.sh" "Baseline Publish Verification" "Temporarily publish one uniquely identified event through HAProxy and verify JetStream acknowledgement and stream progression." "temporary-cli"
criterion "The NATS CLI JetStream publish returns a publish acknowledgement."
criterion "The stream message count and last sequence advance by one."
criterion "Leader and replica status are captured from JetStream."
criterion "Consumer processing is left to Java clients."
show_connection
preflight || { finish; exit 1; }
BEFORE="$REPORT_DIR/before.json"; AFTER="$REPORT_DIR/after.json"
get_stream_json "$BEFORE" "$REPORT_DIR/before.err" || { fail "Cannot inspect stream before publishing."; finish; exit 1; }
BEFORE_MSGS="$(stream_value "$BEFORE" messages)"; BEFORE_SEQ="$(stream_value "$BEFORE" last_seq)"
EVENT_ID="${EVENT_ID:-${RUN_ID}-event-001}"
PAYLOAD="{\"eventId\":\"${EVENT_ID}\",\"runId\":\"${RUN_ID}\",\"type\":\"payment.created\",\"source\":\"temporary-cli-publisher\"}"
printf '%s\n' "$PAYLOAD" > "$REPORT_DIR/published-event.json"
START_EPOCH="$(date +%s)"
workload_publish "baseline" success || { finish; exit 1; }
END_EPOCH="$(date +%s)"; DURATION=$((END_EPOCH-START_EPOCH))
get_stream_json "$AFTER" "$REPORT_DIR/after.err" || { fail "Cannot inspect stream after publishing."; finish; exit 1; }
AFTER_MSGS="$(stream_value "$AFTER" messages)"; AFTER_SEQ="$(stream_value "$AFTER" last_seq)"
ACK_SEQ="$(python3 - "$REPORT_DIR/workload-baseline-ack.json" <<'PYACK'
import json,sys
try: print(json.load(open(sys.argv[1]))['seq'])
except Exception: print('unknown')
PYACK
)"
EVENT_ID="$(python3 - "$REPORT_DIR/workload-baseline-payload.json" <<'PYEVENT'
import json,sys
print(json.load(open(sys.argv[1]))['eventId'])
PYEVENT
)"
_emit "CONNECTION"
_emit "  Client endpoint : nats://${LB_HOST}:${LB_PORT}"
_emit "  Load balancer   : ${LB_CONTAINER}:${LB_PORT}"
_emit "PUBLISH"
_emit "  Event ID        : $EVENT_ID"
_emit "  Publish ACK     : PASS (JetStream reply parsed)"
_emit "  Message sequence: $ACK_SEQ"
_emit "  CLI duration    : ${DURATION}s (whole-second resolution)"
_emit "STREAM PROGRESS"
_emit "                  BEFORE  AFTER"
_emit "  Messages        : $BEFORE_MSGS  $AFTER_MSGS"
_emit "  Last sequence   : $BEFORE_SEQ  $AFTER_SEQ"
_emit "CLUSTER"
_emit "  Leader          : $(stream_value "$AFTER" leader)"
_emit "  Replicas        : $(stream_value "$AFTER" replica_names)"
_emit "  Replica status  : $(stream_value "$AFTER" replica_status)"
if [[ "$AFTER_SEQ" =~ ^[0-9]+$ && "$BEFORE_SEQ" =~ ^[0-9]+$ && "$AFTER_MSGS" =~ ^[0-9]+$ && "$BEFORE_MSGS" =~ ^[0-9]+$ ]] && (( AFTER_SEQ > BEFORE_SEQ && AFTER_MSGS == BEFORE_MSGS+1 )); then pass "Stream progression verified."; else fail "Expected exactly one new stored message; inspect before/after JSON."; fi
if [[ "$ACK_SEQ" =~ ^[0-9]+$ && "$AFTER_SEQ" =~ ^[0-9]+$ && "$ACK_SEQ" -eq "$AFTER_SEQ" ]]; then pass "Acknowledged sequence is consistent with stream state."; else inconclusive "Could not parse ACK sequence; inspect publish.out. Do not infer sequence from stream growth alone."; fi
_emit "CONSUMERS"
_emit "  Processing      : Java client verification pending"
_emit "  Notifications   : Java client verification pending"
finish
