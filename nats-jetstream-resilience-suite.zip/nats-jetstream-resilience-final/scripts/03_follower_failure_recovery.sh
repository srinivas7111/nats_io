#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  exec bash "$0" "$@"
fi
# Scenario: Follower Failure and Recovery
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh, then this script. It stops a non-leader node, performs a CLI publish probe, restores the node, and checks replica recovery.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "03_follower_failure_recovery.sh" "Follower Failure and Recovery" "Stop a non-leader NATS node, inspect cluster status, then restore it." "disruptive"
criterion "Target is a running non-leader node."
criterion "Capture remaining cluster and client path during outage."
criterion "Restore node and capture replica catch-up status."
show_connection

# JR-03: Follower failure and recovery
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=disruptive"
section "Capture baseline"; snapshot
section "Select a running node that is not the stream leader"
nats_cli stream info "$STREAM" --json > "$REPORT_DIR/stream-before.json" || { fail "Cannot inspect stream"; finish; exit 1; }
LEADER="$(python3 - "$REPORT_DIR/stream-before.json" <<'PY'
import json,sys
print((json.load(open(sys.argv[1])).get("cluster") or {}).get("leader",""))
PY
)"
TARGET=""
for n in "${NODES[@]}"; do [[ "$n" != "$LEADER" ]] && is_running "$n" && { TARGET="$n"; break; }; done
[[ -n "$TARGET" ]] || { fail "Could not find running follower"; finish; exit 1; }
printf 'STREAM_LEADER=%s FOLLOWER_TARGET=%s\n' "$LEADER" "$TARGET"
section "Stop follower and publish probe"
confirm "This stops follower $TARGET. Continue?" || { skip "Operator cancelled"; finish; exit 0; }
stop_node "$TARGET"; sleep 5; workload_publish "follower-down" success
section "Verify stream/LB/nodes"; snapshot
section "Restore follower"; start_node "$TARGET"; wait_node "$TARGET"; sleep 10; snapshot
inconclusive "Follower was restored; replica catch-up must be confirmed in stream JSON."
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
