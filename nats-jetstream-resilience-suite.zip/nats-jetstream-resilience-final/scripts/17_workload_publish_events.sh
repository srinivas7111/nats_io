#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-workload-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  exec bash "$0" "$@"
fi
# FULL-FLOW GUIDE: Run after 01_baseline_infra.sh. Follow with 18_workload_consume_events.sh to pull/ACK from PAYMENT_PROCESSORS. The event manifest and PubAck/sequence evidence are written to REPORT_DIR.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
COUNT="${1:-5}"
PHASE="${2:-demo-publish}"
begin_test "17_workload_publish_events.sh" "Publish Payment Events" "Publish a batch of unique payment marker events through HAProxy using JetStream PubAck and retain payload/sequence evidence." "workload"
criterion "Every requested event has a parseable JetStream PubAck."
criterion "Stream message count and last sequence advance by at least the requested batch size."
criterion "Unique event payloads and a manifest are retained for later consume reconciliation."
show_connection
[[ "$COUNT" =~ ^[1-9][0-9]*$ ]] || { fail "COUNT must be a positive integer"; finish; exit 1; }
preflight || { finish; exit 1; }
BEFORE="$REPORT_DIR/${PHASE}-stream-before.json"
AFTER="$REPORT_DIR/${PHASE}-stream-after.json"
get_stream_json "$BEFORE" "$REPORT_DIR/${PHASE}-stream-before.err" || { fail "Cannot inspect stream before publish"; finish; exit 1; }
START_SEQ="$(stream_value "$BEFORE" last_seq)"
section "PUBLISH WORKLOAD"
info "Requested event count=$COUNT phase=$PHASE"
if workload_publish_batch "$PHASE" "$COUNT"; then pass "Published $COUNT event(s) with JetStream PubAck evidence"; else fail "Publish batch did not complete"; finish; exit 1; fi
get_stream_json "$AFTER" "$REPORT_DIR/${PHASE}-stream-after.err" || { fail "Cannot inspect stream after publish"; finish; exit 1; }
workload_assert_stream_advanced "$BEFORE" "$AFTER" "$COUNT" && pass "Stream progressed by at least $COUNT messages" || fail "Stream progression did not meet batch expectation"
workload_write_manifest
info "Start consumer validation with: bash scripts/18_workload_consume_events.sh ${PROCESSOR_CONSUMER} $COUNT"
info "Starting stream sequence was: $START_SEQ"
finish
