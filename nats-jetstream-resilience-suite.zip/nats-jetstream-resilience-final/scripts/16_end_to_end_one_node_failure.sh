#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  exec bash "$0" "$@"
fi
# Scenario: End-to-End One-Node Failure
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh and ensure both durable consumers exist. Keep any available CLI test subscribers/workload observers running; this script injects one-node failure and publishes a marker, but end-to-end processing/notification assertions require subscriber evidence.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "16_end_to_end_one_node_failure.sh" "End-to-End One-Node Failure" "Observe cluster during one-node outage and publish a CLI marker; capture consumer checkpoints where configured." "disruptive/java"
criterion "Stop one node after explicit confirmation."
criterion "Capture cluster and client path during outage."
criterion "Restore node and verify replica catch-up."
criterion "Record marker publish ACK and infrastructure recovery; processing/notification outcomes remain inconclusive without subscriber evidence."
show_connection
info "CLI-only mode: workload_publish and workload_consumer_checkpoint are available; consumer delivery/ACK/business effects require separate CLI subscriber evidence."

# JR-16: End-to-end publish/process/notification during one-node failure
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=disruptive"
section "Baseline snapshot"; workload_consumer_checkpoint "$PROCESSOR_CONSUMER" before || true; workload_consumer_checkpoint "$NOTIFICATION_CONSUMER" before || true; snapshot
info "Optional for full application flow: run two publishers, both pull processors, and the push notification subscriber. This shell suite alone cannot assert business processing."
info "Record event IDs and business outcomes from any active subscriber harness before disruption."
TARGET="${TARGET_NODE:-${NODES[2]}}"
confirm "Stop one NATS node ($TARGET) while all Java clients are active." || { skip "Operator cancelled"; finish; exit 0; }
section "Stop node, keep workload running"; stop_node "$TARGET"; sleep 8; workload_publish "node-down" success; snapshot
read -r -p "Wait for all Java clients to reconnect and drain, then press Enter..."
section "Restore node and capture final evidence"; start_node "$TARGET"; wait_node "$TARGET"; sleep 15; snapshot
workload_consumer_checkpoint "$PROCESSOR_CONSUMER" after || true; workload_consumer_checkpoint "$NOTIFICATION_CONSUMER" after || true; inconclusive "Payment business effects and notification delivery require subscriber evidence"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
