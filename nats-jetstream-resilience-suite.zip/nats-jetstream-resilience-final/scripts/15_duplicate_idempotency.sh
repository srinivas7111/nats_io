#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  exec bash "$0" "$@"
fi
# Scenario: Duplicate Delivery and Idempotency
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh and ensure PAYMENT_PROCESSORS exists. The script publishes a marker and captures consumer state. Without a real subscriber/business-effect observer, duplicate delivery and exactly-once business effect remain INCONCLUSIVE.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "15_duplicate_idempotency.sh" "Duplicate Delivery and Idempotency" "Publish a marker and capture consumer state; report business idempotency as inconclusive without an application-side effect observer." "manual/java"
criterion "Capture baseline processor state."
criterion "Record the marker event ID and consumer state for follow-up comparison."
criterion "Do not claim exactly-once business effect from CLI-only evidence."
show_connection
info "CLI-only mode: workload_publish and workload_consumer_checkpoint are available; consumer delivery/ACK/business effects require separate CLI subscriber evidence."

# JR-15: Duplicate delivery and idempotent business processing
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=manual"
section "Baseline"; workload_consumer_checkpoint "$PROCESSOR_CONSUMER" before || true; workload_publish "duplicate-demo-marker" success || true
info "ACTION REQUIRED: a real subscriber must receive the event, perform the business effect, then be interrupted before ACK to prove redelivery."
info "The CLI helper alone cannot prove redelivery or deduplication. Compare subscriber event IDs and business-effect count when a subscriber harness is available."
read -r -p "After observing the same event ID on redelivery, press Enter..."
section "Capture cursor and redelivery counters"; workload_consumer_checkpoint "$PROCESSOR_CONSUMER" after || true
inconclusive "Java client evidence is required to verify application-level acceptance."
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
