#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  exec bash "$0" "$@"
fi
# Scenario: Quorum Restoration
# FULL-FLOW GUIDE: RELATED FLOW: Prefer running after 11_two_node_quorum_loss.sh, or after manually restoring a previously interrupted quorum test. It waits for node recovery and validates publishing/replica status.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "12_quorum_restoration.sh" "Quorum Restoration" "Verify cluster and replicated stream health after node recovery." "recovery"
criterion "All nodes respond on monitoring endpoints."
criterion "HAProxy client path is reachable."
criterion "Stream remains configured for RF=3."
criterion "Replica status is current or inconclusive."
show_connection

# JR-12: Quorum restoration after node recovery
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=manual"
section "Current cluster snapshot"; snapshot
info "If a previous quorum test left nodes stopped, restore them before proceeding."
for n in "${NODES[@]}"; do if ! is_running "$n"; then warn "$n is stopped"; fi; done
read -r -p "Restore all expected nodes manually if needed, then press Enter..."
for n in "${NODES[@]}"; do wait_node "$n" || true; done
section "Test JetStream publish after quorum returns"; workload_publish "quorum-restored" success
section "Verify stream and consumer replicas"; snapshot
inconclusive "Recovery snapshot captured; confirm all nodes and replicas are healthy. Publishing is delegated to Java clients."
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
