#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  exec bash "$0" "$@"
fi
# Scenario: Pull Consumer Leader Failover
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh; ensure PAYMENT_PROCESSORS exists and its consumer leader is known; then run this script. It injects a NATS node failure and captures consumer state; it cannot prove delivery/ACK continuity without a consumer harness.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "07_pull_consumer_leader_failover.sh" "Pull Consumer Leader Failover" "Stop the NATS node reported as pull consumer leader and restore it." "disruptive/java"
criterion "Capture consumer leader before disruption."
criterion "Confirm target before stopping."
criterion "Restore node and capture consumer state."
criterion "Java evidence verifies processing continuity."
show_connection
info "CLI-only mode: workload_publish and workload_consumer_checkpoint are available; consumer delivery/ACK/business effects require separate CLI subscriber evidence."

# JR-07: Pull durable consumer leader failover
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=disruptive"
section "Capture consumer cluster state"; workload_consumer_checkpoint "$PROCESSOR_CONSUMER" before || true; snapshot
info "Use the consumer info JSON to identify PAYMENT_PROCESSORS cluster leader and replicas."
info "This scenario must stop the actual consumer leader, not an arbitrary NATS node."
TARGET="${TARGET_NODE:-}"
if [[ -z "$TARGET" ]]; then
  read -r -p "Enter the confirmed PAYMENT_PROCESSORS consumer leader container name: " TARGET
fi
[[ " ${NODES[*]} " == *" $TARGET "* ]] || { fail "Target is not in NODES_CSV"; finish; exit 1; }
confirm "Stop consumer leader $TARGET, then test pull processing." || { skip "Operator cancelled"; finish; exit 0; }
stop_node "$TARGET"; sleep 8; snapshot
workload_publish "pull-leader-down" success || true
section "Restore node"; start_node "$TARGET"; wait_node "$TARGET"; sleep 10; snapshot
workload_consumer_checkpoint "$PROCESSOR_CONSUMER" after || true; inconclusive "Consumer delivery and ACK continuity not demonstrated by infrastructure CLI"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
