#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  exec bash "$0" "$@"
fi
# Scenario: Stream Replica Rejoin and Catch-up
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh, then this script. It restarts a selected node, publishes a marker while it is offline, and checks replica catch-up.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "04_stream_rejoin_catchup.sh" "Stream Replica Rejoin and Catch-up" "Restart a NATS node and inspect whether its stream replica catches up." "disruptive"
criterion "Capture leader and replica state before restart."
criterion "Restart node and verify monitoring endpoint."
criterion "Capture post-restart replica state."
show_connection

# JR-04: Restart node and verify replica catch-up
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=disruptive"
section "Baseline snapshot"; snapshot
section "Select node to restart"
TARGET="${TARGET_NODE:-${NODES[2]}}"
printf 'TARGET_NODE=%s\n' "$TARGET"
confirm "This restarts $TARGET; choose a non-leader if you do not intend a leader test." || { skip "Operator cancelled"; finish; exit 0; }
section "Stop node"; stop_node "$TARGET"; sleep 5
section "Publish while node is absent"; workload_publish "replica-offline" success
section "Restart and inspect catch-up"; start_node "$TARGET"; wait_node "$TARGET"; sleep 15; workload_replica_wait 60 || true; snapshot
inconclusive "Node rejoined; replica catch-up must be confirmed in stream JSON."
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
