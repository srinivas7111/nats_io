#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  exec bash "$0" "$@"
fi
# Scenario: Push Consumer Offline Catch-up
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh; ensure PAYMENT_NOTIFICATIONS exists; stop the notification subscriber manually; run this script to publish markers; restart the subscriber and verify event IDs/cursors separately.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "08_push_cursor_offline_catchup.sh" "Push Consumer Offline Catch-up" "Use Java notification client to verify durable push consumer catches up after reconnect." "manual/java"
criterion "Capture notification consumer state before disconnect."
criterion "Java verifies offline events arrive after reconnect."
criterion "Capture ACK floor and pending state."
show_connection
info "CLI-only mode: workload_publish and workload_consumer_checkpoint are available; consumer delivery/ACK/business effects require separate CLI subscriber evidence."

# JR-08: Push durable cursor while notification client is offline
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=manual"
section "Baseline notification cursor"; workload_consumer_checkpoint "$NOTIFICATION_CONSUMER" before || true
info "ACTION REQUIRED: stop Subscriber 3 process only; keep NATS and JetStream running."
read -r -p "After Subscriber 3 is stopped, press Enter to publish offline events..."
section "Publish three uniquely identified notification events"
workload_publish_batch "notification-offline" 3 || true
read -r -p "Restart Subscriber 3 and wait for it to process pending events, then press Enter..."
section "Inspect notification cursor and pending counts"; workload_consumer_checkpoint "$NOTIFICATION_CONSUMER" after || true
inconclusive "Java client evidence is required to verify application-level acceptance."
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
