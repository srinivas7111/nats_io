#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-consume-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  exec bash "$0" "$@"
fi
# FULL-FLOW GUIDE: Run after 17_workload_publish_events.sh for pull-consumer workload. The consumer must already exist as a pull durable. Use PAYMENT_NOTIFICATIONS only if it is configured as a pull consumer; push delivery is a subscriber-side test and cannot be consumed with `consumer next`.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
DURABLE="${1:-$PROCESSOR_CONSUMER}"
COUNT="${2:-5}"
PHASE="${3:-demo-consume}"
begin_test "18_workload_consume_events.sh" "Consume and ACK Payment Events" "Use the NATS CLI to pull up to COUNT events from an existing durable and capture consumer cursor plus raw output evidence." "workload"
criterion "The configured durable consumer is inspectable before and after the pull."
criterion "The NATS CLI pull/ACK command completes and its raw output is retained."
criterion "Consumer cursor and pending/redelivery counters are captured for comparison."
criterion "No business processing or exactly-once side effect is claimed from CLI evidence alone."
show_connection
[[ "$COUNT" =~ ^[1-9][0-9]*$ ]] || { fail "COUNT must be a positive integer"; finish; exit 1; }
preflight || { finish; exit 1; }
section "CONSUMER BEFORE"
workload_consumer_checkpoint "$DURABLE" before || { inconclusive "Could not capture pre-consume consumer checkpoint"; finish; exit 2; }
section "PULL AND ACK"
if workload_consume_pull "$DURABLE" "$COUNT" "$PHASE"; then pass "Consumer pull command completed"; else inconclusive "Pull/ACK outcome requires review of CLI evidence"; fi
section "CONSUMER AFTER"
workload_consumer_checkpoint "$DURABLE" after || inconclusive "Could not capture post-consume consumer checkpoint"
if [[ -f "$REPORT_DIR/consumer-${DURABLE}-before.json" && -f "$REPORT_DIR/consumer-${DURABLE}-after.json" ]]; then
  workload_consumer_nonregression "$DURABLE" before after && pass "Consumer cursor non-regression check passed" || inconclusive "Consumer cursor comparison unavailable or regressed"
fi
info "Raw pull output: $REPORT_DIR/workload-${PHASE}-consume.out"
info "For application-level validation, compare received eventIds and business/ACK logs from a real subscriber."
finish
