# NATS JetStream resilience demo — CLI-only suite

This bundle contains the baseline infrastructure test, a standalone publish smoke test, 15 numbered resilience scenarios (02–16), and the shared helper scripts. It is intended for the local Podman demo environment described below.

## Files

- `scripts/01_baseline_infra.sh` — non-disruptive infrastructure/stream baseline.
- `scripts/01_01_publish_verify.sh` — standalone JetStream publish smoke test.
- `scripts/02_...sh` through `scripts/16_...sh` — individual resilience scenarios.
- `scripts/lib.sh` — common config, logging, checks, stream provisioning, node/HAProxy operations, JSON parsing, result summary.
- `scripts/workload_helpers.sh` — CLI workload and stream/consumer evidence helpers.
- `RUN-ORDER.md` — related scripts and end-to-end flow recommendations.
- `SCENARIO-MATRIX.md` — scenarios, acceptance targets, and CLI-only limitations.

## Environment defaults

- NATS nodes: `nats-1`, `nats-2`, `nats-3`
- HAProxy container: `nats-lb`
- Podman network: `nats-net`
- Host client endpoint: `nats://nats.local.test:4222`
- In-network client endpoint: `nats://nats-lb:4222`
- HAProxy stats URL: `http://localhost:8404/stats`
- Stream: `PAYMENT_EVENTS`
- Subject: `payment.events.created`
- Pull durable: `PAYMENT_PROCESSORS`
- Push durable: `PAYMENT_NOTIFICATIONS`

Override through environment variables, e.g.:

```bash
export STREAM=PAYMENT_EVENTS
export SUBJECT=payment.events.created
export PROCESSOR_CONSUMER=PAYMENT_PROCESSORS
export NOTIFICATION_CONSUMER=PAYMENT_NOTIFICATIONS
export NODES_CSV="nats-1 nats-2 nats-3"
export REPORT_DIR="./evidence-my-run"
# If your installed NATS CLI uses a different JetStream publish flag:
export NATS_JS_FLAG=--jetstream
```

## Requirements and setup

1. Run from a machine with Podman, `curl`, `python3`, and Bash.
2. The NATS CLI image defaults to `docker.io/natsio/nats-box:latest`.
3. `preflight` preserves an existing `PAYMENT_EVENTS` stream without changing its configuration. If it cannot inspect the stream, it attempts to create the demo defaults: subject `payment.events.created`, file storage, RF=3, limits retention. Confirm this behavior is acceptable before running.
4. Durable consumers are **not created automatically**. Provision `PAYMENT_PROCESSORS` and `PAYMENT_NOTIFICATIONS` with the intended settings before running consumer scenarios.
5. Verify the installed NATS CLI supports the JetStream publish flag set by `NATS_JS_FLAG` (default `--js`). The helper requires a parseable JetStream PubAck. If output format differs, inspect the captured `workload-*-publish.out` and update the parser rather than weakening acceptance criteria.
6. Scripts that stop NATS nodes or HAProxy are disruptive. Run only in a disposable demo environment, read the prompt, and type `YES` to proceed.

## Start safely

```bash
chmod +x scripts/*.sh
bash scripts/01_baseline_infra.sh
bash scripts/01_01_publish_verify.sh
```

Then use `RUN-ORDER.md` for the relevant scenario flow. Do not run all disruptive tests in parallel. Run each test independently and confirm the environment has been restored before starting the next.

## Output and result meanings

Every test prints a header in this format:

`========== <script_name> :: <test scenario> ==========`

It then prints the objective and acceptance criteria, actions, evidence location, and final result.

- `PASS`: mandatory criteria were verified.
- `FAIL`: a mandatory criterion failed.
- `INCONCLUSIVE`: the scenario ran or evidence was collected, but one or more required behaviors could not be proven.
- `WARN`: a diagnostic or optional check is unavailable; warnings are not passes.
- `SKIP`: the operator cancelled or an explicitly optional action was skipped.

The exit code is `0` for PASS, `1` for FAIL, and `2` for INCONCLUSIVE. A script can produce a valid infrastructure PASS while a separate application-level criterion remains unverified; do not describe that as end-to-end PASS.

## CLI-only limits (no Java clients)

These helpers can publish uniquely identified marker events with JetStream acknowledgements, record stream sequence/count, inspect leader/replica state, wait for replica catch-up, and snapshot durable consumer cursors and pending/redelivery counters.

They cannot by themselves prove that a subscriber received a specific event, executed business logic, acknowledged it, reconnected successfully, or produced exactly one business side effect. Consumer cursor values and redelivery counters are useful evidence, but are not substitutes for subscriber-level evidence. The corresponding tests intentionally report `INCONCLUSIVE` when application-level acceptance cannot be established.

## Evidence

Each run writes `run.log`, `summary.txt`, and per-step JSON/output/error files to `REPORT_DIR`. Keep the `RUN_ID` and event IDs with the scenario evidence when comparing related runs.
