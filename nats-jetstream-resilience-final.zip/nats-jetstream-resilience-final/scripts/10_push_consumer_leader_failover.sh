#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  set -o pipefail
  bash "$0" "$@" 2>&1 | tee -a "$REPORT_DIR/run.log"
  exit $?
fi
# Scenario: Push Consumer Leader Failover
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh; ensure PAYMENT_NOTIFICATIONS exists and its consumer leader is known; then run this script. It captures infrastructure/cursor state, not proof of notification processing.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "10_push_consumer_leader_failover.sh" "Push Consumer Leader Failover" "Stop the NATS node reported as push consumer leader and restore it." "disruptive/java"
criterion "Capture consumer leader before disruption."
criterion "Confirm target before stopping."
criterion "Restore node and capture consumer state."
criterion "Java evidence verifies notification continuity."
show_connection
info "CLI-only mode: workload_publish and workload_consumer_checkpoint are available; consumer delivery/ACK/business effects require separate CLI subscriber evidence."

# JR-10: Push durable consumer leader failover
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=disruptive"
section "STEP 1 - Inspect consumer state"; workload_consumer_checkpoint "$NOTIFICATION_CONSUMER" before || true; snapshot
TARGET="${TARGET_NODE:-}"
if [[ -z "$TARGET" ]]; then read -r -p "Enter the confirmed PAYMENT_NOTIFICATIONS consumer leader node: " TARGET; fi
[[ " ${NODES[*]} " == *" $TARGET "* ]] || { fail "Target is not in NODES_CSV"; finish; exit 1; }
confirm "Stop consumer leader $TARGET; notification delivery may pause." || { skip "Operator cancelled"; finish; exit 0; }
section "STEP 2 - Stop leader, publish probe, inspect"; stop_node "$TARGET"; sleep 8; workload_publish "push-leader-down" success || true; snapshot
section "STEP 3 - Restore node"; start_node "$TARGET"; wait_node "$TARGET"; sleep 10; snapshot
workload_consumer_checkpoint "$NOTIFICATION_CONSUMER" after || true; inconclusive "Notification delivery and ACK continuity require subscriber evidence"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
