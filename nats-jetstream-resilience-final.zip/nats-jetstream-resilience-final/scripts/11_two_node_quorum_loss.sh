#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  set -o pipefail
  bash "$0" "$@" 2>&1 | tee -a "$REPORT_DIR/run.log"
  exit $?
fi
# Scenario: Two-Node Quorum Loss
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh first. This is highly disruptive and requires explicit confirmation; it stops two nodes, tests expected publish failure, and attempts to restore both nodes before exit. Run 12_quorum_restoration.sh afterward for a separate recovery validation.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "11_two_node_quorum_loss.sh" "Two-Node Quorum Loss" "Stop two NATS nodes and observe JetStream availability without quorum." "highly disruptive"
criterion "Select two distinct nodes and confirm outage."
criterion "Capture stream API availability while two nodes are down."
criterion "Restore both nodes and verify recovery."
show_connection

# JR-11: Two-node outage and expected quorum loss
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=disruptive"
section "STEP 1 - Baseline snapshot"; snapshot
section "STEP 2 - Confirm two-node outage"
info "This is intentionally disruptive. Do not run against shared or production environments."
confirm "Stop TWO NATS nodes. JetStream writes should fail without quorum." || { skip "Operator cancelled"; finish; exit 0; }
read -r -p "Enter first node to stop: " N1
read -r -p "Enter second node to stop: " N2
[[ "$N1" != "$N2" && " ${NODES[*]} " == *" $N1 "* && " ${NODES[*]} " == *" $N2 "* ]] || { fail "Invalid node selection"; finish; exit 1; }
stop_node "$N1"; stop_node "$N2"; sleep 5
section "STEP 3 - Observe node and JetStream status"; print_node_health
workload_publish "quorum-lost" failure || true
if nats_cli stream info "$STREAM" --json > "$REPORT_DIR/quorum-during.json" 2> "$REPORT_DIR/quorum-during.err"; then
  inconclusive "Stream info remained readable; read access alone does not prove write quorum."
else
  pass "Stream info request failed with two nodes down, consistent with quorum loss."
fi
section "STEP 4 - Restore both nodes"
start_node "$N1"; start_node "$N2"
wait_node "$N1" || true; wait_node "$N2" || true; sleep 20
if nats_cli stream info "$STREAM" --json > "$REPORT_DIR/quorum-after.json" 2> "$REPORT_DIR/quorum-after.err"; then
  RF="$(python3 - "$REPORT_DIR/quorum-after.json" <<'PY'
import json,sys
print((json.load(open(sys.argv[1])).get('config') or {}).get('num_replicas','unknown'))
PY
)"
  RSTAT="$(python3 - "$REPORT_DIR/quorum-after.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1])); r=(d.get('cluster') or {}).get('replicas') or []
print(f"{sum(1 for x in r if x.get('current') is True)}/{len(r)} current" if r else 'unknown')
PY
)"
  info "AFTER RESTORE: RF=$RF replica_status=$RSTAT"
  [[ "$RF" == 3 ]] && pass "Stream remains configured for RF=3 after restoration." || fail "Stream RF after restoration is '$RF'."
  [[ "$RSTAT" == "2/2 current" ]] && pass "Both replicas report current after quorum restoration." || inconclusive "Replica catch-up is not confirmed: $RSTAT."
else
  fail "Stream API did not recover after restoring both nodes."
fi
workload_publish "quorum-restored" success || true
section "FINAL HEALTH SNAPSHOT"; print_node_health; print_lb_status
finish
