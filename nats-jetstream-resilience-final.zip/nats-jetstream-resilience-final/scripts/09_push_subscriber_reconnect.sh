#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  set -o pipefail
  bash "$0" "$@" 2>&1 | tee -a "$REPORT_DIR/run.log"
  exit $?
fi
# Scenario: Push Subscriber Reconnect
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh and ensure PAYMENT_NOTIFICATIONS exists. Stop the notification subscriber, run this script to publish a marker, restart the subscriber, then verify reconnect and event receipt from subscriber evidence.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "09_push_subscriber_reconnect.sh" "Push Subscriber Reconnect" "Inspect durable notification consumer state around Java subscriber reconnect." "manual/java"
criterion "Capture baseline notification consumer state."
criterion "Java verifies reconnect and expected event IDs."
criterion "Capture consumer state after reconnect."
show_connection
info "CLI-only mode: workload_publish and workload_consumer_checkpoint are available; consumer delivery/ACK/business effects require separate CLI subscriber evidence."

# JR-09: Push subscriber disconnect/reconnect
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=manual"
section "STEP 1 - Baseline"; workload_consumer_checkpoint "$NOTIFICATION_CONSUMER" before || true
info "ACTION REQUIRED: stop only the Java notification process, publish events, then restart it."
read -r -p "Press Enter after restart and after the notification process has drained pending events..."
section "STEP 2 - Publish marker and inspect notification durable consumer"; workload_publish "push-reconnect-marker" success || true; workload_consumer_checkpoint "$NOTIFICATION_CONSUMER" after || true
inconclusive "Java client evidence is required to verify application-level acceptance."
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
