#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  set -o pipefail
  bash "$0" "$@" 2>&1 | tee -a "$REPORT_DIR/run.log"
  exit $?
fi
# Scenario: Stream Leader Failover
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh, then optionally 01_01_publish_verify.sh, then this script. This test injects leader failure and uses a CLI publish probe while the leader is down; inspect before/during/after evidence.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "02_stream_leader_failover.sh" "Stream Leader Failover" "Stop the actual stream leader, observe leader election, and restore the node." "disruptive"
criterion "Identify actual leader before stopping it."
criterion "Observe replacement leader while original leader is stopped."
criterion "Restore original node and capture replica status."
show_connection

# JR-02: Stream leader failure and recovery
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=disruptive"
section "STEP 1 - Identify current stream leader"
nats_cli stream info "$STREAM" --json > "$REPORT_DIR/stream-before.json" || { fail "Cannot inspect stream"; finish; exit 1; }
LEADER="$(python3 - "$REPORT_DIR/stream-before.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1])); print((d.get("cluster") or {}).get("leader",""))
PY
)"
printf 'STREAM_LEADER=%s\n' "$LEADER"
[[ -n "$LEADER" && "$LEADER" != "None" ]] || { fail "Could not identify stream leader; do not guess which node to stop"; finish; exit 1; }
section "STEP 2 - Confirm disruptive action"
confirm "This stops stream leader $LEADER and may interrupt publishing briefly." || { skip "Operator cancelled"; finish; exit 0; }
section "STEP 3 - Stop leader and probe through LB"
stop_node "$LEADER"
sleep 8
workload_publish "leader-down" success
section "STEP 4 - Inspect leader election and stream state"; print_node_health; nats_cli stream info "$STREAM" --json > "$REPORT_DIR/stream-during.json" 2> "$REPORT_DIR/stream-during.err" || inconclusive "Stream info unavailable during leader transition."
section "STEP 5 - Restore original node"; start_node "$LEADER"; wait_node "$LEADER"; sleep 10; print_node_health; print_lb_status
workload_replica_wait 60 || true
inconclusive "Leader transition still requires before/during leader comparison; consumer behavior not tested."
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
