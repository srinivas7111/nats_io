#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  set -o pipefail
  bash "$0" "$@" 2>&1 | tee -a "$REPORT_DIR/run.log"
  exit $?
fi
# FULL-FLOW GUIDE: RELATED FLOW: Run first before any scenario. It is read-only apart from creating PAYMENT_EVENTS if the stream is missing. Follow with 01_01_publish_verify.sh for a publish smoke test.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "01_baseline_infra.sh" "Baseline Infrastructure Validation" "Verify NATS nodes, HAProxy connectivity, and PAYMENT_EVENTS stream readiness." "safe"
criterion "All configured NATS nodes respond on monitoring endpoints."
criterion "HAProxy client path is reachable."
criterion "PAYMENT_EVENTS exists with file storage and RF=3."
criterion "Stream leader and replica status are captured."
preflight || { finish; exit 1; }
section "Baseline checks"
node_summary; NODE_RC=$?
[[ $NODE_RC -eq 0 ]] && pass "All NATS node monitoring endpoints respond." || fail "One or more NATS node monitoring endpoints are unavailable."
lb_summary; LB_RC=$?
[[ $LB_RC -eq 0 ]] && pass "HAProxy NATS client path is reachable." || fail "HAProxy NATS client path is unavailable."
if get_stream_json "$REPORT_DIR/${STREAM}-info.json" "$REPORT_DIR/${STREAM}-info.err"; then
  STORAGE="$(stream_value "$REPORT_DIR/${STREAM}-info.json" storage)"
  RF="$(stream_value "$REPORT_DIR/${STREAM}-info.json" replicas_configured)"
  LEADER="$(stream_value "$REPORT_DIR/${STREAM}-info.json" leader)"
  RSTAT="$(stream_value "$REPORT_DIR/${STREAM}-info.json" replica_status)"
  _emit "STREAM: $STREAM | storage=$STORAGE | RF=$RF | leader=$LEADER | replicas=$RSTAT"
  [[ "$STORAGE" == file ]] && pass "Stream storage is file." || fail "Expected file storage; got '$STORAGE'."
  [[ "$RF" == 3 ]] && pass "Stream replication factor is 3." || fail "Expected RF=3; got '$RF'."
  [[ -n "$LEADER" && "$LEADER" != unknown && "$LEADER" != None ]] && pass "Stream leader identified: $LEADER." || fail "Stream leader is unavailable."
  [[ "$RSTAT" == "2/2 current" ]] && pass "Both stream replicas report current." || inconclusive "Replica status is '$RSTAT'; inspect JSON evidence."
else fail "PAYMENT_EVENTS stream information is unavailable."; fi
info "Consumer delivery, cursors, and ACK verification are delegated to Java clients."
finish
