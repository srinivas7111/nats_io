#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  set -o pipefail
  bash "$0" "$@" 2>&1 | tee -a "$REPORT_DIR/run.log"
  exit $?
fi
# Scenario: HAProxy Process Failure and Recovery
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh first. This stops HAProxy itself and validates client-path failure/recovery; do not run while other tests or users depend on this endpoint.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "14_haproxy_process_failure.sh" "HAProxy Process Failure and Recovery" "Stop HAProxy, confirm the client path fails, then restore it." "disruptive"
criterion "Client path fails while HAProxy is stopped."
criterion "HAProxy restarts and client path recovers."
criterion "Stream is readable after recovery."
show_connection

# JR-14: HAProxy process/container failure
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
section "STEP 1 - Capture baseline"
print_node_health
print_lb_status
if ! is_running "$LB_CONTAINER"; then fail "HAProxy is not running at baseline."; finish; exit 1; fi
confirm "Stop HAProxy container $LB_CONTAINER. The client endpoint should become unavailable." || { skip "Operator cancelled"; finish; exit 0; }
section "STEP 2 - Stop HAProxy and verify expected client-path loss"
if stop_lb; then pass "HAProxy container stopped."; else finish; exit 1; fi
sleep 3
if nats_cli server check connection > "$REPORT_DIR/lb-during.out" 2> "$REPORT_DIR/lb-during.err"; then
  fail "NATS client path remained reachable while HAProxy was stopped."
else
  pass "NATS client path was unavailable while HAProxy was stopped."
fi
section "STEP 3 - Restore HAProxy and verify recovery"
if start_lb; then
  sleep 2
  if nats_cli server check connection > "$REPORT_DIR/lb-after.out" 2> "$REPORT_DIR/lb-after.err"; then pass "NATS client path recovered after HAProxy restart."; else fail "NATS client path did not recover after HAProxy restart."; fi
else
  fail "Could not restart HAProxy; manual recovery may be required."
fi
print_node_health
if nats_cli stream info "$STREAM" --json > "$REPORT_DIR/stream-after.json" 2> "$REPORT_DIR/stream-after.err"; then pass "Stream state is readable after HAProxy recovery."; else fail "Stream state is not readable after HAProxy recovery."; fi

finish
