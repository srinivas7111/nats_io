#!/usr/bin/env bash
# Shared helpers for the Payment Factory NATS/JetStream resilience suite.
set -uo pipefail
LB_HOST="${LB_HOST:-nats.local.test}"
LB_PORT="${LB_PORT:-4222}"
LB_CONTAINER="${LB_CONTAINER:-nats-lb}"
LB_STATS_URL="${LB_STATS_URL:-http://localhost:8404/stats}"
NETWORK="${NETWORK:-nats-net}"
NATS_BOX_IMAGE="${NATS_BOX_IMAGE:-docker.io/natsio/nats-box:latest}"
STREAM="${STREAM:-PAYMENT_EVENTS}"
PROCESSOR_CONSUMER="${PROCESSOR_CONSUMER:-PAYMENT_PROCESSORS}"
NOTIFICATION_CONSUMER="${NOTIFICATION_CONSUMER:-PAYMENT_NOTIFICATIONS}"
SUBJECT="${SUBJECT:-payment.events.created}"
NODES_CSV="${NODES_CSV:-nats-1 nats-2 nats-3}"
read -r -a NODES <<< "$NODES_CSV"
REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-$(date +%Y%m%d-%H%M%S)}"
mkdir -p "$REPORT_DIR"
PASS_COUNT=0; FAIL_COUNT=0; WARN_COUNT=0; SKIP_COUNT=0; INCONCLUSIVE_COUNT=0
RUN_LOG="$REPORT_DIR/run.log"
exec > >(tee -a "$RUN_LOG") 2>&1

section(){ printf '\n\n============================================================\nSTEP: %s\n============================================================\n' "$*"; }
info(){ printf 'INFO: %s\n' "$*"; }
pass(){ printf 'SUCCESS: %s\n' "$*"; PASS_COUNT=$((PASS_COUNT+1)); }
fail(){ printf 'FAIL: %s\n' "$*"; FAIL_COUNT=$((FAIL_COUNT+1)); }
warn(){ printf 'WARN: %s\n' "$*"; WARN_COUNT=$((WARN_COUNT+1)); }
skip(){ printf 'SKIP: %s\n' "$*"; SKIP_COUNT=$((SKIP_COUNT+1)); }
inconclusive(){ printf 'INCONCLUSIVE: %s\n' "$*"; INCONCLUSIVE_COUNT=$((INCONCLUSIVE_COUNT+1)); }
begin_test(){
  local script="$1" scenario="$2" objective="$3" mode="${4:-safe}"
  printf '\n========== %s :: %s ==========\n' "$script" "$scenario"
  printf 'TEST OBJECTIVE: %s\n' "$objective"
  printf 'MODE: %s\n' "$mode"
  printf 'RUN_ID: %s\n' "${RUN_ID:-unspecified}"
  printf 'TIMESTAMP: %s\n' "$(date "+%Y-%m-%dT%H:%M:%S%z")"
}
criterion(){ printf 'ACCEPTANCE CRITERION: %s\n' "$*"; }
show_connection(){
  info "Client endpoint: nats://${LB_HOST}:${LB_PORT} (host); in-network endpoint nats://${LB_CONTAINER}:${LB_PORT}"
  info "Nodes: ${NODES[*]} | Stream: $STREAM | Subject: $SUBJECT"
  info "Consumers: $PROCESSOR_CONSUMER, $NOTIFICATION_CONSUMER"
  info "Evidence directory: $REPORT_DIR"
}
node_summary(){
  local n rc=0
  for n in "${NODES[@]}"; do
    if is_running "$n" && node_http "$n" /varz >/dev/null 2>&1; then
      info "$n: running, monitoring endpoint healthy"
    else
      warn "$n: not running or monitoring endpoint unavailable"; rc=1
    fi
  done
  return "$rc"
}
lb_summary(){
  local rc=0
  if curl -fsS --max-time 3 "$LB_STATS_URL" -o "$REPORT_DIR/lb-stats.txt"; then
    info "HAProxy stats endpoint: reachable ($LB_STATS_URL)"
  else
    warn "HAProxy stats endpoint unavailable ($LB_STATS_URL)"; rc=1
  fi
  if nats_cli server check connection >"$REPORT_DIR/lb-connection.out" 2>"$REPORT_DIR/lb-connection.err"; then
    info "NATS client path via ${LB_CONTAINER}:${LB_PORT}: reachable"
  else
    warn "NATS client path via ${LB_CONTAINER}:${LB_PORT}: unavailable"; rc=1
  fi
  return "$rc"
}
get_stream_json(){
  local dest="$1" err="${2:-${1%.json}.err}"
  nats_cli stream info "$STREAM" --json >"$dest" 2>"$err" || return 1
  python3 -m json.tool "$dest" >/dev/null 2>&1
}
stream_value(){
  local file="$1" field="$2"
  python3 - "$file" "$field" <<'PYVALUE'
import json,sys
try:
 d=json.load(open(sys.argv[1])); f=sys.argv[2]
 cfg=d.get('config') or {}; state=d.get('state') or {}; cl=d.get('cluster') or {}; reps=cl.get('replicas') or []
 if f=='storage': v=cfg.get('storage','unknown')
 elif f=='replicas_configured': v=cfg.get('num_replicas','unknown')
 elif f=='leader': v=cl.get('leader','unknown')
 elif f=='messages': v=state.get('messages','unknown')
 elif f=='last_seq': v=state.get('last_seq','unknown')
 elif f=='replica_names': v=', '.join(str(x.get('name','?')) for x in reps) or 'none reported'
 elif f=='replica_status': v=f"{sum(x.get('current') is True for x in reps)}/{len(reps)} current" if reps else 'unknown'
 else: v='unknown'
 print(v)
except Exception: print('unknown')
PYVALUE
}

cmd(){ printf '\nCOMMAND:'; printf ' %q' "$@"; printf '\n'; }
need(){ command -v "$1" >/dev/null 2>&1 || { echo "ERROR: required command '$1' not found"; exit 2; }; }
is_running(){ [[ "$(podman inspect -f '{{.State.Running}}' "$1" 2>/dev/null || true)" == "true" ]]; }
node_http(){ podman exec "$1" sh -c "wget -qO- 'http://127.0.0.1:8222$2'" 2>/dev/null; }
nats_cli(){ podman run --rm --network "$NETWORK" "$NATS_BOX_IMAGE" nats --server "nats://${LB_CONTAINER}:${LB_PORT}" --timeout "${NATS_TIMEOUT:-5s}" "$@"; }
nats_cli_direct(){ local node="$1"; shift; podman run --rm --network "$NETWORK" "$NATS_BOX_IMAGE" nats --server "nats://${node}:4222" --timeout "${NATS_TIMEOUT:-5s}" "$@"; }
ensure_stream(){
  section "ENSURE STREAM EXISTS"
  info "Required stream: $STREAM | subject: $SUBJECT | storage: file | replicas: 3"
  if nats_cli stream info "$STREAM" --json > "$REPORT_DIR/${STREAM}-ensure-before.json" 2>"$REPORT_DIR/${STREAM}-ensure-before.err"; then
    pass "Stream '$STREAM' already exists; preserving it without modifying its configuration"
    return 0
  fi

  warn "Stream '$STREAM' does not exist or cannot be inspected. Attempting to create it."
  info "Creation defaults: subject=$SUBJECT, file storage, replicas=3, limits retention"
  cmd podman run --rm --network "$NETWORK" "$NATS_BOX_IMAGE" nats --server "nats://${LB_CONTAINER}:${LB_PORT}" stream add "$STREAM" --subjects "$SUBJECT" --storage file --replicas 3 --retention limits --defaults
  if podman run --rm --network "$NETWORK" "$NATS_BOX_IMAGE" nats --server "nats://${LB_CONTAINER}:${LB_PORT}" --timeout "${NATS_TIMEOUT:-5s}" stream add "$STREAM" --subjects "$SUBJECT" --storage file --replicas 3 --retention limits --defaults; then
    sleep 2
    if nats_cli stream info "$STREAM" --json > "$REPORT_DIR/${STREAM}-ensure-after.json" 2>"$REPORT_DIR/${STREAM}-ensure-after.err"; then
      pass "Created and verified stream '$STREAM'"
      return 0
    fi
  fi

  fail "Could not create/verify stream '$STREAM'. Check NATS CLI flags, permissions, and JetStream availability."
  cat "$REPORT_DIR/${STREAM}-ensure-before.err" "$REPORT_DIR/${STREAM}-ensure-after.err" 2>/dev/null || true
  return 1
}
preflight(){
  need podman; need curl; need python3
  info "Client endpoint: nats://${LB_HOST}:${LB_PORT} (host); in-network endpoint nats://${LB_CONTAINER}:${LB_PORT}"
  info "Nodes: ${NODES[*]} | Stream: $STREAM | Consumers: $PROCESSOR_CONSUMER, $NOTIFICATION_CONSUMER"
  info "Evidence directory: $REPORT_DIR"
  if ! podman image exists "$NATS_BOX_IMAGE"; then
    info "Pulling CLI image $NATS_BOX_IMAGE"; cmd podman pull "$NATS_BOX_IMAGE"; podman pull "$NATS_BOX_IMAGE" || { fail "Could not pull NATS CLI image"; return 1; }
  fi
  ensure_stream || return 1
}
print_node_health(){
  section "NODE HEALTH AND SERVER STATUS"
  local node running varz jsz
  for node in "${NODES[@]}"; do
    running="$(podman inspect -f '{{.State.Running}}' "$node" 2>/dev/null || echo missing)"
    printf '\nNODE=%s CONTAINER_RUNNING=%s\n' "$node" "$running"
    if [[ "$running" == "true" ]]; then
      varz="$(node_http "$node" /varz || true)"
      jsz="$(node_http "$node" '/jsz?streams=true&consumers=true' || true)"
      if [[ -n "$varz" ]]; then
        printf '%s' "$varz" > "$REPORT_DIR/${node}-varz.json"
        python3 - "$varz" <<'PY'
import json,sys
try:
 d=json.loads(sys.argv[1])
 print("  server_name:",d.get("server_name","?"))
 print("  server_id:",d.get("server_id","?"))
 print("  connections:",d.get("connections","?"))
 print("  in_msgs/out_msgs:",d.get("in_msgs","?"),"/",d.get("out_msgs","?"))
 print("  uptime:",d.get("uptime","?"))
except Exception: print("  varz response received (not valid JSON)")
PY
      else
        warn "$node is running but monitoring endpoint :8222/varz did not respond"
      fi
      if [[ -n "$jsz" ]]; then
        printf '%s' "$jsz" > "$REPORT_DIR/${node}-jsz.json"
        python3 - "$jsz" <<'PY'
import json,sys
try:
 d=json.loads(sys.argv[1])
 print("  jetstream: enabled=",d.get("disabled",None) is False or d.get("config",{}).get("max_memory",None) is not None)
 print("  streams:",d.get("streams","?")," consumers:",d.get("consumers","?"))
 print("  meta leader:",(d.get("meta",{}) or {}).get("leader","?"))
except Exception: print("  jsz response received (not valid JSON)")
PY
      else
        warn "$node JetStream monitoring endpoint did not respond or JetStream is disabled"
      fi
    else
      printf '  STATUS=DOWN_OR_MISSING\n'
    fi
  done
}
print_lb_status(){
  section "LOAD BALANCER STATUS"
  if curl -fsS --max-time 3 "$LB_STATS_URL" -o "$REPORT_DIR/lb-stats.txt"; then
    printf 'LB_STATS=UP URL=%s\n' "$LB_STATS_URL"
    # Print a compact HAProxy stats view if CSV stats endpoint is configured.
    python3 - "$REPORT_DIR/lb-stats.txt" <<'PY'
import sys
s=open(sys.argv[1],errors="replace").read()
lines=[x for x in s.splitlines() if x and not x.startswith("#")]
if not lines:
 print("  Stats endpoint reachable; no CSV rows parsed (may be HTML or custom format).")
else:
 for line in lines[:30]:
  c=line.split(",")
  if len(c)>17 and c[0].strip().isdigit():
   print("  proxy=%s server=%s status=%s sessions=%s" % (c[0],c[1],c[17],c[4]))
PY
  else
    printf 'LB_STATS=UNREACHABLE URL=%s\n' "$LB_STATS_URL"
    warn "Could not read HAProxy stats URL; this does not by itself prove the NATS data endpoint is down"
  fi
  if nats_cli server check connection >/dev/null 2>&1; then
    pass "NATS client connection through ${LB_CONTAINER}:${LB_PORT} works"
  else
    fail "NATS client connection through ${LB_CONTAINER}:${LB_PORT} failed"
  fi
}
print_stream_consumer_status(){
  section "STREAM COUNT, STREAM REPLICAS AND CONSUMER CURSORS"
  local out
  if out="$(nats_cli stream ls 2>&1)"; then
    printf '%s\n' "$out" | tee "$REPORT_DIR/stream-list.txt"
    # Prefer the CLI's structured output. Do not count rendered table lines:
    # tables can wrap, include headers, or omit rows depending on terminal width.
    if nats_cli stream ls --json > "$REPORT_DIR/stream-list.json" 2>"$REPORT_DIR/stream-list-json.err"; then
      python3 - "$REPORT_DIR/stream-list.json" <<'PYCOUNT'
import json,sys
try:
    data=json.load(open(sys.argv[1]))
    if isinstance(data, list):
        streams=data
    elif isinstance(data, dict):
        streams=data.get("streams")
        if streams is None:
            streams=data.get("data")
        if streams is None and isinstance(data.get("config"), dict):
            streams=[data]
        if streams is None:
            streams=[]
    else:
        streams=[]
    print("STREAM_COUNT=%d" % len(streams))
    names=[]
    for item in streams:
        if isinstance(item, dict):
            name=item.get("name") or (item.get("config") or {}).get("name") or "?"
        else:
            name=str(item)
        names.append(str(name))
    print("STREAM_NAMES=" + (", ".join(names) if names else "(none returned)"))
except Exception as exc:
    print("STREAM_COUNT=UNKNOWN")
    print("STREAM_COUNT_PARSE_ERROR:", exc)
PYCOUNT
    else
      warn "NATS CLI JSON stream listing is unavailable; exact stream count omitted"
      cat "$REPORT_DIR/stream-list-json.err" 2>/dev/null || true
    fi
    if nats_cli stream info "$STREAM" --json > "$REPORT_DIR/${STREAM}-info.json" 2>"$REPORT_DIR/${STREAM}-info.err"; then
      python3 - "$REPORT_DIR/${STREAM}-info.json" <<'PY'
import json,sys
try:
 d=json.load(open(sys.argv[1]))
 cfg=d.get("config",{}) or {}
 state=d.get("state",{}) or {}
 cl=d.get("cluster",{}) or {}
 print("STREAM_NAME:",cfg.get("name",d.get("name","?")))
 print("STREAM_SUBJECTS:",cfg.get("subjects","?"))
 print("STREAM_STORAGE:",cfg.get("storage","?"),"REPLICAS_CONFIGURED:",cfg.get("num_replicas","?"))
 print("STREAM_MESSAGES:",state.get("messages","?"),"BYTES:",state.get("bytes","?"),"FIRST_SEQ:",state.get("first_seq","?"),"LAST_SEQ:",state.get("last_seq","?"))
 print("STREAM_LEADER:",cl.get("leader","?"),"STREAM_REPLICAS:",json.dumps(cl.get("replicas",[])))
except Exception as e: print("Could not parse stream info JSON:",e)
PY
    else warn "Could not read stream '$STREAM'; check name/auth/JetStream setup"; cat "$REPORT_DIR/${STREAM}-info.err"; fi
  else fail "Unable to list streams through load balancer"; printf '%s\n' "$out"; fi
  for c in "$PROCESSOR_CONSUMER" "$NOTIFICATION_CONSUMER"; do
    if nats_cli consumer info "$STREAM" "$c" --json > "$REPORT_DIR/${c}-info.json" 2>"$REPORT_DIR/${c}-info.err"; then
      printf '\nCONSUMER=%s\n' "$c"
      python3 - "$REPORT_DIR/${c}-info.json" <<'PY'
import json,sys
try:
 d=json.load(open(sys.argv[1]))
 cfg=d.get("config",{}) or {}; st=d.get("delivered",{}) or {}; ack=d.get("ack_floor",{}) or {}; cl=d.get("cluster",{}) or {}
 print("  durable:",cfg.get("durable_name",cfg.get("name","?")),"delivery:",cfg.get("deliver_subject","pull/none"))
 print("  delivered consumer/stream seq:",st.get("consumer_seq","?"),"/",st.get("stream_seq","?"))
 print("  ack floor consumer/stream seq:",ack.get("consumer_seq","?"),"/",ack.get("stream_seq","?"))
 print("  pending:",d.get("num_pending","?"),"ack_pending:",d.get("num_ack_pending","?"),"redelivered:",d.get("num_redelivered","?"))
 print("  consumer leader:",cl.get("leader","?"),"consumer replicas:",json.dumps(cl.get("replicas",[])))
except Exception as e: print("  Could not parse consumer JSON:",e)
PY
    else
      warn "Consumer '$c' not found/readable (this is expected before setup); details in $REPORT_DIR/${c}-info.err"
    fi
  done
}
snapshot(){ print_node_health; print_lb_status; print_stream_consumer_status; }
confirm(){
  printf '\nWARNING: %s\nType YES to proceed: ' "$1"; read -r ans
  [[ "$ans" == "YES" ]]
}
stop_node(){
  local n="$1"
  if [[ ! " ${NODES[*]} " == *" $n "* ]]; then fail "Node '$n' is not in NODES_CSV"; return 1; fi
  if ! is_running "$n"; then warn "$n is already stopped"; return 0; fi
  cmd podman stop "$n"; podman stop "$n"
}
start_node(){
  local n="$1"
  cmd podman start "$n"; podman start "$n"
}
wait_node(){
  local n="$1" i
  for i in $(seq 1 30); do
    if is_running "$n" && node_http "$n" /varz >/dev/null 2>&1; then pass "$n monitoring endpoint is responding"; return 0; fi
    sleep 2
  done
  fail "$n did not become healthy within 60 seconds"; return 1
}

stop_lb(){
  if ! is_running "$LB_CONTAINER"; then warn "HAProxy container $LB_CONTAINER is already stopped"; return 1; fi
  cmd podman stop "$LB_CONTAINER"; podman stop "$LB_CONTAINER"
}
start_lb(){
  cmd podman start "$LB_CONTAINER"; podman start "$LB_CONTAINER"
}

publish_probe(){
  local id="${1:-probe-$(date +%s)}"
  cmd nats_cli pub "$SUBJECT" "$id"
  nats_cli pub "$SUBJECT" "$id"
}
finish(){
  section "FINAL RESULT"
  local result="PASS" rc=0
  if (( FAIL_COUNT > 0 )); then result="FAIL"; rc=1
  elif (( INCONCLUSIVE_COUNT > 0 )); then result="INCONCLUSIVE"; rc=2
  fi
  printf 'RESULT=%s PASS=%d FAIL=%d INCONCLUSIVE=%d WARN=%d SKIP=%d\n' "$result" "$PASS_COUNT" "$FAIL_COUNT" "$INCONCLUSIVE_COUNT" "$WARN_COUNT" "$SKIP_COUNT"
  printf 'REPORT_DIR=%s\nLOG=%s\n' "$REPORT_DIR" "$RUN_LOG"
  {
    printf 'RESULT=%s\nPASS=%d\nFAIL=%d\nINCONCLUSIVE=%d\nWARN=%d\nSKIP=%d\n' "$result" "$PASS_COUNT" "$FAIL_COUNT" "$INCONCLUSIVE_COUNT" "$WARN_COUNT" "$SKIP_COUNT"
  } > "$REPORT_DIR/summary.txt"
  return "$rc"
}
trap 'rc=$?; printf "EXIT_CODE=%s\n" "$rc" >> "$REPORT_DIR/summary.txt" 2>/dev/null || true' EXIT

# Shared CLI workload helpers for the no-Java demo phase.
# Related helpers: workload_publish, workload_publish_batch, workload_stream_state,
# workload_replica_wait, workload_consumer_checkpoint, workload_consumer_nonregression.
# These helpers do not simulate subscriber business logic or prove business idempotency.
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/workload_helpers.sh"
