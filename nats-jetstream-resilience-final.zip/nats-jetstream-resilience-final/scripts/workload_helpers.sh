#!/usr/bin/env bash
# CLI-only workload helpers for temporary use until Java clients are available.
# Source after lib.sh. No consumer/business side effects are claimed by these helpers.

workload_stream_state() {
  local label="$1" file="$REPORT_DIR/workload-${label}-stream.json"
  if ! nats_cli stream info "$STREAM" --json >"$file" 2>"${file%.json}.err"; then
    fail "Unable to capture stream state ($label)"; return 1
  fi
  python3 - "$file" "$label" <<'PY'
import json,sys
j=json.load(open(sys.argv[1])); s=j.get('state') or {}; c=j.get('cluster') or {}
r=c.get('replicas') or []
print(f"{sys.argv[2]}: messages={s.get('messages','?')} last_seq={s.get('last_seq','?')} leader={c.get('leader','?')} replicas_current={sum(x.get('current') is True for x in r)}/{len(r)}")
PY
}

# Publishes using the NATS CLI JetStream publish mode and parses the PubAck.
# A successful core NATS publish alone is not accepted as publish-verification evidence.
workload_publish() {
  local phase="${1:-normal}" expect="${2:-success}" event_id payload output_file ack_file rc=0
  event_id="${EVENT_ID:-${RUN_ID}-${phase}-$(date +%s)-${RANDOM}}"
  payload="$(python3 - "$event_id" "$phase" <<'PY'
import json,sys
print(json.dumps({'eventId':sys.argv[1],'type':'payment.created','phase':sys.argv[2],'source':'cli-resilience-demo'}))
PY
)"
  output_file="$REPORT_DIR/workload-${phase}-publish.out"
  ack_file="$REPORT_DIR/workload-${phase}-ack.json"
  printf '%s\n' "$payload" >"$REPORT_DIR/workload-${phase}-payload.json"
  info "CLI workload: phase=$phase eventId=$event_id expected=$expect"

  # JetStream-aware publish; a core NATS publish is not sufficient evidence.
  # NATS CLI versions may use --js or --jetstream; override via NATS_JS_FLAG if needed.
  local js_flag="${NATS_JS_FLAG:---js}"
  if nats_cli pub "$js_flag" "$SUBJECT" "$payload" >"$output_file" 2>"$REPORT_DIR/workload-${phase}-publish.err"; then
    if python3 - "$output_file" "$ack_file" "$STREAM" <<'PYACK'
import json,re,sys
text=open(sys.argv[1],errors='replace').read(); expected=sys.argv[3]; obj=None
for line in text.splitlines():
 line=line.strip(); candidates=[line]
 if '{' in line: candidates.append(line[line.find('{'):])
 for candidate in candidates:
  try:
   x=json.loads(candidate)
   if isinstance(x,dict) and ('stream' in x or 'seq' in x or 'error' in x): obj=x; break
  except Exception: pass
 if obj is not None: break
if obj is not None:
 stream=obj.get('stream') or obj.get('stream_name'); seq=obj.get('seq') or obj.get('sequence')
 if not obj.get('error') and stream==expected and isinstance(seq,int):
  json.dump({'stream':stream,'seq':seq,'duplicate':obj.get('duplicate',False)},open(sys.argv[2],'w'),indent=2)
  print('JetStream PubAck: stream=%s seq=%s' % (stream,seq)); sys.exit(0)
# NATS CLI often prints a text acknowledgement, e.g. Published to stream "X" with sequence N.
patterns=[r"Published to stream ['\"]([^'\"]+)['\"] with sequence (\d+)",
          r"stream[=: ]+['\"]?([A-Za-z0-9_-]+)['\"]?.*?(?:sequence|seq)[=: ]+(\d+)"]
for pat in patterns:
 m=re.search(pat,text,re.I|re.S)
 if m and m.group(1)==expected:
  stream,seq=m.group(1),int(m.group(2))
  json.dump({'stream':stream,'seq':seq,'duplicate':False,'ack_format':'text'},open(sys.argv[2],'w'),indent=2)
  print('JetStream PubAck: stream=%s seq=%s (parsed CLI text)' % (stream,seq)); sys.exit(0)
sys.exit(1)
PYACK
    then
      if [[ "$expect" == success ]]; then pass "JetStream acknowledged event ($phase)"; return 0; fi
      fail "Unexpected publish success during $phase (expected failure)"; return 1
    fi
    if [[ "$expect" == failure ]]; then
      pass "No valid JetStream PubAck was observed during $phase (expected unavailable)"
      return 0
    fi
    fail "Publish command returned but a valid JetStream PubAck could not be parsed ($phase); inspect $output_file"
    return 1
  else
    rc=$?
    if [[ "$expect" == failure ]]; then pass "JetStream publish unavailable during $phase as expected (exit=$rc)"; return 0; fi
    fail "JetStream publish failed during $phase (exit=$rc)"; return 1
  fi
}

# Backward-compatible name used by scenario scripts.
workload_consumer_state() { workload_consumer_checkpoint "$@"; }

workload_consumer_checkpoint() {
  local durable="$1" phase="$2" dest="$REPORT_DIR/consumer-${durable}-${phase}.json"
  if ! nats_cli consumer info "$STREAM" "$durable" --json >"$dest" 2>"${dest%.json}.err"; then
    inconclusive "Cannot inspect $durable ($phase): durable not provisioned or unavailable"
    return 1
  fi
  python3 - "$dest" "$durable" "$phase" <<'PYCON'
import json,sys
j=json.load(open(sys.argv[1])); d=j.get('delivered') or {}; a=j.get('ack_floor') or {}
print(f"CONSUMER {sys.argv[2]} [{sys.argv[3]}]: delivered={d.get('stream_seq','?')} ack_floor={a.get('stream_seq','?')} pending={j.get('num_pending','?')} ack_pending={j.get('num_ack_pending','?')} redelivered={j.get('num_redelivered','?')}")
PYCON
}

# Verify a durable consumer's ACK floor did not regress. Does not claim delivery.
workload_consumer_nonregression() {
  local durable="$1" before="$2" after="$3"
  python3 - "$REPORT_DIR/consumer-${durable}-${before}.json" "$REPORT_DIR/consumer-${durable}-${after}.json" <<'PYCON'
import json,sys
try:
 b=json.load(open(sys.argv[1])); a=json.load(open(sys.argv[2]))
 for key in ('delivered','ack_floor'):
  x=(b.get(key) or {}).get('stream_seq'); y=(a.get(key) or {}).get('stream_seq')
  if not isinstance(x,int) or not isinstance(y,int) or y<x: raise ValueError(f'{key} unavailable or regressed: {x} -> {y}')
 print('Consumer cursor did not regress (not proof of processing)')
except Exception as e:
 print('Consumer cursor comparison failed:',e); sys.exit(1)
PYCON
}

# Publish a specified number of unique marker events; failure propagates.
workload_publish_batch() {
  local phase="$1" count="$2" i
  [[ "$count" =~ ^[1-9][0-9]*$ ]] || { fail 'Invalid publish batch count'; return 1; }
  for ((i=1;i<=count;i++)); do
    workload_publish "${phase}-${i}" success || return 1
  done
}

# Wait for the configured RF=3 stream to report both follower replicas current.
# This validates replication catch-up only; it does not prove application processing.
workload_replica_wait() {
  local seconds="${1:-60}" i file="$REPORT_DIR/workload-replica-wait.json"
  for ((i=0; i<seconds; i+=2)); do
    if nats_cli stream info "$STREAM" --json >"$file" 2>"${file%.json}.err" && python3 - "$file" <<'PYREPLICA'
import json,sys
try:
 d=json.load(open(sys.argv[1])); reps=(d.get('cluster') or {}).get('replicas') or []
 ok=len(reps)==2 and all(r.get('current') is True for r in reps)
 sys.exit(0 if ok else 1)
except Exception: sys.exit(1)
PYREPLICA
    then
      pass "Both stream replicas report current"
      return 0
    fi
    sleep 2
  done
  fail "Replica catch-up not confirmed within ${seconds}s"
  return 1
}
