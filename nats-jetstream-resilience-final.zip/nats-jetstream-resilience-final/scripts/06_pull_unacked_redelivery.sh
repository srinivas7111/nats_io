#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  set -o pipefail
  bash "$0" "$@" 2>&1 | tee -a "$REPORT_DIR/run.log"
  exit $?
fi
# Scenario: Pull Consumer Unacknowledged Redelivery
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh; ensure PAYMENT_PROCESSORS exists; then run this script. A real redelivery proof requires a pull subscriber to receive and intentionally withhold ACK; CLI snapshots alone are not sufficient.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "06_pull_unacked_redelivery.sh" "Pull Consumer Unacknowledged Redelivery" "Use Java clients to verify redelivery after a worker stops before ACK." "manual/java"
criterion "Capture baseline consumer state."
criterion "Java confirms same event ID is redelivered."
criterion "Java confirms ACK and idempotent processing."
show_connection
info "CLI-only mode: workload_publish and workload_consumer_checkpoint are available; consumer delivery/ACK/business effects require separate CLI subscriber evidence."

# JR-06: Pull worker crash before ACK and redelivery
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=manual"
section "STEP 1 - Capture baseline"; workload_consumer_checkpoint "$PROCESSOR_CONSUMER" before || true; workload_publish "unacked-marker" success || true
info "ACTION REQUIRED: configure Subscriber 1 to pause after receiving one event but before ACK; then terminate it."
info "Publish one uniquely identified event and verify Subscriber 2 receives it after AckWait expires."
read -r -p "After observing the redelivery, press Enter to capture state..."
section "STEP 2 - Inspect cursor, ACK pending, redelivery"; workload_consumer_checkpoint "$PROCESSOR_CONSUMER" after || true
inconclusive "Java client evidence is required to verify application-level acceptance."
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
