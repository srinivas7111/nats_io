#!/usr/bin/env bash
if [[ "${NATS_LOG_WRAPPED:-0}" != "1" ]]; then
  export NATS_LOG_WRAPPED=1
  RUN_ID="${RUN_ID:-nats-demo-$(date +%Y%m%d-%H%M%S)-$$}"
  REPORT_DIR="${REPORT_DIR:-./payment-factory-evidence-${RUN_ID}}"
  export RUN_ID REPORT_DIR
  mkdir -p "$REPORT_DIR"
  set -o pipefail
  bash "$0" "$@" 2>&1 | tee -a "$REPORT_DIR/run.log"
  exit $?
fi
# Scenario: Pull Consumer Cursor Resume
# FULL-FLOW GUIDE: RELATED FLOW: Run 01_baseline_infra.sh; ensure PAYMENT_PROCESSORS exists; then run this script. It captures cursor state and publishes a marker, but a CLI-only run cannot prove a subscriber restart or successful processing/ACK.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
begin_test "05_pull_cursor_resume.sh" "Pull Consumer Cursor Resume" "Use Java pull clients to verify durable cursor continuity across subscriber restart." "manual/java"
criterion "Capture PAYMENT_PROCESSORS state before and after Java restart."
criterion "Java evidence verifies cursor continuity and expected event IDs."
criterion "Capture consumer cursor before and after a marker publish; do not claim delivery or ACK from cursor snapshots alone."
show_connection
info "CLI-only mode: workload_publish and workload_consumer_checkpoint are available; consumer delivery/ACK/business effects require separate CLI subscriber evidence."

# JR-05: Pull durable cursor persistence after Java client restart
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
preflight || { finish; exit 1; }
info "MODE=manual"
section "STEP 1 - Capture consumer cursor baseline"; workload_consumer_checkpoint "$PROCESSOR_CONSUMER" before || true
info "ACTION REQUIRED: stop and restart Subscriber 1 Java process only; do not delete its durable consumer."
read -r -p "After restarting Subscriber 1, press Enter to continue..."
section "STEP 2 - Publish a marker event"; workload_publish "cursor-marker" success || true
section "STEP 3 - Inspect durable cursor and pending counts"; workload_consumer_checkpoint "$PROCESSOR_CONSUMER" after || true; workload_consumer_nonregression "$PROCESSOR_CONSUMER" before after || inconclusive "Consumer cursor comparison unavailable"
inconclusive "Java client evidence is required to verify application-level acceptance."
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
