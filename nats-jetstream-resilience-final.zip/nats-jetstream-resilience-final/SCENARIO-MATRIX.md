# NATS JetStream resilience scenario matrix

| ID | Scenario | Script | Main CLI evidence | CLI-only limitation |
|---|---|---|---|---|
| JR-01 | Baseline infrastructure | `01_baseline_infra.sh` | Node monitoring, HAProxy client path, stream storage/RF, leader/replicas | Does not prove app publish/consume |
| JR-01A | Baseline publish verification | `01_01_publish_verify.sh` | JetStream PubAck, event ID, sequence, before/after stream state | No consumer processing assertion |
| JR-02 | Stream leader failure | `02_stream_leader_failover.sh` | Leader before/during/after, publish probe, replica state | Subscriber processing not proven |
| JR-03 | Follower failure | `03_follower_failure_recovery.sh` | Node outage, publish probe, recovery state | Replica catch-up must be explicitly confirmed |
| JR-04 | Node rejoin/catch-up | `04_stream_rejoin_catchup.sh` | Marker sequence and post-restart replica status | Current replicas do not prove consumer processing |
| JR-05 | Pull cursor resume | `05_pull_cursor_resume.sh` | Durable delivered/ACK floor/pending snapshots | No subscriber restart/processing proof |
| JR-06 | Pull unacked redelivery | `06_pull_unacked_redelivery.sh` | Durable pending/redelivery counters | Requires a subscriber to withhold ACK and observe same event ID |
| JR-07 | Pull consumer leader failover | `07_pull_consumer_leader_failover.sh` | Consumer cursor and NATS node recovery | No delivery/ACK continuity proof |
| JR-08 | Push consumer offline catch-up | `08_push_cursor_offline_catchup.sh` | Marker PubAcks and durable cursor snapshot | Must verify actual notification event IDs after reconnect |
| JR-09 | Push subscriber reconnect | `09_push_subscriber_reconnect.sh` | Marker PubAck and consumer snapshot | Reconnect and receipt need subscriber evidence |
| JR-10 | Push consumer leader failover | `10_push_consumer_leader_failover.sh` | Consumer cursor and NATS node recovery | Notification processing/ACK not proven |
| JR-11 | Two-node quorum loss | `11_two_node_quorum_loss.sh` | Expected publish unavailability and recovery snapshots | Exact quorum behavior depends on stream/cluster configuration |
| JR-12 | Quorum restoration | `12_quorum_restoration.sh` | Node health, publish PubAck, replica state | Does not prove app-level processing |
| JR-13 | HAProxy backend failure | `13_haproxy_backend_failure.sh` | Backend/node status and publish probe | Confirm backend selection from HAProxy stats if available |
| JR-14 | HAProxy process failure | `14_haproxy_process_failure.sh` | Client path unavailable during stop and available after restart | Does not validate client reconnect behavior beyond CLI probe |
| JR-15 | Duplicate/idempotency | `15_duplicate_idempotency.sh` | Marker and consumer snapshots | Exactly-once business side effect cannot be proven by CLI only |
| JR-16 | End-to-end one-node failure | `16_end_to_end_one_node_failure.sh` | Publish probe, node/stream/consumer snapshots | Full end-to-end requires event-ID reconciliation from subscriber harness |

## Result contract

- `PASS`: all mandatory, script-verifiable acceptance criteria succeeded.
- `FAIL`: a mandatory criterion failed.
- `INCONCLUSIVE`: required behavior cannot be established with available evidence.
- `WARN` and `SKIP` are never treated as PASS.

Consumer cursor values, pending counts, and redelivery counters are supporting evidence; they do not independently prove a subscriber received or processed a particular event.
