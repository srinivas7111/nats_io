#!/usr/bin/env bash
# Static validation only. This does not connect to or disrupt a NATS environment.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPTS="$ROOT/scripts"
errors=0

printf 'NATS JetStream suite validation\n'
printf 'Root: %s\n\n' "$ROOT"

for f in "$SCRIPTS"/*.sh; do
  if bash -n "$f"; then
    printf 'PASS syntax: %s\n' "${f##*/}"
  else
    printf 'FAIL syntax: %s\n' "${f##*/}"
    errors=$((errors+1))
  fi
done

for f in lib.sh workload_helpers.sh; do
  if [[ -s "$SCRIPTS/$f" ]]; then printf 'PASS helper present: %s\n' "$f"; else printf 'FAIL helper missing: %s\n' "$f"; errors=$((errors+1)); fi
done

expected=(01_baseline_infra.sh 01_01_publish_verify.sh 02_stream_leader_failover.sh 03_follower_failure_recovery.sh 04_stream_rejoin_catchup.sh 05_pull_cursor_resume.sh 06_pull_unacked_redelivery.sh 07_pull_consumer_leader_failover.sh 08_push_cursor_offline_catchup.sh 09_push_subscriber_reconnect.sh 10_push_consumer_leader_failover.sh 11_two_node_quorum_loss.sh 12_quorum_restoration.sh 13_haproxy_backend_failure.sh 14_haproxy_process_failure.sh 15_duplicate_idempotency.sh 16_end_to_end_one_node_failure.sh)
for f in "${expected[@]}"; do
  if [[ -f "$SCRIPTS/$f" ]]; then
    if grep -q 'FULL-FLOW GUIDE:' "$SCRIPTS/$f"; then printf 'PASS scenario + flow comment: %s\n' "$f"; else printf 'FAIL missing flow comment: %s\n' "$f"; errors=$((errors+1)); fi
  else printf 'FAIL missing scenario script: %s\n' "$f"; errors=$((errors+1)); fi
done

for fn in workload_publish workload_publish_batch workload_stream_state workload_replica_wait workload_consumer_checkpoint workload_consumer_nonregression; do
  if grep -q "^${fn}()" "$SCRIPTS/workload_helpers.sh"; then printf 'PASS workload helper: %s\n' "$fn"; else printf 'FAIL workload helper missing: %s\n' "$fn"; errors=$((errors+1)); fi
done

printf '\nScenario scripts expected: %s\n' "${#expected[@]}"
if (( errors == 0 )); then printf 'VALIDATION RESULT: PASS (static checks only)\n'; exit 0; else printf 'VALIDATION RESULT: FAIL (%s issue(s))\n' "$errors"; exit 1; fi
