# Run order and related-script guide

## General flow

1. `01_baseline_infra.sh` — run first to check the cluster, HAProxy client path, stream configuration, leader, and replicas.
2. `01_01_publish_verify.sh` — run once as the standalone JetStream publish smoke test. It adds one message to `PAYMENT_EVENTS`.
3. Run only the scenario(s) relevant to the behavior you want to demonstrate. Each scenario has its own CLI publish marker where required; you do not need to rerun the standalone smoke test before every scenario.
4. Run `01_baseline_infra.sh` after disruptive scenarios to confirm the environment has returned to baseline.

## Scenario flows

| Script | Related scripts / prerequisites | What to execute and what it proves |
|---|---|---|
| `01_baseline_infra.sh` | First for all flows | Checks NATS node monitoring, HAProxy client path, stream storage/RF, leader and replica status. Does not publish intentionally. It may create the stream if missing. |
| `01_01_publish_verify.sh` | Run after baseline | Publishes one unique event via JetStream-aware CLI and checks PubAck plus stream progression. Standalone smoke test, not a failover test. |
| `02_stream_leader_failover.sh` | `01_baseline_infra.sh`; optional `01_01_publish_verify.sh` | Stops the current stream leader, attempts a JetStream publish during outage, observes leader state, restores node, and waits for replica catch-up. |
| `03_follower_failure_recovery.sh` | `01_baseline_infra.sh` | Stops a non-leader node, publishes a marker, inspects state, restores node and checks recovery. |
| `04_stream_rejoin_catchup.sh` | `01_baseline_infra.sh` | Stops a selected node, publishes while it is offline, restarts it and checks whether replicas report current. |
| `05_pull_cursor_resume.sh` | `01_baseline_infra.sh`; `PAYMENT_PROCESSORS` must exist | Capture pull durable cursor, publish marker, compare cursor snapshots. Without a live pull subscriber, cursor progression/processing is inconclusive. |
| `06_pull_unacked_redelivery.sh` | `01_baseline_infra.sh`; `PAYMENT_PROCESSORS` must exist | Publish a marker and inspect consumer state. To prove redelivery, a subscriber must receive the event and intentionally withhold ACK; CLI-only evidence is insufficient. |
| `07_pull_consumer_leader_failover.sh` | `01_baseline_infra.sh`; `PAYMENT_PROCESSORS` must exist; identify its leader | Stops the operator-confirmed consumer leader node, captures cursor/state and restores node. Does not prove consumer delivery/ACK continuity. |
| `08_push_cursor_offline_catchup.sh` | `01_baseline_infra.sh`; `PAYMENT_NOTIFICATIONS` must exist | Stop notification subscriber manually, run this script to publish three marker events, restart subscriber, then compare received event IDs and consumer cursor. CLI captures only part of this flow. |
| `09_push_subscriber_reconnect.sh` | `01_baseline_infra.sh`; `PAYMENT_NOTIFICATIONS` must exist | Stop notification subscriber, run marker publish, restart subscriber and verify reconnect/event receipt using subscriber logs or a future client harness. |
| `10_push_consumer_leader_failover.sh` | `01_baseline_infra.sh`; `PAYMENT_NOTIFICATIONS` must exist; identify its leader | Stops the confirmed consumer leader node and records state before/after. Notification delivery must be verified separately. |
| `11_two_node_quorum_loss.sh` | `01_baseline_infra.sh`; use only in disposable demo | Stops two NATS nodes, expects JetStream publish to be unavailable without quorum, and attempts to restore both nodes. Highly disruptive. |
| `12_quorum_restoration.sh` | Prefer after `11_two_node_quorum_loss.sh` or manual node restoration | Checks nodes, client path, stream/replicas and performs a JetStream publish after recovery. |
| `13_haproxy_backend_failure.sh` | `01_baseline_infra.sh` | Stops one NATS backend while HAProxy remains up, attempts a JetStream publish, restores backend and inspects recovery. |
| `14_haproxy_process_failure.sh` | `01_baseline_infra.sh`; no other test/client should depend on the endpoint | Stops HAProxy, verifies client-path failure, restarts it and verifies the path and stream recover. |
| `15_duplicate_idempotency.sh` | `01_baseline_infra.sh`; `PAYMENT_PROCESSORS` must exist | Publishes a marker and records consumer state. True duplicate redelivery and one-time business side effect require a real subscriber/side-effect observer; CLI-only result remains inconclusive. |
| `16_end_to_end_one_node_failure.sh` | `01_baseline_infra.sh`; both durable consumers should exist | Stops one node while publishing a marker and captures consumer checkpoints. To claim end-to-end success, reconcile event IDs, processing ACKs and notifications from a subscriber harness. |

## Suggested demo sequences

### Infrastructure and publish smoke test

`01_baseline_infra.sh` → `01_01_publish_verify.sh` → `01_baseline_infra.sh`

### Stream leader failover

`01_baseline_infra.sh` → `02_stream_leader_failover.sh` → `01_baseline_infra.sh`

### Replica recovery

`01_baseline_infra.sh` → `04_stream_rejoin_catchup.sh` → `01_baseline_infra.sh`

### Quorum loss and recovery

`01_baseline_infra.sh` → `11_two_node_quorum_loss.sh` → `12_quorum_restoration.sh` → `01_baseline_infra.sh`

### HAProxy recovery

`01_baseline_infra.sh` → `14_haproxy_process_failure.sh` → `01_baseline_infra.sh`

Do not run disruptive scenarios concurrently. Review each prompt and ensure every node/HAProxy process is restored before moving to another scenario.
