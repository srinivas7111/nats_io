package com.company.messaging;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import org.junit.jupiter.api.Test;

/** Guards the two design promises: no JNATS in the public API, and no admin capability in the client artifact. */
class ApiBoundaryTest {

    private static List<String> classNamesInMainPackage() throws Exception {
        List<String> names = new ArrayList<>();
        File location = codeSource();
        if (location.isDirectory()) {
            File[] files = new File(location, "com/company/messaging").listFiles();
            for (File f : files == null ? new File[0] : files) {
                if (f.getName().endsWith(".class")) {
                    names.add("com.company.messaging." + f.getName().replace(".class", ""));
                }
            }
        } else {
            try (JarFile jar = new JarFile(location)) {
                for (Enumeration<JarEntry> e = jar.entries(); e.hasMoreElements(); ) {
                    String n = e.nextElement().getName();
                    if (n.startsWith("com/company/messaging/") && n.indexOf('/', 22) < 0 && n.endsWith(".class")) {
                        names.add(n.replace('/', '.').replace(".class", ""));
                    }
                }
            }
        }
        return names;
    }

    private static File codeSource() throws URISyntaxException {
        return new File(MessagingClient.class.getProtectionDomain().getCodeSource().getLocation().toURI());
    }

    @Test
    void noJnatsTypeAppearsInThePublicApi() throws Exception {
        List<String> violations = new ArrayList<>();
        List<String> names = classNamesInMainPackage();
        assertTrue(names.size() > 20, "scan found too few classes: " + names.size());
        for (String name : names) {
            Class<?> c = Class.forName(name);
            if (!Modifier.isPublic(c.getModifiers())) continue;
            for (Method m : c.getDeclaredMethods()) {
                if (!exposed(m.getModifiers())) continue;
                check(violations, name + "#" + m.getName() + " returns", m.getGenericReturnType().getTypeName());
                for (var p : m.getGenericParameterTypes()) check(violations, name + "#" + m.getName() + " param", p.getTypeName());
                for (var x : m.getGenericExceptionTypes()) check(violations, name + "#" + m.getName() + " throws", x.getTypeName());
            }
            for (Constructor<?> k : c.getDeclaredConstructors()) {
                if (!exposed(k.getModifiers())) continue;
                for (var p : k.getGenericParameterTypes()) check(violations, name + " constructor param", p.getTypeName());
            }
            for (Field f : c.getDeclaredFields()) {
                if (exposed(f.getModifiers())) check(violations, name + "#" + f.getName() + " field", f.getGenericType().getTypeName());
            }
            for (var i : c.getGenericInterfaces()) check(violations, name + " implements", i.getTypeName());
        }
        assertEquals(List.of(), violations);
    }

    private static boolean exposed(int modifiers) {
        return Modifier.isPublic(modifiers) || Modifier.isProtected(modifiers);
    }

    private static void check(List<String> violations, String where, String type) {
        if (type.contains("io.nats")) {
            violations.add(where + " " + type);
        }
    }

    @Test
    void theClientArtifactHasNoAdminCapability() {
        assertThrows(ClassNotFoundException.class, () -> Class.forName("com.company.messaging.JetStreamAdmin"));
        assertThrows(ClassNotFoundException.class, () -> Class.forName("com.company.messaging.StreamSpec"));
        assertThrows(ClassNotFoundException.class, () -> Class.forName("com.company.messaging.ConsumerSpec"));
        assertThrows(ClassNotFoundException.class, () -> Class.forName("com.company.messaging.admin.MessagingAdmin"));
        for (Class<?> c : new Class<?>[]{MessagingClient.class, JetStreamClient.class, PullConsumer.class, JetStreamPublisher.class}) {
            for (Method m : c.getMethods()) {
                String n = m.getName().toLowerCase();
                assertFalse(n.contains("admin") || n.startsWith("createstream") || n.startsWith("deletestream")
                        || n.startsWith("deleteconsumer"), c.getSimpleName() + "#" + m.getName());
            }
        }
    }
}
