package com.company.messaging;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;

/** The ack / nak / term decisions made for every delivery, including the unhappy paths. */
class DispatchTest {

    private static ConsumeOptions.Builder opts() {
        return ConsumeOptions.builder().retryDelay(Duration.ofSeconds(1), Duration.ofSeconds(30));
    }

    @Test
    void successfulHandlerIsAckedOnce() {
        FakeJsMessage f = new FakeJsMessage(1);
        PullConsumer.dispatch(f.message, opts().build(), m -> { });
        assertEquals(1, f.acks.get());
        assertEquals(0, f.naks.get());
    }

    @Test
    void ackFailureAfterSuccessfulHandlerDoesNotNakOrReportAFailure() {
        FakeJsMessage f = new FakeJsMessage(1);
        f.failAcks.set(1);
        List<Throwable> failures = new CopyOnWriteArrayList<>();
        PullConsumer.dispatch(f.message, opts().onFailure((m, t) -> failures.add(t)).build(), m -> { });
        assertEquals(1, f.acks.get());
        assertEquals(0, f.naks.get(), "must not nak a message whose ack may have reached the server");
        assertEquals(0, f.terms.get());
        assertTrue(failures.isEmpty(), "the handler succeeded, so onFailure must not fire");
    }

    @Test
    void failingHandlerNaksWithExponentialDelay() {
        FakeJsMessage f = new FakeJsMessage(3);
        List<Throwable> failures = new CopyOnWriteArrayList<>();
        PullConsumer.dispatch(f.message, opts().onFailure((m, t) -> failures.add(t)).build(), m -> {
            throw new IllegalStateException("db down");
        });
        assertEquals(1, f.naks.get());
        assertEquals(Duration.ofSeconds(4), f.lastNakDelay); // 1s * 2^(3-1)
        assertEquals(1, failures.size());
        assertEquals(0, f.acks.get());
    }

    @Test
    void poisonMessageIsTerminatedAtTheLimit() {
        FakeJsMessage f = new FakeJsMessage(3);
        PullConsumer.dispatch(f.message, opts().terminateAfterDeliveries(3).build(), m -> {
            throw new RuntimeException("bad payload");
        });
        assertEquals(1, f.terms.get());
        assertEquals(0, f.naks.get());
    }

    @Test
    void belowThePoisonLimitItIsStillRetried() {
        FakeJsMessage f = new FakeJsMessage(2);
        PullConsumer.dispatch(f.message, opts().terminateAfterDeliveries(3).build(), m -> {
            throw new RuntimeException("bad payload");
        });
        assertEquals(0, f.terms.get());
        assertEquals(1, f.naks.get());
    }

    @Test
    void nakFailureAfterHandlerFailureNeverEscapesIntoTheConsumerThread() {
        FakeJsMessage f = new FakeJsMessage(1);
        f.failNaks.set(1);
        PullConsumer.dispatch(f.message, opts().build(), m -> {
            throw new RuntimeException("boom");
        }); // must not throw
        assertEquals(1, f.naks.get());
    }

    @Test
    void unreadableMetadataIsTerminatedReportedAndNeverHandled() {
        FakeJsMessage f = new FakeJsMessage(1);
        f.unreadable = true;
        AtomicInteger handled = new AtomicInteger();
        List<String> subjects = new CopyOnWriteArrayList<>();
        List<Throwable> causes = new CopyOnWriteArrayList<>();
        ConsumeOptions o = opts().onUnreadable((subject, cause) -> {
            subjects.add(subject);
            causes.add(cause);
        }).build();
        PullConsumer.dispatch(f.message, o, m -> handled.incrementAndGet());
        assertEquals(0, handled.get());
        assertEquals(1, f.terms.get(), "an unreadable delivery must be terminated, not left to redeliver forever");
        assertEquals(List.of("orders.created"), subjects);
        assertNotNull(causes.get(0));
    }

    @Test
    void unreadableMessageWhoseTermFailsStillDoesNotThrow() {
        FakeJsMessage f = new FakeJsMessage(1);
        f.unreadable = true;
        f.failTerms.set(1);
        PullConsumer.dispatch(f.message, opts().build(), m -> { }); // must not throw
        assertEquals(1, f.terms.get());
    }

    @Test
    void jvmFatalErrorsPropagateAndLeaveTheMessageUntouched() {
        FakeJsMessage f = new FakeJsMessage(1);
        List<Throwable> failures = new CopyOnWriteArrayList<>();
        assertThrows(NoClassDefFoundError.class, () -> PullConsumer.dispatch(f.message,
                opts().onFailure((m, t) -> failures.add(t)).build(), m -> {
                    throw new NoClassDefFoundError("missing dependency");
                }));
        assertEquals(0, f.acks.get());
        assertEquals(0, f.naks.get());
        assertEquals(0, f.terms.get());
        assertTrue(failures.isEmpty());
    }

    @Test
    void handlerThatSettlesItselfIsNotAckedAgain() {
        FakeJsMessage f = new FakeJsMessage(1);
        PullConsumer.dispatch(f.message, opts().build(), ReceivedMessage::term);
        assertEquals(1, f.terms.get());
        assertEquals(0, f.acks.get());
    }

    @Test
    void autoAckCanBeDisabled() {
        FakeJsMessage f = new FakeJsMessage(1);
        PullConsumer.dispatch(f.message, opts().autoAck(false).build(), m -> { });
        assertEquals(0, f.acks.get());
    }
}
