package com.company.messaging;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.company.messaging.MessagingException.Kind;
import com.company.messaging.spi.ErrorMapper;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.CompletionException;
import java.util.concurrent.TimeoutException;
import org.junit.jupiter.api.Test;

/** Tests that need no NATS server. */
class UnitTest {

    @Test
    void configRequiresAServer() {
        MessagingException e = assertThrows(MessagingException.class, () -> MessagingConfig.builder().build());
        assertEquals(Kind.CONFIGURATION, e.kind());
    }

    @Test
    void configRejectsTwoAuthMethods() {
        var b = MessagingConfig.builder().server("nats://x:4222").userPassword("u", "p").token("t");
        assertEquals(Kind.CONFIGURATION, assertThrows(MessagingException.class, b::build).kind());
    }

    @Test
    void configRejectsDomainAndPrefixTogether() {
        var b = MessagingConfig.builder().server("nats://x:4222").jetStreamDomain("hub").jetStreamApiPrefix("$JS.acc.API");
        assertEquals(Kind.CONFIGURATION, assertThrows(MessagingException.class, b::build).kind());
    }

    @Test
    void toStringNeverLeaksSecrets() {
        String s = MessagingConfig.builder().server("nats://x:4222")
                .userPassword("alice", "s3cr3t-pass").build().toString();
        assertFalse(s.contains("s3cr3t-pass"), s);
        assertTrue(s.contains("user-password"), s);
        String t = MessagingConfig.builder().server("nats://x:4222").token("tok-abc-123").build().toString();
        assertFalse(t.contains("tok-abc-123"), t);
    }

    @Test
    void fromEnvironmentReadsVariables() {
        Map<String, String> env = Map.of(
                "NATS_URL", "nats://a:4222, nats://b:4222",
                "NATS_USERNAME", "svc", "NATS_PASSWORD", "pw",
                "NATS_CONNECTION_NAME", "orders",
                "NATS_JS_DOMAIN", "hub");
        MessagingConfig c = MessagingConfig.fromEnvironment(env::get).build();
        assertEquals(java.util.List.of("nats://a:4222", "nats://b:4222"), c.servers());
        assertEquals("svc", c.username());
        assertEquals("orders", c.connectionName());
        assertEquals("hub", c.jetStreamDomain());
    }

    @Test
    void backoffDoublesAndIsCapped() {
        Duration base = Duration.ofSeconds(1);
        Duration max = Duration.ofSeconds(30);
        assertEquals(Duration.ofSeconds(1), Backoff.retryDelay(base, max, 1));
        assertEquals(Duration.ofSeconds(1), Backoff.retryDelay(base, max, 0));
        assertEquals(Duration.ofSeconds(2), Backoff.retryDelay(base, max, 2));
        assertEquals(Duration.ofSeconds(8), Backoff.retryDelay(base, max, 4));
        assertEquals(max, Backoff.retryDelay(base, max, 10));
        assertEquals(max, Backoff.retryDelay(base, max, 1_000_000));
    }

    @Test
    void consumeOptionsValidateInput() {
        assertThrows(IllegalArgumentException.class, () -> ConsumeOptions.builder().batchSize(0));
        assertThrows(IllegalArgumentException.class, () -> ConsumeOptions.builder().pullExpiry(Duration.ofMillis(500)));
        assertThrows(IllegalArgumentException.class, () -> ConsumeOptions.builder().pullExpiry(Duration.ofMinutes(6)));
        assertThrows(IllegalArgumentException.class,
                () -> ConsumeOptions.builder().retryDelay(Duration.ofSeconds(5), Duration.ofSeconds(1)));
        assertEquals(Duration.ofSeconds(10), ConsumeOptions.defaults().pullExpiry());
    }

    @Test
    void publishRequestRejectsBadSubjects() {
        assertThrows(IllegalArgumentException.class, () -> PublishRequest.builder(""));
        assertThrows(IllegalArgumentException.class, () -> PublishRequest.builder("a.*"));
        assertThrows(IllegalArgumentException.class, () -> PublishRequest.builder("a.>"));
        assertThrows(IllegalArgumentException.class, () -> PublishRequest.builder("has space"));
    }

    @Test
    void errorMapperClassifies() {
        assertEquals(Kind.TIMEOUT, ErrorMapper.map("op", new TimeoutException("x")).kind());
        assertEquals(Kind.INVALID_REQUEST, ErrorMapper.map("op", new IllegalArgumentException("bad")).kind());
        assertEquals(Kind.CONNECTION, ErrorMapper.map("op", new java.io.IOException("socket reset")).kind());
        assertEquals(Kind.UNAVAILABLE, ErrorMapper.map("op", new java.io.IOException("No responders available")).kind());
        assertEquals(Kind.CLOSED, ErrorMapper.map("op", new IllegalStateException("Connection is Closed")).kind());
        // wrapped in CompletionException (async publish) is unwrapped
        assertEquals(Kind.TIMEOUT, ErrorMapper.map("op", new CompletionException(new TimeoutException())).kind());
        assertTrue(ErrorMapper.map("op", new TimeoutException()).isRetryable());
        assertFalse(ErrorMapper.map("op", new IllegalArgumentException()).isRetryable());
        // interrupt flag is restored
        MessagingException ie = ErrorMapper.map("op", new InterruptedException());
        assertEquals(Kind.INTERRUPTED, ie.kind());
        assertTrue(Thread.interrupted());
    }

    @Test
    void connectFailureIsAConnectionException() {
        MessagingConfig cfg = MessagingConfig.builder().server("nats://127.0.0.1:1")
                .connectionTimeout(Duration.ofMillis(500)).build();
        MessagingException e = assertThrows(MessagingException.class, () -> MessagingClient.connect(cfg));
        assertEquals(Kind.CONNECTION, e.kind());
        assertTrue(e.isRetryable());
    }
}
