package com.company.messaging;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.company.messaging.MessagingException.Kind;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import org.junit.jupiter.api.Test;

/** Message settlement state must always reflect what the server actually received. */
class SettlementTest {

    @Test
    void failedAckLeavesTheMessageUnsettledSoItCanBeRetried() {
        FakeJsMessage fake = new FakeJsMessage(1);
        fake.failAcks.set(1);
        ReceivedMessage msg = ReceivedMessage.from(fake.message);

        MessagingException e = assertThrows(MessagingException.class, msg::ack);
        assertEquals(Kind.CLOSED, e.kind());
        assertFalse(msg.isSettled(), "a failed ack must not count as settled");

        msg.ack(); // retry succeeds
        assertTrue(msg.isSettled());
        assertEquals(2, fake.acks.get());
    }

    @Test
    void failedAckSyncLeavesTheMessageUnsettled() {
        FakeJsMessage fake = new FakeJsMessage(1);
        fake.failAcks.set(1);
        ReceivedMessage msg = ReceivedMessage.from(fake.message);
        assertThrows(MessagingException.class, () -> msg.ackSync(Duration.ofSeconds(1)));
        assertFalse(msg.isSettled());
        msg.ackSync(Duration.ofSeconds(1));
        assertTrue(msg.isSettled());
    }

    @Test
    void failedNakLeavesTheMessageFreeForADifferentSettlement() {
        FakeJsMessage fake = new FakeJsMessage(2);
        fake.failNaks.set(1);
        ReceivedMessage msg = ReceivedMessage.from(fake.message);

        assertThrows(MessagingException.class, () -> msg.nakWithDelay(Duration.ofSeconds(1)));
        assertFalse(msg.isSettled());

        msg.term(); // caller decides to terminate instead
        assertTrue(msg.isSettled());
        assertEquals(1, fake.terms.get());
        msg.ack(); // ignored: already settled
        assertEquals(0, fake.acks.get());
    }

    @Test
    void failedTermLeavesTheMessageUnsettled() {
        FakeJsMessage fake = new FakeJsMessage(9);
        fake.failTerms.set(1);
        ReceivedMessage msg = ReceivedMessage.from(fake.message);
        assertThrows(MessagingException.class, msg::term);
        assertFalse(msg.isSettled());
    }

    @Test
    void firstSuccessfulSettlementWins() {
        FakeJsMessage fake = new FakeJsMessage(1);
        ReceivedMessage msg = ReceivedMessage.from(fake.message);
        msg.ack();
        msg.nak();
        msg.term();
        assertEquals(1, fake.acks.get());
        assertEquals(0, fake.naks.get());
        assertEquals(0, fake.terms.get());
    }

    @Test
    void concurrentSettlementReachesTheServerOnce() throws Exception {
        FakeJsMessage fake = new FakeJsMessage(1);
        ReceivedMessage msg = ReceivedMessage.from(fake.message);
        int threads = 16;
        CountDownLatch go = new CountDownLatch(1);
        List<Thread> ts = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            Thread t = new Thread(() -> {
                try {
                    go.await();
                } catch (InterruptedException e) {
                    return;
                }
                msg.ack();
            });
            t.start();
            ts.add(t);
        }
        go.countDown();
        for (Thread t : ts) t.join(5000);
        assertEquals(1, fake.acks.get());
    }

    @Test
    void metadataIsExposed() {
        ReceivedMessage msg = ReceivedMessage.from(new FakeJsMessage(3).message);
        assertEquals("ORDERS", msg.metadata().stream());
        assertEquals("billing", msg.metadata().consumer());
        assertEquals(3L, msg.metadata().deliveredCount());
        assertEquals(7L, msg.metadata().streamSequence());
        assertTrue(msg.metadata().isRedelivery());
    }
}
