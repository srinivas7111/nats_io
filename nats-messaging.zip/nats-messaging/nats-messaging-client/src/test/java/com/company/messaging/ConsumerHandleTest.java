package com.company.messaging;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.nats.client.MessageConsumer;
import io.nats.client.api.ConsumerInfo;
import java.time.Duration;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;

/** Shutdown behaviour of a consumer handle, including a handler that never finishes. */
class ConsumerHandleTest {

    private static final class FakeConsumer implements MessageConsumer {
        final AtomicBoolean stopped = new AtomicBoolean();
        final AtomicBoolean closed = new AtomicBoolean();

        @Override public String getConsumerName() { return "fake"; }
        @Override public ConsumerInfo getConsumerInfo() { return null; }
        @Override public ConsumerInfo getCachedConsumerInfo() { return null; }
        @Override public void stop() { stopped.set(true); }
        @Override public void close() { stopped.set(true); closed.set(true); }
        @Override public boolean isStopped() { return stopped.get(); }
        @Override public boolean isFinished() { return closed.get(); }
    }

    @Test
    void timedOutShutdownStillReleasesTheConsumerAndStopsTrackingIt() {
        FakeConsumer fake = new FakeConsumer();
        Set<ManagedResource> registry = ConcurrentHashMap.newKeySet();
        AtomicInteger inFlight = new AtomicInteger(1); // a handler that never finishes
        ConsumerHandle handle = new ConsumerHandle(fake, registry, inFlight);
        assertEquals(1, registry.size());

        boolean finished = handle.awaitFinished(Duration.ofMillis(150));

        assertFalse(finished);
        assertTrue(fake.closed.get(), "a consumer must be released even if its handler is stuck");
        assertTrue(registry.isEmpty(), "and must no longer be tracked");
    }

    @Test
    void cleanShutdownWaitsForTheRunningHandler() throws Exception {
        FakeConsumer fake = new FakeConsumer();
        Set<ManagedResource> registry = ConcurrentHashMap.newKeySet();
        AtomicInteger inFlight = new AtomicInteger(1);
        ConsumerHandle handle = new ConsumerHandle(fake, registry, inFlight);
        Thread t = new Thread(() -> {
            try {
                Thread.sleep(150);
            } catch (InterruptedException ignored) {
                // test thread
            }
            inFlight.decrementAndGet();
        });
        t.start();

        assertTrue(handle.awaitFinished(Duration.ofSeconds(3)));
        assertTrue(fake.closed.get());
        assertTrue(registry.isEmpty());
        t.join();
    }

    @Test
    void stopAloneKeepsTheHandleRegisteredUntilItIsClosed() {
        FakeConsumer fake = new FakeConsumer();
        Set<ManagedResource> registry = ConcurrentHashMap.newKeySet();
        ConsumerHandle handle = new ConsumerHandle(fake, registry, new AtomicInteger());

        handle.stop();
        assertTrue(handle.isStopped());
        assertFalse(fake.closed.get());
        assertEquals(1, registry.size(), "still tracked so MessagingClient.close() can release it");

        handle.close();
        assertTrue(fake.closed.get());
        assertTrue(registry.isEmpty());
    }
}
