package com.company.messaging;

import io.nats.client.Message;
import io.nats.client.impl.NatsJetStreamMetaData;
import io.nats.client.impl.NatsMessage;
import java.lang.reflect.Proxy;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * A scripted JetStream delivery for unit tests: counts ack/nak/term calls and can be told to fail them
 * or to have unreadable metadata. Backed by a dynamic proxy of {@link Message}.
 */
final class FakeJsMessage {

    final AtomicInteger acks = new AtomicInteger();
    final AtomicInteger ackSyncs = new AtomicInteger();
    final AtomicInteger naks = new AtomicInteger();
    final AtomicInteger terms = new AtomicInteger();
    /** Number of upcoming calls that should fail, per operation. */
    final AtomicInteger failAcks = new AtomicInteger();
    final AtomicInteger failNaks = new AtomicInteger();
    final AtomicInteger failTerms = new AtomicInteger();
    volatile Duration lastNakDelay;
    volatile boolean unreadable;
    final Message message;

    /** Metadata subclass trick: NatsMessage with isJetStream() true so NatsJetStreamMetaData accepts it. */
    private static final class JsEnvelope extends NatsMessage {
        JsEnvelope(String replyTo) {
            super("orders.created", replyTo, new byte[0]);
        }

        @Override
        public boolean isJetStream() {
            return true;
        }
    }

    FakeJsMessage(long deliveredCount) {
        String reply = "$JS.ACK.ORDERS.billing." + deliveredCount + ".7.3.1700000000000000000.0";
        NatsJetStreamMetaData meta = new NatsJetStreamMetaData(new JsEnvelope(reply));
        this.message = (Message) Proxy.newProxyInstance(Message.class.getClassLoader(), new Class<?>[]{Message.class},
                (proxy, method, args) -> {
                    switch (method.getName()) {
                        case "getSubject": return "orders.created";
                        case "getData": return "payload".getBytes();
                        case "metaData":
                            if (unreadable) throw new IllegalStateException("Message is not a JetStream message");
                            return meta;
                        case "ack": acks.incrementAndGet(); maybeFail(failAcks); return null;
                        case "ackSync": ackSyncs.incrementAndGet(); maybeFail(failAcks); return null;
                        case "nak": naks.incrementAndGet(); maybeFail(failNaks); return null;
                        case "nakWithDelay":
                            naks.incrementAndGet();
                            lastNakDelay = args[0] instanceof Duration d ? d : Duration.ofMillis((Long) args[0]);
                            maybeFail(failNaks);
                            return null;
                        case "term": terms.incrementAndGet(); maybeFail(failTerms); return null;
                        case "inProgress": return null;
                        case "isJetStream": return true;
                        case "toString": return "FakeJsMessage";
                        case "hashCode": return System.identityHashCode(proxy);
                        case "equals": return proxy == args[0];
                        default: return defaultValue(method.getReturnType());
                    }
                });
    }

    private static void maybeFail(AtomicInteger remaining) {
        if (remaining.getAndUpdate(n -> Math.max(0, n - 1)) > 0) {
            throw new IllegalStateException("Connection is closed");
        }
    }

    private static Object defaultValue(Class<?> type) {
        if (!type.isPrimitive()) return null;
        if (type == boolean.class) return false;
        if (type == long.class) return 0L;
        if (type == int.class) return 0;
        if (type == double.class) return 0d;
        if (type == float.class) return 0f;
        if (type == short.class) return (short) 0;
        if (type == byte.class) return (byte) 0;
        return '\0';
    }
}
