package com.company.messaging;

import com.company.messaging.MessagingException.Kind;
import com.company.messaging.spi.ErrorMapper;
import io.nats.client.Connection;
import io.nats.client.Dispatcher;
import io.nats.client.Message;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Plain NATS publish / subscribe / request-reply (no persistence). For durable messaging use {@link JetStreamClient}.
 */
public final class CoreClient {

    private static final System.Logger LOG = System.getLogger(CoreClient.class.getName());

    private final Connection connection;
    private final Set<ManagedResource> registry;

    CoreClient(Connection connection, Set<ManagedResource> registry) {
        this.connection = connection;
        this.registry = registry;
    }

    public void publish(String subject, byte[] data) {
        publish(subject, Map.of(), data);
    }

    public void publish(String subject, Map<String, List<String>> headers, byte[] data) {
        checkSubject(subject);
        try {
            connection.publish(subject, HeaderCodec.toNats(headers), data);
        } catch (RuntimeException e) {
            throw ErrorMapper.map("publish to '" + subject + "'", e);
        }
    }

    /**
     * Sends a request and waits for one reply.
     *
     * @throws MessagingException {@link Kind#TIMEOUT} if nobody answered in time,
     *                            {@link Kind#UNAVAILABLE} if nobody is subscribed to the subject
     */
    public CoreMessage request(String subject, byte[] data, Duration timeout) {
        checkSubject(subject);
        java.util.concurrent.CompletableFuture<Message> pending = null;
        try {
            // The async variant is used because the blocking one returns null both for "no responders" and for a
            // real timeout, which callers need to tell apart.
            pending = connection.request(subject, null, data);
            return convert(pending.get(timeout.toMillis(), java.util.concurrent.TimeUnit.MILLISECONDS));
        } catch (java.util.concurrent.CancellationException e) {
            throw new MessagingException(Kind.UNAVAILABLE,
                    "request to '" + subject + "' failed: no responders (nobody is subscribed)", e, 503);
        } catch (java.util.concurrent.TimeoutException e) {
            pending.cancel(true);
            throw new MessagingException(Kind.TIMEOUT,
                    "request to '" + subject + "' got no reply within " + timeout, e);
        } catch (InterruptedException | java.util.concurrent.ExecutionException | RuntimeException e) {
            if (pending != null) {
                pending.cancel(true);
            }
            throw ErrorMapper.map("request to '" + subject + "'", e);
        }
    }

    /**
     * Subscribes with its own dispatcher thread, so a slow handler on one subscription never blocks another.
     *
     * @param queueGroup optional queue group: members of the same group share messages (load balancing); may be null
     */
    public SubscriptionHandle subscribe(String subject, String queueGroup, CoreMessageHandler handler) {
        java.util.Objects.requireNonNull(handler, "handler");
        if (subject == null || subject.isBlank()) {
            throw new IllegalArgumentException("subject must not be blank");
        }
        Dispatcher dispatcher = null;
        try {
            dispatcher = connection.createDispatcher();
            io.nats.client.MessageHandler wrapped = raw -> {
                try {
                    handler.handle(convert(raw));
                } catch (Throwable t) {
                    ErrorMapper.rethrowIfFatal(t);
                    if (t instanceof InterruptedException) {
                        Thread.currentThread().interrupt();
                    }
                    LOG.log(System.Logger.Level.ERROR, "Core handler for '" + subject + "' failed: " + t, t);
                }
            };
            if (queueGroup == null || queueGroup.isBlank()) {
                dispatcher.subscribe(subject, wrapped);
            } else {
                dispatcher.subscribe(subject, queueGroup, wrapped);
            }
            return new SubscriptionHandle(connection, dispatcher, registry);
        } catch (RuntimeException e) {
            if (dispatcher != null) {
                try {
                    connection.closeDispatcher(dispatcher);
                } catch (RuntimeException ignored) {
                    // best effort
                }
            }
            throw ErrorMapper.map("subscribe to '" + subject + "'", e);
        }
    }

    public SubscriptionHandle subscribe(String subject, CoreMessageHandler handler) {
        return subscribe(subject, null, handler);
    }

    private static CoreMessage convert(Message m) {
        return new CoreMessage(m.getSubject(), HeaderCodec.fromNats(m.getHeaders()),
                m.getData() == null ? new byte[0] : m.getData(), m.getReplyTo());
    }

    private static void checkSubject(String subject) {
        if (subject == null || subject.isBlank() || subject.contains("*") || subject.contains(">")
                || subject.chars().anyMatch(Character::isWhitespace)) {
            throw new MessagingException(Kind.INVALID_REQUEST,
                    "subject must be non-blank, without whitespace or wildcards: '" + subject + "'");
        }
    }
}
