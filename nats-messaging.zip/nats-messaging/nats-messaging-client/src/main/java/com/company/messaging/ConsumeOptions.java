package com.company.messaging;

import java.time.Duration;
import java.util.function.BiConsumer;

/** Options for {@link PullConsumer#consume(ConsumeOptions, MessageHandler)}. */
public final class ConsumeOptions {

    private final int batchSize;
    private final Duration pullExpiry;
    private final boolean autoAck;
    private final long terminateAfterDeliveries;
    private final Duration retryBaseDelay;
    private final Duration retryMaxDelay;
    private final BiConsumer<ReceivedMessage, Throwable> failureListener;
    private final BiConsumer<String, Throwable> unreadableListener;

    private ConsumeOptions(Builder b) {
        this.batchSize = b.batchSize;
        this.pullExpiry = b.pullExpiry;
        this.autoAck = b.autoAck;
        this.terminateAfterDeliveries = b.terminateAfterDeliveries;
        this.retryBaseDelay = b.retryBaseDelay;
        this.retryMaxDelay = b.retryMaxDelay;
        this.failureListener = b.failureListener;
        this.unreadableListener = b.unreadableListener;
    }

    /** Defaults: batch 50, pull expiry 10s, auto-ack, retry delay 1s doubling up to 30s, no client-side poison limit. */
    public static ConsumeOptions defaults() {
        return builder().build();
    }

    public static Builder builder() {
        return new Builder();
    }

    int batchSize() { return batchSize; }
    Duration pullExpiry() { return pullExpiry; }
    boolean autoAck() { return autoAck; }
    long terminateAfterDeliveries() { return terminateAfterDeliveries; }
    Duration retryBaseDelay() { return retryBaseDelay; }
    Duration retryMaxDelay() { return retryMaxDelay; }
    BiConsumer<ReceivedMessage, Throwable> failureListener() { return failureListener; }
    BiConsumer<String, Throwable> unreadableListener() { return unreadableListener; }

    public static final class Builder {
        private int batchSize = 50;
        private Duration pullExpiry = Duration.ofSeconds(10);
        private boolean autoAck = true;
        private long terminateAfterDeliveries = 0;
        private Duration retryBaseDelay = Duration.ofSeconds(1);
        private Duration retryMaxDelay = Duration.ofSeconds(30);
        private BiConsumer<ReceivedMessage, Throwable> failureListener = (m, t) -> { };
        private BiConsumer<String, Throwable> unreadableListener = (subject, t) -> { };

        private Builder() {
        }

        /** Messages requested from the server per pull. Default 50. */
        public Builder batchSize(int batchSize) {
            if (batchSize < 1) throw new IllegalArgumentException("batchSize must be >= 1");
            this.batchSize = batchSize;
            return this;
        }

        /**
         * How long each pull request stays open on the server (1s to 5min, default 10s). The server sends heartbeats
         * at half this interval, so it also bounds how quickly a consumer notices a lost pull request after a server
         * restart or failover (roughly 1 to 2 times this value). Shorter = faster recovery, slightly more idle traffic.
         */
        public Builder pullExpiry(Duration expiry) {
            if (expiry == null || expiry.toMillis() < 1000 || expiry.toMinutes() > 5) {
                throw new IllegalArgumentException("pullExpiry must be between 1 second and 5 minutes");
            }
            this.pullExpiry = expiry;
            return this;
        }

        /** When false the handler must settle every message itself. Default true. */
        public Builder autoAck(boolean autoAck) {
            this.autoAck = autoAck;
            return this;
        }

        /**
         * After this many deliveries a failing message is terminated (never redelivered) instead of nak'ed.
         * 0 (default) disables the client-side limit; the consumer's server-side {@code maxDeliver} still applies.
         */
        public Builder terminateAfterDeliveries(long deliveries) {
            if (deliveries < 0) throw new IllegalArgumentException("deliveries must be >= 0");
            this.terminateAfterDeliveries = deliveries;
            return this;
        }

        /** Redelivery delay after a handler failure: {@code base * 2^(deliveries-1)}, capped at {@code max}. */
        public Builder retryDelay(Duration base, Duration max) {
            if (base == null || base.isNegative() || base.isZero()) throw new IllegalArgumentException("base must be positive");
            if (max == null || max.compareTo(base) < 0) throw new IllegalArgumentException("max must be >= base");
            this.retryBaseDelay = base;
            this.retryMaxDelay = max;
            return this;
        }

        /** Called when the handler throws; use for metrics and dead-letter publishing. Must not throw. */
        public Builder onFailure(BiConsumer<ReceivedMessage, Throwable> listener) {
            this.failureListener = java.util.Objects.requireNonNull(listener, "listener");
            return this;
        }

        /**
         * Policy for a delivery whose JetStream metadata cannot be read (not a valid JetStream delivery): the library
         * <b>terminates</b> it (it can never be processed, and redelivering it would loop forever), logs an ERROR and
         * calls this hook with the subject and the cause, so the platform can alert or record it. Must not throw.
         * <p>
         * This is different from a payload your handler cannot parse: that is a handler failure and follows the
         * normal retry / {@link #terminateAfterDeliveries(long)} path.
         */
        public Builder onUnreadable(BiConsumer<String, Throwable> listener) {
            this.unreadableListener = java.util.Objects.requireNonNull(listener, "listener");
            return this;
        }

        public ConsumeOptions build() {
            return new ConsumeOptions(this);
        }
    }
}
