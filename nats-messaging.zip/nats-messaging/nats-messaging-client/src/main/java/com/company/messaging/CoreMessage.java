package com.company.messaging;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * A plain NATS (non-JetStream) message: no persistence, no acknowledgement.
 *
 * @param subject subject it was published to
 * @param headers unmodifiable headers, never null
 * @param data    payload, do not modify
 * @param replyTo reply subject for request/reply, or null
 */
public record CoreMessage(String subject, Map<String, List<String>> headers, byte[] data, String replyTo) {

    public String text() {
        return new String(data == null ? new byte[0] : data, StandardCharsets.UTF_8);
    }
}
