package com.company.messaging;

/**
 * @param stream     stream name
 * @param name       consumer name
 * @param pending    messages not yet delivered to this consumer
 * @param ackPending messages delivered but not yet acknowledged
 * @param redelivered messages that were delivered more than once
 */
public record ConsumerSummary(String stream, String name, long pending, long ackPending, long redelivered) {
}
