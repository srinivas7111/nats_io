package com.company.messaging.spi;

import com.company.messaging.ConnectionEventListener;
import com.company.messaging.MessagingConfig;
import com.company.messaging.MessagingException;
import com.company.messaging.MessagingException.Kind;
import io.nats.client.AuthHandler;
import io.nats.client.Connection;
import io.nats.client.ConnectionListener;
import io.nats.client.ErrorListener;
import io.nats.client.JetStreamOptions;
import io.nats.client.Nats;
import io.nats.client.Options;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.net.ssl.SSLContext;

/**
 * Builds JNATS connections from a {@link MessagingConfig}, so that authentication, TLS and listener behaviour
 * are implemented exactly once for the client and for the admin artifact.
 * <p>
 * <b>Platform tooling only.</b> Unlike the rest of the library, this class exposes JNATS types. Applications use
 * {@code MessagingClient} and must not depend on this package.
 */
public final class NatsConnections {

    private static final System.Logger LOG = System.getLogger(NatsConnections.class.getName());

    private NatsConnections() {
    }

    /**
     * Connects using the given configuration.
     *
     * @throws MessagingException {@code CONNECTION}, {@code AUTHORIZATION} or {@code CONFIGURATION}
     */
    public static Connection connect(MessagingConfig config) {
        java.util.Objects.requireNonNull(config, "config");
        Options options = options(config);
        try {
            return Nats.connect(options);
        } catch (Exception e) {
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            MessagingException me = ErrorMapper.map("connect to " + config.servers(), e);
            LOG.log(System.Logger.Level.ERROR, me.getMessage());
            throw me;
        }
    }

    public static JetStreamOptions jetStreamOptions(MessagingConfig config) {
        JetStreamOptions.Builder jb = JetStreamOptions.builder().requestTimeout(config.jetStreamRequestTimeout());
        if (config.jetStreamDomain() != null) {
            jb.domain(config.jetStreamDomain());
        }
        if (config.jetStreamApiPrefix() != null) {
            jb.prefix(config.jetStreamApiPrefix());
        }
        return jb.build();
    }

    public static Options options(MessagingConfig config) {
        Bridge bridge = new Bridge(config.listener());
        Options.Builder b = new Options.Builder()
                .servers(config.servers().toArray(new String[0]))
                .connectionTimeout(config.connectionTimeout())
                .reconnectWait(config.reconnectWait())
                .maxReconnects(config.maxReconnects())
                .pingInterval(config.pingInterval())
                .connectionListener(bridge)
                .errorListener(bridge);

        if (config.connectionName() != null) {
            b.connectionName(config.connectionName());
        }
        if (config.username() != null) {
            b.userInfo(config.username(), config.password());
        } else if (config.token() != null) {
            b.token(config.token().toCharArray());
        } else if (config.credentialsFile() != null) {
            // JNATS re-reads the credentials file on every authentication, so a rotated file is picked up
            // on the next (re)connect without restarting the client.
            AuthHandler handler = Nats.credentials(config.credentialsFile());
            b.authHandler(handler);
        }
        if (config.sslContext() != null) {
            b.sslContext(config.sslContext());
        } else if (config.trustStorePath() != null || config.keyStorePath() != null) {
            try {
                SSLContext ctx = TlsSupport.create(config.trustStorePath(), config.trustStorePassword(),
                        config.keyStorePath(), config.keyStorePassword(), config.storeType());
                b.sslContext(ctx);
            } catch (Exception e) {
                throw new MessagingException(Kind.CONFIGURATION, "Cannot load TLS key/trust store: " + e.getMessage(), e);
            }
        }
        return b.build();
    }

    /** Adapts JNATS listeners to {@link ConnectionEventListener}; guards against listener exceptions. */
    private static final class Bridge implements ConnectionListener, ErrorListener {
        private final ConnectionEventListener target;
        // JNATS reports DISCONNECTED once per failed reconnect attempt; forward only real transitions.
        private final AtomicBoolean up = new AtomicBoolean(false);

        Bridge(ConnectionEventListener target) {
            this.target = target;
        }

        @Override
        @SuppressWarnings("deprecation")
        public void connectionEvent(Connection conn, Events type) {
            // superseded by the 4-argument variant below, which the JNATS client calls
        }

        @Override
        public void connectionEvent(Connection conn, Events type, Long time, String uriDetails) {
            try {
                switch (type) {
                    case CONNECTED -> {
                        up.set(true);
                        target.onConnected();
                    }
                    case DISCONNECTED -> {
                        if (up.compareAndSet(true, false)) {
                            target.onDisconnected();
                        }
                    }
                    case RECONNECTED -> {
                        up.set(true);
                        target.onReconnected();
                    }
                    case CLOSED -> {
                        up.set(false);
                        target.onClosed();
                    }
                    case LAME_DUCK -> target.onLameDuck();
                    default -> { }
                }
            } catch (RuntimeException e) {
                LOG.log(System.Logger.Level.WARNING, "ConnectionEventListener threw: " + e);
            }
        }

        @Override
        public void errorOccurred(Connection conn, String error) {
            notifyError(error, null);
        }

        @Override
        public void exceptionOccurred(Connection conn, Exception exp) {
            notifyError(String.valueOf(exp.getMessage()), exp);
        }

        @Override
        public void slowConsumerDetected(Connection conn, io.nats.client.Consumer consumer) {
            notifyError("slow consumer detected", null);
        }

        private void notifyError(String description, Throwable cause) {
            try {
                target.onError(description, cause);
            } catch (RuntimeException e) {
                LOG.log(System.Logger.Level.WARNING, "ConnectionEventListener threw: " + e);
            }
        }
    }
}
