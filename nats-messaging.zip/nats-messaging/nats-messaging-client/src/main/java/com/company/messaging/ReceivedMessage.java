package com.company.messaging;

import com.company.messaging.spi.ErrorMapper;
import io.nats.client.Message;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeoutException;

/**
 * A message delivered by a JetStream consumer, with explicit acknowledgement controls.
 * <p>
 * <b>Delivery guarantee is at-least-once.</b> Make handlers idempotent; use
 * {@link MessageMetadata#deliveredCount()} to detect redeliveries.
 * <p>
 * A message is <em>settled</em> by {@link #ack()}, {@link #ackSync(Duration)}, {@link #nak()},
 * {@link #nakWithDelay(Duration)} or {@link #term()}. The first call that <b>succeeds</b> wins and later calls are
 * ignored. If a settling call <b>fails</b> (it throws {@link MessagingException}) the message stays unsettled, so the
 * caller may retry or choose a different settlement. Note that after a failed {@code ackSync} (timeout) the server
 * may or may not have recorded the ack; acking again is harmless. {@link #inProgress()} may be called repeatedly to
 * extend the ack deadline.
 */
public final class ReceivedMessage {

    private final Message raw;
    private final Map<String, List<String>> headers;
    private final MessageMetadata metadata;
    private final Object lock = new Object();
    private volatile boolean settled;

    private ReceivedMessage(Message raw) {
        this.raw = raw;
        this.headers = HeaderCodec.fromNats(raw.getHeaders());
        var m = raw.metaData();
        this.metadata = new MessageMetadata(m.getStream(), m.getConsumer(), m.streamSequence(), m.consumerSequence(),
                m.deliveredCount(), m.pendingCount(), m.timestamp().toInstant(), m.getDomain());
    }

    static ReceivedMessage from(Message raw) {
        return new ReceivedMessage(raw);
    }

    public String subject() {
        return raw.getSubject();
    }

    /** Raw payload. Do not modify the returned array. */
    public byte[] data() {
        byte[] d = raw.getData();
        return d == null ? new byte[0] : d;
    }

    /** Payload decoded as UTF-8. */
    public String text() {
        return new String(data(), StandardCharsets.UTF_8);
    }

    /** Unmodifiable view of all headers. */
    public Map<String, List<String>> headers() {
        return headers;
    }

    /** First value of the given header, if present (case-sensitive). */
    public Optional<String> header(String name) {
        List<String> v = headers.get(name);
        return v == null || v.isEmpty() ? Optional.empty() : Optional.of(v.get(0));
    }

    public MessageMetadata metadata() {
        return metadata;
    }

    /** True once ack / nak / term has been called (by the handler or by the library). */
    public boolean isSettled() {
        return settled;
    }

    /** Acknowledge (fire-and-forget). Use {@link #ackSync(Duration)} when you must know the server recorded it. */
    public void ack() {
        settle("ack", raw::ack);
    }

    /** Acknowledge and wait for the server to confirm. */
    public void ackSync(Duration timeout) {
        settle("ackSync", () -> raw.ackSync(timeout));
    }

    /** Negative-acknowledge: ask for immediate redelivery. Prefer {@link #nakWithDelay(Duration)}. */
    public void nak() {
        settle("nak", raw::nak);
    }

    /** Negative-acknowledge: ask for redelivery after {@code delay}. */
    public void nakWithDelay(Duration delay) {
        settle("nak", () -> raw.nakWithDelay(delay));
    }

    /** Terminate: never redeliver this message (poison message). */
    public void term() {
        settle("term", raw::term);
    }

    /** Tell the server work is still ongoing; resets the ack deadline. Does not settle the message. */
    public void inProgress() {
        guard("inProgress", raw::inProgress);
    }

    @FunctionalInterface
    private interface Settlement {
        void run() throws Exception;
    }

    /** Marks the message settled only after {@code action} succeeded; a failure leaves it unsettled. */
    private void settle(String operation, Settlement action) {
        synchronized (lock) {
            if (settled) {
                return;
            }
            try {
                action.run();
            } catch (Exception e) {
                throw ErrorMapper.map(operation, e);
            }
            settled = true;
        }
    }

    private static void guard(String op, Runnable r) {
        try {
            r.run();
        } catch (RuntimeException e) {
            throw ErrorMapper.map(op, e);
        }
    }

    @Override
    public String toString() {
        return "ReceivedMessage{subject=" + subject() + ", bytes=" + data().length + ", metadata=" + metadata + '}';
    }
}
