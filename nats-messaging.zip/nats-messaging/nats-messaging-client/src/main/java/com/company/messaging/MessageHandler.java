package com.company.messaging;

/**
 * Processes one JetStream message.
 * <p>
 * With the default {@link ConsumeOptions} the library settles the message for you:
 * returning normally acks it; throwing any exception naks it with a growing delay (or terminates it once
 * {@link ConsumeOptions.Builder#terminateAfterDeliveries(long)} is reached). Call {@code ack()/nak()/term()}
 * yourself on the message to override that.
 */
@FunctionalInterface
public interface MessageHandler {
    void handle(ReceivedMessage message) throws Exception;
}
