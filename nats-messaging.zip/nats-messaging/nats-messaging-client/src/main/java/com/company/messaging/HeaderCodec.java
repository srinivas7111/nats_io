package com.company.messaging;

import io.nats.client.impl.Headers;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Converts between plain maps (public API) and JNATS {@link Headers}. Package-private. */
final class HeaderCodec {

    private HeaderCodec() {
    }

    static Headers toNats(Map<String, List<String>> map) {
        if (map == null || map.isEmpty()) {
            return null;
        }
        Headers headers = new Headers();
        map.forEach((k, v) -> headers.add(k, v));
        return headers;
    }

    static Map<String, List<String>> fromNats(Headers headers) {
        if (headers == null || headers.isEmpty()) {
            return Map.of();
        }
        Map<String, List<String>> out = new LinkedHashMap<>();
        for (String key : headers.keySet()) {
            out.put(key, List.copyOf(headers.get(key)));
        }
        return java.util.Collections.unmodifiableMap(out);
    }
}
