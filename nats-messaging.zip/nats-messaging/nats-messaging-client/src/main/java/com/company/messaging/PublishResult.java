package com.company.messaging;

/**
 * Server acknowledgement of a JetStream publish.
 *
 * @param stream    stream that stored the message
 * @param sequence  sequence number assigned in the stream
 * @param duplicate true if the server detected a duplicate message id and did not store it again
 * @param domain    JetStream domain, may be null
 */
public record PublishResult(String stream, long sequence, boolean duplicate, String domain) {
}
