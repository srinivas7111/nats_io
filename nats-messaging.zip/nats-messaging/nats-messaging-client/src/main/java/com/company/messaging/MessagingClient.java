package com.company.messaging;

import com.company.messaging.MessagingException.Kind;
import com.company.messaging.spi.ErrorMapper;
import com.company.messaging.spi.NatsConnections;
import io.nats.client.Connection;
import io.nats.client.JetStream;
import io.nats.client.JetStreamOptions;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Entry point of the library. One instance owns one NATS connection and is safe to share between threads;
 * create it once at application start and close it at shutdown.
 *
 * <pre>{@code
 * try (MessagingClient client = MessagingClient.connect(MessagingConfig.fromEnvironment().build())) {
 *     client.jetStream().publisher().publish(PublishRequest.builder("orders.created").payload("{}").messageId("o-1").build());
 * }
 * }</pre>
 *
 * Reconnection is automatic. No JNATS type appears anywhere in this library's public API.
 */
public final class MessagingClient implements AutoCloseable {

    private static final System.Logger LOG = System.getLogger(MessagingClient.class.getName());

    private final Connection connection;
    private final MessagingConfig config;
    private final Set<ManagedResource> registry;
    private final JetStreamClient jetStream;
    private final CoreClient core;
    private final AtomicBoolean closed = new AtomicBoolean(false);

    private MessagingClient(Connection connection, JetStream js, MessagingConfig config,
                            Set<ManagedResource> registry) {
        this.connection = connection;
        this.config = config;
        this.registry = registry;
        this.jetStream = new JetStreamClient(js, config, registry);
        this.core = new CoreClient(connection, registry);
    }

    /**
     * Connects to the server(s). Blocks until connected or {@code connectionTimeout} per server elapses.
     *
     * @throws MessagingException {@link Kind#CONNECTION}, {@link Kind#AUTHORIZATION} or {@link Kind#CONFIGURATION}
     */
    public static MessagingClient connect(MessagingConfig config) {
        java.util.Objects.requireNonNull(config, "config");
        Connection connection = NatsConnections.connect(config);
        try {
            JetStreamOptions jsOptions = NatsConnections.jetStreamOptions(config);
            JetStream js = connection.jetStream(jsOptions);
            return new MessagingClient(connection, js, config, ConcurrentHashMap.newKeySet());
        } catch (Exception e) {
            try {
                connection.close();
            } catch (Exception ignored) {
                // best effort
            }
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            throw ErrorMapper.map("open JetStream context", e);
        }
    }

    /** Durable messaging: publish with acknowledgements, pull consumers, admin helpers. */
    public JetStreamClient jetStream() {
        return jetStream;
    }

    /** Plain publish / subscribe / request-reply. */
    public CoreClient core() {
        return core;
    }

    public ConnectionStatus status() {
        return switch (connection.getStatus()) {
            case CONNECTED -> ConnectionStatus.CONNECTED;
            case CONNECTING -> ConnectionStatus.CONNECTING;
            case RECONNECTING -> ConnectionStatus.RECONNECTING;
            case DISCONNECTED -> ConnectionStatus.DISCONNECTED;
            case CLOSED -> ConnectionStatus.CLOSED;
        };
    }

    /**
     * Round-trips to the server. Returns false (never throws) if the server does not answer in time,
     * so it can back a readiness probe.
     */
    public boolean healthCheck(Duration timeout) {
        if (closed.get() || connection.getStatus() != Connection.Status.CONNECTED) {
            return false;
        }
        try {
            connection.flush(timeout);
            return true;
        } catch (TimeoutException e) {
            return false;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        } catch (RuntimeException e) {
            return false;
        }
    }

    /**
     * Graceful shutdown: stops all consumers and subscriptions, waits (up to {@code shutdownTimeout}) for handlers
     * that are running, flushes pending publishes, then closes the connection. Idempotent.
     */
    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        Duration timeout = config.shutdownTimeout();
        List<ManagedResource> resources = new ArrayList<>(registry);
        resources.forEach(ManagedResource::stopResource);
        long deadline = System.nanoTime() + timeout.toNanos();
        for (ManagedResource r : resources) {
            long remaining = Math.max(0, deadline - System.nanoTime());
            // drain() always releases the resource, even when it times out, so nothing is leaked
            if (!r.drain(Duration.ofNanos(remaining))) {
                LOG.log(System.Logger.Level.WARNING, "A consumer did not finish within the shutdown timeout");
            }
        }
        try {
            long remaining = Math.max(1_000_000L, deadline - System.nanoTime());
            if (connection.getStatus() == Connection.Status.CONNECTED) {
                connection.drain(Duration.ofNanos(remaining)).get(remaining, TimeUnit.NANOSECONDS);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            LOG.log(System.Logger.Level.WARNING, "Drain did not complete cleanly: " + e);
        } finally {
            try {
                connection.close();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (Exception ignored) {
                // nothing more to do
            }
        }
    }
}
