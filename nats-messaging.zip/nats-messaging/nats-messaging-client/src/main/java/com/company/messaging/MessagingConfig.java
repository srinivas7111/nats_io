package com.company.messaging;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import javax.net.ssl.SSLContext;

/**
 * Immutable client configuration. Build with {@link #builder()} or {@link #fromEnvironment()}.
 * <p>
 * Secrets (password, token) are never included in {@link #toString()}.
 */
public final class MessagingConfig {

    private static final System.Logger LOG = System.getLogger(MessagingConfig.class.getName());

    private final List<String> servers;
    private final String connectionName;
    private final String username;
    private final String password;
    private final String token;
    private final String credentialsFile;
    private final SSLContext sslContext;
    private final String trustStorePath;
    private final String trustStorePassword;
    private final String keyStorePath;
    private final String keyStorePassword;
    private final String storeType;
    private final Duration connectionTimeout;
    private final Duration reconnectWait;
    private final int maxReconnects;
    private final Duration pingInterval;
    private final Duration shutdownTimeout;
    private final String jetStreamDomain;
    private final String jetStreamApiPrefix;
    private final Duration jetStreamRequestTimeout;
    private final int publishMaxAttempts;
    private final Duration publishRetryInitialBackoff;
    private final Duration publishRetryMaxBackoff;
    private final ConnectionEventListener listener;

    private MessagingConfig(Builder b) {
        this.servers = List.copyOf(b.servers);
        this.connectionName = b.connectionName;
        this.username = b.username;
        this.password = b.password;
        this.token = b.token;
        this.credentialsFile = b.credentialsFile;
        this.sslContext = b.sslContext;
        this.trustStorePath = b.trustStorePath;
        this.trustStorePassword = b.trustStorePassword;
        this.keyStorePath = b.keyStorePath;
        this.keyStorePassword = b.keyStorePassword;
        this.storeType = b.storeType;
        this.connectionTimeout = b.connectionTimeout;
        this.reconnectWait = b.reconnectWait;
        this.maxReconnects = b.maxReconnects;
        this.pingInterval = b.pingInterval;
        this.shutdownTimeout = b.shutdownTimeout;
        this.jetStreamDomain = b.jetStreamDomain;
        this.jetStreamApiPrefix = b.jetStreamApiPrefix;
        this.jetStreamRequestTimeout = b.jetStreamRequestTimeout;
        this.publishMaxAttempts = b.publishMaxAttempts;
        this.publishRetryInitialBackoff = b.publishRetryInitialBackoff;
        this.publishRetryMaxBackoff = b.publishRetryMaxBackoff;
        this.listener = b.listener;
    }

    public static Builder builder() {
        return new Builder();
    }

    /** Builder pre-populated from {@code NATS_*} environment variables. See the README for the list. */
    public static Builder fromEnvironment() {
        return fromEnvironment(System::getenv);
    }

    /** Same as {@link #fromEnvironment()} with an injectable lookup (handy for tests). */
    public static Builder fromEnvironment(Function<String, String> env) {
        Builder b = new Builder();
        String url = blankToNull(env.apply("NATS_URL"));
        if (url != null) {
            for (String s : url.split(",")) {
                if (!s.isBlank()) {
                    b.server(s.trim());
                }
            }
        }
        String v;
        if ((v = blankToNull(env.apply("NATS_CONNECTION_NAME"))) != null) b.connectionName(v);
        String user = blankToNull(env.apply("NATS_USERNAME"));
        String pass = env.apply("NATS_PASSWORD");
        if (user != null) b.userPassword(user, pass == null ? "" : pass);
        if ((v = blankToNull(env.apply("NATS_TOKEN"))) != null) b.token(v);
        if ((v = blankToNull(env.apply("NATS_CREDS_FILE"))) != null) b.credentialsFile(v);
        String ts = blankToNull(env.apply("NATS_TLS_TRUSTSTORE"));
        if (ts != null) b.tlsTrustStore(ts, env.apply("NATS_TLS_TRUSTSTORE_PASSWORD"));
        String ks = blankToNull(env.apply("NATS_TLS_KEYSTORE"));
        if (ks != null) b.tlsKeyStore(ks, env.apply("NATS_TLS_KEYSTORE_PASSWORD"));
        if ((v = blankToNull(env.apply("NATS_JS_DOMAIN"))) != null) b.jetStreamDomain(v);
        if ((v = blankToNull(env.apply("NATS_JS_PREFIX"))) != null) b.jetStreamApiPrefix(v);
        return b;
    }

    private static String blankToNull(String s) {
        return s == null || s.isBlank() ? null : s;
    }

    // ---- accessors: read by the client and by platform tooling (com.company.messaging.spi) ----
    // password() and token() return secrets; they are never printed by toString().
    public List<String> servers() { return servers; }
    public String connectionName() { return connectionName; }
    public String username() { return username; }
    public String password() { return password; }
    public String token() { return token; }
    public String credentialsFile() { return credentialsFile; }
    public SSLContext sslContext() { return sslContext; }
    public String trustStorePath() { return trustStorePath; }
    public String trustStorePassword() { return trustStorePassword; }
    public String keyStorePath() { return keyStorePath; }
    public String keyStorePassword() { return keyStorePassword; }
    public String storeType() { return storeType; }
    public Duration connectionTimeout() { return connectionTimeout; }
    public Duration reconnectWait() { return reconnectWait; }
    public int maxReconnects() { return maxReconnects; }
    public Duration pingInterval() { return pingInterval; }
    public Duration shutdownTimeout() { return shutdownTimeout; }
    public String jetStreamDomain() { return jetStreamDomain; }
    public String jetStreamApiPrefix() { return jetStreamApiPrefix; }
    public Duration jetStreamRequestTimeout() { return jetStreamRequestTimeout; }
    public int publishMaxAttempts() { return publishMaxAttempts; }
    public Duration publishRetryInitialBackoff() { return publishRetryInitialBackoff; }
    public Duration publishRetryMaxBackoff() { return publishRetryMaxBackoff; }
    public ConnectionEventListener listener() { return listener; }

    public boolean tlsConfigured() {
        return sslContext != null || trustStorePath != null || keyStorePath != null;
    }

    private String authMode() {
        if (username != null) return "user-password";
        if (token != null) return "token";
        if (credentialsFile != null) return "credentials-file";
        return "none";
    }

    /** Never prints secrets. */
    @Override
    public String toString() {
        return "MessagingConfig{servers=" + servers
                + ", connectionName=" + connectionName
                + ", auth=" + authMode()
                + ", tls=" + tlsConfigured()
                + ", jetStreamDomain=" + jetStreamDomain
                + ", jetStreamApiPrefix=" + jetStreamApiPrefix
                + ", maxReconnects=" + maxReconnects
                + '}';
    }

    /** Builder for {@link MessagingConfig}. */
    public static final class Builder {
        private final List<String> servers = new ArrayList<>();
        private String connectionName;
        private String username;
        private String password;
        private String token;
        private String credentialsFile;
        private SSLContext sslContext;
        private String trustStorePath;
        private String trustStorePassword;
        private String keyStorePath;
        private String keyStorePassword;
        private String storeType = "PKCS12";
        private Duration connectionTimeout = Duration.ofSeconds(5);
        private Duration reconnectWait = Duration.ofSeconds(2);
        private int maxReconnects = -1; // unlimited: a long outage must not permanently kill the client
        private Duration pingInterval = Duration.ofSeconds(30);
        private Duration shutdownTimeout = Duration.ofSeconds(10);
        private String jetStreamDomain;
        private String jetStreamApiPrefix;
        private Duration jetStreamRequestTimeout = Duration.ofSeconds(5);
        private int publishMaxAttempts = 3;
        private Duration publishRetryInitialBackoff = Duration.ofMillis(100);
        private Duration publishRetryMaxBackoff = Duration.ofSeconds(2);
        private ConnectionEventListener listener = new ConnectionEventListener() { };

        private Builder() {
        }

        /** Adds a server URL, e.g. {@code nats://host:4222} or {@code tls://host:4222}. Call repeatedly for a cluster. */
        public Builder server(String url) {
            Objects.requireNonNull(url, "url");
            if (url.isBlank()) throw new IllegalArgumentException("server url must not be blank");
            servers.add(url.trim());
            return this;
        }

        public Builder servers(List<String> urls) {
            urls.forEach(this::server);
            return this;
        }

        /** Shown in the server's connection list; set it to the application name. */
        public Builder connectionName(String name) {
            this.connectionName = name;
            return this;
        }

        public Builder userPassword(String username, String password) {
            this.username = Objects.requireNonNull(username, "username");
            this.password = Objects.requireNonNull(password, "password");
            return this;
        }

        public Builder token(String token) {
            this.token = Objects.requireNonNull(token, "token");
            return this;
        }

        /** Path to a NATS {@code .creds} file (JWT + NKey seed). */
        public Builder credentialsFile(String path) {
            this.credentialsFile = Objects.requireNonNull(path, "path");
            return this;
        }

        /** Use a ready-made SSLContext. Mutually exclusive with the trust/key store setters. */
        public Builder sslContext(SSLContext sslContext) {
            this.sslContext = Objects.requireNonNull(sslContext, "sslContext");
            return this;
        }

        /** Trust store holding the CA that signed the server certificate. Omit to use the JVM default trust. */
        public Builder tlsTrustStore(String path, String password) {
            this.trustStorePath = Objects.requireNonNull(path, "path");
            this.trustStorePassword = password;
            return this;
        }

        /** Key store with the client certificate, for mutual TLS. */
        public Builder tlsKeyStore(String path, String password) {
            this.keyStorePath = Objects.requireNonNull(path, "path");
            this.keyStorePassword = password;
            return this;
        }

        /** Store type for the trust/key store files. Default {@code PKCS12}. */
        public Builder tlsStoreType(String type) {
            this.storeType = Objects.requireNonNull(type, "type");
            return this;
        }

        public Builder connectionTimeout(Duration d) {
            this.connectionTimeout = positive(d, "connectionTimeout");
            return this;
        }

        public Builder reconnectWait(Duration d) {
            this.reconnectWait = positive(d, "reconnectWait");
            return this;
        }

        /** Maximum reconnect attempts per server; {@code -1} (default) means unlimited. */
        public Builder maxReconnects(int max) {
            if (max < -1) throw new IllegalArgumentException("maxReconnects must be >= -1");
            this.maxReconnects = max;
            return this;
        }

        public Builder pingInterval(Duration d) {
            this.pingInterval = positive(d, "pingInterval");
            return this;
        }

        /** How long {@link MessagingClient#close()} waits for in-flight work to finish. Default 10s. */
        public Builder shutdownTimeout(Duration d) {
            this.shutdownTimeout = positive(d, "shutdownTimeout");
            return this;
        }

        /** JetStream domain (leaf-node / hub setups). Mutually exclusive with {@link #jetStreamApiPrefix}. */
        public Builder jetStreamDomain(String domain) {
            this.jetStreamDomain = domain;
            return this;
        }

        /** Custom JetStream API prefix (cross-account imports). Mutually exclusive with {@link #jetStreamDomain}. */
        public Builder jetStreamApiPrefix(String prefix) {
            this.jetStreamApiPrefix = prefix;
            return this;
        }

        /** Timeout for JetStream API calls and synchronous publish acks. Default 5s. */
        public Builder jetStreamRequestTimeout(Duration d) {
            this.jetStreamRequestTimeout = positive(d, "jetStreamRequestTimeout");
            return this;
        }

        /**
         * Retry policy for synchronous JetStream publishes. Retries only happen for publishes that carry a
         * message id (deduplication makes them safe) and only for retryable failures. Default: 3 attempts, 100ms..2s.
         */
        public Builder publishRetry(int maxAttempts, Duration initialBackoff, Duration maxBackoff) {
            if (maxAttempts < 1) throw new IllegalArgumentException("maxAttempts must be >= 1");
            this.publishMaxAttempts = maxAttempts;
            this.publishRetryInitialBackoff = positive(initialBackoff, "initialBackoff");
            this.publishRetryMaxBackoff = positive(maxBackoff, "maxBackoff");
            return this;
        }

        public Builder listener(ConnectionEventListener listener) {
            this.listener = Objects.requireNonNull(listener, "listener");
            return this;
        }

        public MessagingConfig build() {
            if (servers.isEmpty()) {
                throw new MessagingException(MessagingException.Kind.CONFIGURATION,
                        "At least one server URL is required (builder.server(...) or NATS_URL)");
            }
            int authModes = (username != null ? 1 : 0) + (token != null ? 1 : 0) + (credentialsFile != null ? 1 : 0);
            if (authModes > 1) {
                throw new MessagingException(MessagingException.Kind.CONFIGURATION,
                        "Configure only one authentication method: user/password, token or credentials file");
            }
            if (sslContext != null && (trustStorePath != null || keyStorePath != null)) {
                throw new MessagingException(MessagingException.Kind.CONFIGURATION,
                        "Use either sslContext(...) or the trust/key store setters, not both");
            }
            if (jetStreamDomain != null && jetStreamApiPrefix != null) {
                throw new MessagingException(MessagingException.Kind.CONFIGURATION,
                        "jetStreamDomain and jetStreamApiPrefix are mutually exclusive");
            }
            if (publishRetryMaxBackoff.compareTo(publishRetryInitialBackoff) < 0) {
                throw new MessagingException(MessagingException.Kind.CONFIGURATION,
                        "publish retry maxBackoff must be >= initialBackoff");
            }
            warnIfRetriesOutliveDuplicateWindow();
            return new MessagingConfig(this);
        }

        /** A retry that outlives the stream's duplicate window (default 2 min) can be stored twice. */
        private void warnIfRetriesOutliveDuplicateWindow() {
            long worst = (long) publishMaxAttempts * jetStreamRequestTimeout.toMillis();
            long backoff = publishRetryInitialBackoff.toMillis();
            for (int i = 1; i < publishMaxAttempts; i++) {
                worst += backoff;
                backoff = Math.min(publishRetryMaxBackoff.toMillis(), backoff * 2);
            }
            if (worst > 120_000) {
                LOG.log(System.Logger.Level.WARNING,
                        "Worst-case publish retry time is {0} ms, longer than JetStream's default 2-minute duplicate "
                                + "window; a late retry could be stored twice unless the stream's window is larger.", worst);
            }
        }

        private static Duration positive(Duration d, String name) {
            Objects.requireNonNull(d, name);
            if (d.isZero() || d.isNegative()) throw new IllegalArgumentException(name + " must be positive");
            return d;
        }
    }
}
