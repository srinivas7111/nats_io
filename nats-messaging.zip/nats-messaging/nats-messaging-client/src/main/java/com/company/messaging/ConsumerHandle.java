package com.company.messaging;

import io.nats.client.MessageConsumer;
import java.time.Duration;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Handle to a running continuous consumer.
 * <ul>
 *   <li>{@link #stop()} stops requesting new messages and returns immediately; the handle stays registered with the
 *       client until it is closed.</li>
 *   <li>{@link #close()} / {@link #awaitFinished(Duration)} stop, wait for the handler that is currently running, then
 *       <b>always</b> release the consumer, even when the wait times out (a warning is logged and the in-flight message,
 *       never having been acknowledged, is redelivered).</li>
 * </ul>
 * Messages the server already sent but whose handler had not started are redelivered later for the same reason.
 */
public final class ConsumerHandle implements AutoCloseable, ManagedResource {

    private static final System.Logger LOG = System.getLogger(ConsumerHandle.class.getName());
    private static final Duration DEFAULT_CLOSE_WAIT = Duration.ofSeconds(5);

    private final MessageConsumer consumer;
    private final Set<ManagedResource> registry;
    private final AtomicInteger inFlight;

    ConsumerHandle(MessageConsumer consumer, Set<ManagedResource> registry, AtomicInteger inFlight) {
        this.consumer = consumer;
        this.registry = registry;
        this.inFlight = inFlight;
        registry.add(this);
    }

    /** Stops pulling new messages and returns immediately. Idempotent. */
    public void stop() {
        stopResource();
    }

    /** True once {@link #stop()} was called. */
    public boolean isStopped() {
        return consumer.isStopped();
    }

    /** True once stopped and no handler is running any more. */
    public boolean isFinished() {
        return consumer.isStopped() && inFlight.get() == 0;
    }

    /**
     * Stops, waits for the running handler (up to {@code timeout}), then releases the consumer.
     *
     * @return true if the handler finished in time; false if the consumer was released while a handler was still running
     */
    public boolean awaitFinished(Duration timeout) {
        stop();
        return drain(timeout);
    }

    /** Internal: used by {@link MessagingClient#close()}. Use {@link #stop()} instead. */
    @Override
    public void stopResource() {
        try {
            consumer.stop();
        } catch (RuntimeException ignored) {
            // already closed
        }
    }

    /** Internal: used by {@link MessagingClient#close()}. Use {@link #awaitFinished(Duration)} instead. */
    @Override
    public boolean drain(Duration timeout) {
        long deadline = System.nanoTime() + timeout.toNanos();
        while (inFlight.get() > 0 && System.nanoTime() < deadline) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        boolean finished = inFlight.get() == 0;
        if (!finished) {
            LOG.log(System.Logger.Level.WARNING,
                    "A message handler was still running after {0} ms; releasing the consumer anyway. "
                            + "The in-flight message was not acknowledged and will be redelivered.", timeout.toMillis());
        }
        release();
        return finished;
    }

    private void release() {
        registry.remove(this);
        try {
            consumer.close(); // tears the subscription down now instead of after the pull request expires
        } catch (Exception ignored) {
            // already closed
        }
    }

    /** Stops and waits up to 5 seconds for the running handler, then releases the consumer. */
    @Override
    public void close() {
        awaitFinished(DEFAULT_CLOSE_WAIT);
    }
}
