package com.company.messaging.spi;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

/** Builds an {@link SSLContext} from key/trust store files. Package-private. */
final class TlsSupport {

    private TlsSupport() {
    }

    static SSLContext create(String trustStorePath, String trustStorePassword,
                             String keyStorePath, String keyStorePassword, String storeType)
            throws GeneralSecurityException, IOException {
        TrustManager[] trustManagers = null;
        KeyManager[] keyManagers = null;

        if (trustStorePath != null) {
            KeyStore trustStore = load(trustStorePath, trustStorePassword, storeType);
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(trustStore);
            trustManagers = tmf.getTrustManagers();
        }
        if (keyStorePath != null) {
            KeyStore keyStore = load(keyStorePath, keyStorePassword, storeType);
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(keyStore, keyStorePassword == null ? new char[0] : keyStorePassword.toCharArray());
            keyManagers = kmf.getKeyManagers();
        }
        // null trust managers => JVM default trust (cacerts); null key managers => no client certificate.
        SSLContext context = SSLContext.getInstance("TLS");
        context.init(keyManagers, trustManagers, null);
        return context;
    }

    private static KeyStore load(String path, String password, String type) throws GeneralSecurityException, IOException {
        KeyStore store = KeyStore.getInstance(type);
        try (InputStream in = Files.newInputStream(Path.of(path))) {
            store.load(in, password == null ? null : password.toCharArray());
        }
        return store;
    }
}
