package com.company.messaging;

import com.company.messaging.MessagingException.Kind;
import com.company.messaging.spi.ErrorMapper;
import io.nats.client.ConsumerContext;
import io.nats.client.FetchConsumeOptions;
import io.nats.client.FetchConsumer;
import io.nats.client.Message;
import io.nats.client.MessageConsumer;
import io.nats.client.api.ConsumerInfo;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * A pull consumer bound to an <b>existing</b> durable consumer. This class never creates consumers;
 * see {@link JetStreamAdmin} for development / bootstrap use.
 * <p>
 * Two styles are offered: {@link #consume(ConsumeOptions, MessageHandler)} for a long-running handler
 * (recommended), and {@link #fetch(int, Duration)} / {@link #next(Duration)} for explicit batch control.
 */
public final class PullConsumer {

    private static final System.Logger LOG = System.getLogger(PullConsumer.class.getName());

    private final String stream;
    private final String durable;
    private final ConsumerContext context;
    private final Set<ManagedResource> registry;

    PullConsumer(String stream, String durable, ConsumerContext context, Set<ManagedResource> registry) {
        this.stream = stream;
        this.durable = durable;
        this.context = context;
        this.registry = registry;
    }

    public String stream() {
        return stream;
    }

    public String durable() {
        return durable;
    }

    /**
     * Starts a continuous consumer that invokes {@code handler} for each message, one at a time, on a single thread
     * (first deliveries arrive in stream order; redeliveries can interleave). Reconnects, heartbeats and re-pulling
     * are handled for you.
     */
    public ConsumerHandle consume(ConsumeOptions options, MessageHandler handler) {
        java.util.Objects.requireNonNull(options, "options");
        java.util.Objects.requireNonNull(handler, "handler");
        java.util.concurrent.atomic.AtomicInteger inFlight = new java.util.concurrent.atomic.AtomicInteger();
        io.nats.client.MessageHandler wrapped = raw -> {
            inFlight.incrementAndGet();
            try {
                dispatch(raw, options, handler);
            } finally {
                inFlight.decrementAndGet();
            }
        };
        try {
            io.nats.client.ConsumeOptions natsOptions = io.nats.client.ConsumeOptions.builder()
                    .batchSize(options.batchSize())
                    .expiresIn(options.pullExpiry().toMillis())
                    .build();
            MessageConsumer mc = context.consume(natsOptions, wrapped);
            return new ConsumerHandle(mc, registry, inFlight);
        } catch (Exception e) {
            throw ErrorMapper.map("start consumer '" + durable + "' on stream '" + stream + "'", e);
        }
    }

    /** {@link #consume(ConsumeOptions, MessageHandler)} with {@link ConsumeOptions#defaults()}. */
    public ConsumerHandle consume(MessageHandler handler) {
        return consume(ConsumeOptions.defaults(), handler);
    }

    /**
     * Fetches up to {@code batchSize} messages, waiting at most {@code maxWait} (minimum 1 second).
     * Returns whatever arrived, possibly an empty list. The caller must settle each message.
     */
    public List<ReceivedMessage> fetch(int batchSize, Duration maxWait) {
        if (batchSize < 1) throw new IllegalArgumentException("batchSize must be >= 1");
        if (maxWait == null || maxWait.toMillis() < 1000) {
            throw new IllegalArgumentException("maxWait must be at least 1 second");
        }
        FetchConsumer fc = null;
        try {
            fc = context.fetch(FetchConsumeOptions.builder()
                    .maxMessages(batchSize)
                    .expiresIn(maxWait.toMillis())
                    .build());
            List<ReceivedMessage> out = new ArrayList<>();
            Message m;
            while ((m = fc.nextMessage()) != null) {
                out.add(ReceivedMessage.from(m));
            }
            return out;
        } catch (Exception e) {
            throw ErrorMapper.map("fetch from '" + durable + "'", e);
        } finally {
            if (fc != null) {
                try {
                    fc.stop();
                } catch (RuntimeException ignored) {
                    // nothing to do
                }
            }
        }
    }

    /** Fetches a single message, waiting at most {@code maxWait} (minimum 1 second). */
    public Optional<ReceivedMessage> next(Duration maxWait) {
        if (maxWait == null || maxWait.toMillis() < 1000) {
            throw new IllegalArgumentException("maxWait must be at least 1 second");
        }
        try {
            Message m = context.next(maxWait.toMillis());
            return Optional.ofNullable(m).map(ReceivedMessage::from);
        } catch (Exception e) {
            throw ErrorMapper.map("next from '" + durable + "'", e);
        }
    }

    /** Current server-side state of the consumer (pending, ack-pending, redelivered). */
    public ConsumerSummary info() {
        try {
            ConsumerInfo ci = context.getConsumerInfo();
            return new ConsumerSummary(ci.getStreamName(), ci.getName(), ci.getNumPending(),
                    ci.getNumAckPending(), ci.getRedelivered());
        } catch (Exception e) {
            throw ErrorMapper.map("consumer info '" + durable + "'", e);
        }
    }

    /**
     * Runs one delivery through the handler and settles it. Package-private for unit tests.
     * <ul>
     *   <li>handler returns: ack (unless {@code autoAck(false)} or the handler settled it);</li>
     *   <li>handler throws: {@code onFailure}, then nak with backoff or term after the poison limit;</li>
     *   <li>ack fails after a successful handler: warn only. The server redelivers after ackWait (at-least-once),
     *       and nak-ing a message that may already have been acked would be wrong;</li>
     *   <li>metadata unreadable: terminate + ERROR log + {@code onUnreadable} hook;</li>
     *   <li>JVM-fatal errors (OutOfMemoryError, LinkageError, ...) are rethrown untouched, the message stays
     *       unacknowledged and is redelivered later.</li>
     * </ul>
     */
    static void dispatch(Message raw, ConsumeOptions options, MessageHandler handler) {
        ReceivedMessage msg;
        try {
            msg = ReceivedMessage.from(raw);
        } catch (RuntimeException e) {
            terminateUnreadable(raw, options, e);
            return;
        }
        try {
            handler.handle(msg);
        } catch (Throwable t) {
            ErrorMapper.rethrowIfFatal(t);
            if (t instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            try {
                options.failureListener().accept(msg, t);
            } catch (RuntimeException listenerError) {
                LOG.log(System.Logger.Level.WARNING, "onFailure listener threw: " + listenerError, listenerError);
            }
            if (!msg.isSettled()) {
                settleFailure(msg, options);
            }
            return;
        }
        if (options.autoAck() && !msg.isSettled()) {
            try {
                msg.ack();
            } catch (RuntimeException e) {
                LOG.log(System.Logger.Level.WARNING,
                        "Handler succeeded but ack failed for stream sequence {0}; the server will redeliver it after "
                                + "ackWait, so handlers must be idempotent. Cause: {1}",
                        msg.metadata().streamSequence(), e.getMessage());
            }
        }
    }

    private static void terminateUnreadable(Message raw, ConsumeOptions options, RuntimeException cause) {
        String subject = raw.getSubject();
        LOG.log(System.Logger.Level.ERROR, "Unreadable JetStream delivery on subject ''{0}'' ({1}); terminating it",
                subject, cause.toString());
        try {
            raw.term();
        } catch (RuntimeException e) {
            LOG.log(System.Logger.Level.WARNING,
                    "Could not terminate the unreadable message; the server will redeliver it after ackWait: {0}", e.toString());
        }
        try {
            options.unreadableListener().accept(subject, cause);
        } catch (RuntimeException listenerError) {
            LOG.log(System.Logger.Level.WARNING, "onUnreadable listener threw: " + listenerError, listenerError);
        }
    }

    private static void settleFailure(ReceivedMessage msg, ConsumeOptions options) {
        try {
            long delivered = msg.metadata().deliveredCount();
            long limit = options.terminateAfterDeliveries();
            if (limit > 0 && delivered >= limit) {
                LOG.log(System.Logger.Level.WARNING, "Terminating poison message {0} after {1} deliveries",
                        msg.metadata().streamSequence(), delivered);
                msg.term();
            } else {
                msg.nakWithDelay(Backoff.retryDelay(options.retryBaseDelay(), options.retryMaxDelay(), delivered));
            }
        } catch (RuntimeException e) {
            // The server redelivers after ackWait anyway; never let this escape into the consumer thread.
            LOG.log(System.Logger.Level.WARNING, "Could not nak/term message: " + e, e);
        }
    }

    static MessagingException notProvisioned(String stream, String durable, MessagingException cause) {
        if (cause.kind() == Kind.CONSUMER_NOT_FOUND || cause.kind() == Kind.STREAM_NOT_FOUND) {
            return new MessagingException(cause.kind(),
                    "Consumer '" + durable + "' on stream '" + stream + "' was not found. "
                            + "This library does not create consumers; ask the platform team to provision it "
                            + "(or use JetStreamAdmin in development). Cause: " + cause.getMessage(),
                    cause, cause.serverErrorCode());
        }
        return cause;
    }
}
