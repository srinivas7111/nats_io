package com.company.messaging;

import java.time.Duration;

/** Redelivery delay calculation for failed messages. Package-private. */
final class Backoff {

    private Backoff() {
    }

    /** {@code base * 2^(deliveredCount-1)}, capped at {@code max}. deliveredCount below 1 is treated as 1. */
    static Duration retryDelay(Duration base, Duration max, long deliveredCount) {
        long attempt = Math.max(1L, deliveredCount);
        int shift = (int) Math.min(attempt - 1, 20L);
        long millis = base.toMillis() * (1L << shift);
        long capped = Math.min(millis < 0 ? Long.MAX_VALUE : millis, max.toMillis());
        return Duration.ofMillis(capped);
    }
}
