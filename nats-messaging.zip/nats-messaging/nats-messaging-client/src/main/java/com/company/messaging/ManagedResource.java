package com.company.messaging;

import java.time.Duration;

/** Something the client must stop before closing the connection. Package-private. */
interface ManagedResource {

    /** Stop accepting/pulling new work. Must be idempotent. */
    void stopResource();

    /** Wait until in-flight work is done, then release underlying resources. Returns false on timeout. */
    boolean drain(Duration timeout);
}
