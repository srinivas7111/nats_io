package com.company.messaging;

/** Current state of the connection to the NATS server(s). */
public enum ConnectionStatus {
    CONNECTING,
    CONNECTED,
    RECONNECTING,
    DISCONNECTED,
    CLOSED
}
