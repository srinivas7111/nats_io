package com.company.messaging;

import com.company.messaging.spi.ErrorMapper;
import io.nats.client.JetStream;
import java.util.Set;

/**
 * JetStream entry point for applications: publishing and consuming. Thread-safe.
 * <p>
 * Streams and consumers are provisioned by the platform team (see the separate {@code nats-messaging-admin}
 * artifact); this class deliberately has no way to create or delete them.
 */
public final class JetStreamClient {

    private final JetStream js;
    private final Set<ManagedResource> registry;
    private final JetStreamPublisher publisher;

    JetStreamClient(JetStream js, MessagingConfig config, Set<ManagedResource> registry) {
        this.js = js;
        this.registry = registry;
        this.publisher = new JetStreamPublisher(js, config);
    }

    /** The shared publisher. */
    public JetStreamPublisher publisher() {
        return publisher;
    }

    /**
     * Binds to an existing durable pull consumer. Fails fast with {@link MessagingException.Kind#CONSUMER_NOT_FOUND}
     * (or {@code STREAM_NOT_FOUND}) if it has not been provisioned; it is never created implicitly.
     */
    public PullConsumer consumer(String stream, String durable) {
        java.util.Objects.requireNonNull(stream, "stream");
        java.util.Objects.requireNonNull(durable, "durable");
        try {
            return new PullConsumer(stream, durable, js.getConsumerContext(stream, durable), registry);
        } catch (Exception e) {
            throw PullConsumer.notProvisioned(stream, durable,
                    ErrorMapper.map("bind consumer '" + durable + "' on stream '" + stream + "'", e));
        }
    }
}
