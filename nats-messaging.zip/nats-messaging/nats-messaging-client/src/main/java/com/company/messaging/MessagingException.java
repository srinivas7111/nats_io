package com.company.messaging;

/**
 * The only exception type thrown by this library for runtime failures.
 * <p>
 * Callers branch on {@link #kind()} (or {@link #isRetryable()}) and never need to know about JNATS exception types.
 */
public class MessagingException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /** Classification of a failure. */
    public enum Kind {
        /** Invalid or incomplete configuration (bad credentials file, TLS store unreadable, ...). */
        CONFIGURATION(false),
        /** The call itself was invalid (blank subject, payload too large, illegal argument, ...). */
        INVALID_REQUEST(false),
        /** Could not reach, or lost, the server. Usually transient. */
        CONNECTION(true),
        /** The server did not answer in time. Usually transient. */
        TIMEOUT(true),
        /** The server answered that it cannot serve the request right now (e.g. no responders, 503). */
        UNAVAILABLE(true),
        /** No stream exists for the subject / name. Streams are normally provisioned by the platform team. */
        STREAM_NOT_FOUND(false),
        /** The named durable consumer does not exist. Consumers are normally provisioned by the platform team. */
        CONSUMER_NOT_FOUND(false),
        /** A publish precondition (expected stream / sequence / message id) was not met. */
        PUBLISH_REJECTED(false),
        /** Authentication or authorization failed. */
        AUTHORIZATION(false),
        /** The client (or the subscription) has already been closed. */
        CLOSED(false),
        /** The calling thread was interrupted. The thread's interrupt flag has been restored. */
        INTERRUPTED(false),
        /** Anything that does not fit the categories above. */
        UNKNOWN(false);

        private final boolean retryable;

        Kind(boolean retryable) {
            this.retryable = retryable;
        }

        /** Whether retrying the same operation later can reasonably succeed. */
        public boolean retryable() {
            return retryable;
        }
    }

    private final Kind kind;
    private final int serverErrorCode;

    public MessagingException(Kind kind, String message) {
        this(kind, message, null, 0);
    }

    public MessagingException(Kind kind, String message, Throwable cause) {
        this(kind, message, cause, 0);
    }

    public MessagingException(Kind kind, String message, Throwable cause, int serverErrorCode) {
        super(message, cause);
        this.kind = kind == null ? Kind.UNKNOWN : kind;
        this.serverErrorCode = serverErrorCode;
    }

    public Kind kind() {
        return kind;
    }

    /** Shortcut for {@code kind().retryable()}. */
    public boolean isRetryable() {
        return kind.retryable();
    }

    /** JetStream API error code reported by the server, or 0 when not applicable. Useful for support tickets. */
    public int serverErrorCode() {
        return serverErrorCode;
    }
}
