package com.company.messaging;

import java.time.Instant;

/**
 * JetStream delivery metadata of a received message.
 *
 * @param stream           stream the message is stored in
 * @param consumer         durable consumer that delivered it
 * @param streamSequence   position in the stream
 * @param consumerSequence position in the consumer's delivery order
 * @param deliveredCount   1 on first delivery; greater than 1 means this is a redelivery
 * @param pending          messages still waiting for this consumer
 * @param timestamp        when the server stored the message
 * @param domain           JetStream domain, may be null
 */
public record MessageMetadata(String stream, String consumer, long streamSequence, long consumerSequence,
                              long deliveredCount, long pending, Instant timestamp, String domain) {

    public boolean isRedelivery() {
        return deliveredCount > 1;
    }
}
