package com.company.messaging;

import com.company.messaging.MessagingException.Kind;
import com.company.messaging.spi.ErrorMapper;
import io.nats.client.JetStream;
import io.nats.client.Message;
import io.nats.client.PublishOptions;
import io.nats.client.api.PublishAck;
import io.nats.client.impl.NatsMessage;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

/** Publishes to JetStream and returns the server's acknowledgement. Thread-safe. */
public final class JetStreamPublisher {

    private static final System.Logger LOG = System.getLogger(JetStreamPublisher.class.getName());

    private final JetStream js;
    private final MessagingConfig config;

    JetStreamPublisher(JetStream js, MessagingConfig config) {
        this.js = js;
        this.config = config;
    }

    /** Publishes and waits for the stream acknowledgement. */
    public PublishResult publish(String subject, byte[] payload) {
        return publish(PublishRequest.of(subject, payload));
    }

    /**
     * Publishes and waits for the stream acknowledgement.
     * <p>
     * If the request has a message id, transient failures ({@link MessagingException#isRetryable()}) are retried
     * according to {@link MessagingConfig.Builder#publishRetry}. Without a message id there is no retry, because
     * a lost ack followed by a retry would store the message twice.
     * <p>
     * <b>This call blocks the calling thread</b>, including while it waits between retries. The worst case is
     * {@code attempts * jetStreamRequestTimeout + sum of back-offs} (defaults: 3 x 5s + 0.3s, about 15s). Use
     * {@link #publishAsync(PublishRequest)} from latency-sensitive or event-loop threads. The total retry time must
     * stay below the stream's duplicate window (default 2 minutes), otherwise a retry can be stored a second time.
     *
     * @throws MessagingException {@link Kind#STREAM_NOT_FOUND} when no stream captures the subject, among others
     */
    public PublishResult publish(PublishRequest request) {
        int attempts = request.messageId() != null ? config.publishMaxAttempts() : 1;
        Duration backoff = config.publishRetryInitialBackoff();
        for (int attempt = 1; ; attempt++) {
            try {
                return toResult(send(request));
            } catch (RuntimeException | java.io.IOException | io.nats.client.JetStreamApiException e) {
                MessagingException me = ErrorMapper.map("publish to '" + request.subject() + "'", e);
                if (!me.isRetryable() || attempt >= attempts) {
                    throw me;
                }
                LOG.log(System.Logger.Level.WARNING, "publish attempt {0}/{1} failed ({2}); retrying in {3} ms",
                        attempt, attempts, me.kind(), backoff.toMillis());
                try {
                    Thread.sleep(backoff.toMillis());
                } catch (InterruptedException ie) {
                    throw ErrorMapper.map("publish", ie);
                }
                backoff = backoff.multipliedBy(2).compareTo(config.publishRetryMaxBackoff()) > 0
                        ? config.publishRetryMaxBackoff() : backoff.multipliedBy(2);
            }
        }
    }

    /**
     * Publishes without blocking. The future completes with the acknowledgement, or exceptionally with a
     * {@link MessagingException}. No automatic retry is performed; the caller owns retry policy for async publishes.
     */
    public CompletableFuture<PublishResult> publishAsync(PublishRequest request) {
        CompletableFuture<PublishResult> out = new CompletableFuture<>();
        try {
            CompletableFuture<PublishAck> f = request.hasPublishOptions()
                    ? js.publishAsync(toMessage(request), toOptions(request))
                    : js.publishAsync(toMessage(request));
            f.whenComplete((ack, err) -> {
                if (err != null) {
                    out.completeExceptionally(ErrorMapper.map("async publish to '" + request.subject() + "'", err));
                } else {
                    out.complete(toResult(ack));
                }
            });
        } catch (RuntimeException e) {
            out.completeExceptionally(ErrorMapper.map("async publish to '" + request.subject() + "'", e));
        }
        return out;
    }

    private PublishAck send(PublishRequest request) throws java.io.IOException, io.nats.client.JetStreamApiException {
        Message msg = toMessage(request);
        return request.hasPublishOptions() ? js.publish(msg, toOptions(request)) : js.publish(msg);
    }

    private static Message toMessage(PublishRequest r) {
        return NatsMessage.builder()
                .subject(r.subject())
                .headers(HeaderCodec.toNats(r.headers()))
                .data(r.payload())
                .build();
    }

    private static PublishOptions toOptions(PublishRequest r) {
        PublishOptions.Builder b = PublishOptions.builder();
        if (r.messageId() != null) b.messageId(r.messageId());
        if (r.expectedStream() != null) b.expectedStream(r.expectedStream());
        if (r.expectedLastSequence() != null) b.expectedLastSequence(r.expectedLastSequence());
        if (r.expectedLastSubjectSequence() != null) b.expectedLastSubjectSequence(r.expectedLastSubjectSequence());
        if (r.expectedLastMessageId() != null) b.expectedLastMsgId(r.expectedLastMessageId());
        return b.build();
    }

    private static PublishResult toResult(PublishAck ack) {
        return new PublishResult(ack.getStream(), ack.getSeqno(), ack.isDuplicate(), ack.getDomain());
    }
}
