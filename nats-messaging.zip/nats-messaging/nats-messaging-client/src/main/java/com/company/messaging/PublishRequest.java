package com.company.messaging;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * A JetStream publish. Create with {@link #builder(String)} or the {@code of} shortcuts.
 * <p>
 * Set {@link Builder#messageId(String)} for <b>idempotent publishing</b>: the server drops duplicates with the same id
 * inside the stream's duplicate window, and the client can then safely retry on transient failures.
 */
public final class PublishRequest {

    private final String subject;
    private final byte[] payload;
    private final Map<String, List<String>> headers;
    private final String messageId;
    private final String expectedStream;
    private final Long expectedLastSequence;
    private final Long expectedLastSubjectSequence;
    private final String expectedLastMessageId;

    private PublishRequest(Builder b) {
        this.subject = b.subject;
        this.payload = b.payload;
        this.headers = Map.copyOf(b.headers);
        this.messageId = b.messageId;
        this.expectedStream = b.expectedStream;
        this.expectedLastSequence = b.expectedLastSequence;
        this.expectedLastSubjectSequence = b.expectedLastSubjectSequence;
        this.expectedLastMessageId = b.expectedLastMessageId;
    }

    public static Builder builder(String subject) {
        return new Builder(subject);
    }

    public static PublishRequest of(String subject, byte[] payload) {
        return builder(subject).payload(payload).build();
    }

    public static PublishRequest of(String subject, String utf8Payload) {
        return builder(subject).payload(utf8Payload).build();
    }

    public String subject() { return subject; }
    public byte[] payload() { return payload; }
    public Map<String, List<String>> headers() { return headers; }
    public String messageId() { return messageId; }
    public String expectedStream() { return expectedStream; }
    public Long expectedLastSequence() { return expectedLastSequence; }
    public Long expectedLastSubjectSequence() { return expectedLastSubjectSequence; }
    public String expectedLastMessageId() { return expectedLastMessageId; }

    boolean hasPublishOptions() {
        return messageId != null || expectedStream != null || expectedLastSequence != null
                || expectedLastSubjectSequence != null || expectedLastMessageId != null;
    }

    public static final class Builder {
        private final String subject;
        private byte[] payload = new byte[0];
        private final Map<String, List<String>> headers = new LinkedHashMap<>();
        private String messageId;
        private String expectedStream;
        private Long expectedLastSequence;
        private Long expectedLastSubjectSequence;
        private String expectedLastMessageId;

        private Builder(String subject) {
            Objects.requireNonNull(subject, "subject");
            if (subject.isBlank() || subject.chars().anyMatch(Character::isWhitespace)
                    || subject.contains("*") || subject.contains(">")) {
                throw new IllegalArgumentException(
                        "publish subject must be non-blank, without whitespace or wildcards: '" + subject + "'");
            }
            this.subject = subject;
        }

        public Builder payload(byte[] payload) {
            this.payload = payload == null ? new byte[0] : payload;
            return this;
        }

        public Builder payload(String utf8) {
            this.payload = utf8 == null ? new byte[0] : utf8.getBytes(StandardCharsets.UTF_8);
            return this;
        }

        /** Adds a header value (headers may have several values). */
        public Builder header(String name, String value) {
            Objects.requireNonNull(name, "name");
            Objects.requireNonNull(value, "value");
            headers.computeIfAbsent(name, k -> new java.util.ArrayList<>()).add(value);
            return this;
        }

        /** Deduplication id ({@code Nats-Msg-Id}). Enables safe automatic retries. */
        public Builder messageId(String id) {
            this.messageId = id;
            return this;
        }

        /** Fail unless the subject is captured by this stream. */
        public Builder expectedStream(String stream) {
            this.expectedStream = stream;
            return this;
        }

        /** Optimistic concurrency: fail unless the stream's last sequence equals this value. */
        public Builder expectedLastSequence(long sequence) {
            this.expectedLastSequence = sequence;
            return this;
        }

        /** Optimistic concurrency per subject: fail unless the subject's last sequence equals this value. */
        public Builder expectedLastSubjectSequence(long sequence) {
            this.expectedLastSubjectSequence = sequence;
            return this;
        }

        /** Fail unless the last message id stored in the stream equals this value. */
        public Builder expectedLastMessageId(String id) {
            this.expectedLastMessageId = id;
            return this;
        }

        public PublishRequest build() {
            return new PublishRequest(this);
        }
    }
}
