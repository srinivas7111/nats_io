package com.company.messaging.spi;

import com.company.messaging.MessagingException;
import com.company.messaging.MessagingException.Kind;
import io.nats.client.AuthenticationException;
import io.nats.client.JetStreamApiException;
import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

/**
 * Translates JNATS / JDK exceptions into {@link MessagingException}.
 * <p>
 * <b>Platform tooling only.</b> This package ({@code com.company.messaging.spi}) is shared by the client and the admin
 * artifact. Application code must not depend on it.
 */
public final class ErrorMapper {

    private ErrorMapper() {
    }

    public static MessagingException map(String operation, Throwable error) {
        Throwable t = unwrap(error);
        if (t instanceof MessagingException me) {
            return me;
        }
        if (t instanceof InterruptedException) {
            Thread.currentThread().interrupt();
            return new MessagingException(Kind.INTERRUPTED, operation + " interrupted", t);
        }
        if (t instanceof JetStreamApiException js) {
            return mapJetStream(operation, js);
        }
        if (t instanceof AuthenticationException) {
            return new MessagingException(Kind.AUTHORIZATION, operation + " failed: authentication error", t);
        }
        if (t instanceof TimeoutException) {
            return new MessagingException(Kind.TIMEOUT, operation + " timed out", t);
        }
        if (t instanceof IllegalArgumentException) {
            return new MessagingException(Kind.INVALID_REQUEST, operation + " rejected: " + t.getMessage(), t);
        }
        String msg = t.getMessage() == null ? "" : t.getMessage();
        String lower = msg.toLowerCase(Locale.ROOT);
        if (t instanceof IllegalStateException && lower.contains("closed")) {
            return new MessagingException(Kind.CLOSED, operation + " failed: connection is closed", t);
        }
        if (lower.contains("authorization violation") || lower.contains("authentication")
                || lower.contains("permissions violation")) {
            return new MessagingException(Kind.AUTHORIZATION, operation + " failed: " + msg, t);
        }
        if (lower.contains("no responders") || lower.contains("503")) {
            return new MessagingException(Kind.UNAVAILABLE, operation + " failed: no responders / service unavailable", t, 503);
        }
        if (lower.contains("timeout") || lower.contains("timed out")) {
            return new MessagingException(Kind.TIMEOUT, operation + " timed out: " + msg, t);
        }
        if (t instanceof IOException) {
            return new MessagingException(Kind.CONNECTION, operation + " failed: " + msg, t);
        }
        return new MessagingException(Kind.UNKNOWN, operation + " failed: " + t, t);
    }

    /**
     * Rethrows JVM-level fatal errors ({@link VirtualMachineError} such as OutOfMemoryError, {@link LinkageError}),
     * which must never be swallowed or turned into a message redelivery. Returns normally for everything else.
     */
    public static void rethrowIfFatal(Throwable t) {
        if (t instanceof VirtualMachineError || t instanceof LinkageError) {
            throw (Error) t;
        }
    }

    private static MessagingException mapJetStream(String operation, JetStreamApiException e) {
        int api = e.getApiErrorCode();
        String desc = e.getErrorDescription() == null ? "" : e.getErrorDescription();
        String lower = desc.toLowerCase(Locale.ROOT);
        Kind kind;
        if (api == 10059 || lower.contains("stream not found")) {
            kind = Kind.STREAM_NOT_FOUND;
        } else if (api == 10014 || lower.contains("consumer not found")) {
            kind = Kind.CONSUMER_NOT_FOUND;
        } else if (lower.contains("wrong last") || lower.contains("expected stream")) {
            kind = Kind.PUBLISH_REJECTED;
        } else if (lower.contains("not enabled")) {
            kind = Kind.CONFIGURATION;
        } else if (e.getErrorCode() == 503) {
            kind = Kind.UNAVAILABLE;
        } else if (e.getErrorCode() == 401 || e.getErrorCode() == 403 || lower.contains("permission")) {
            kind = Kind.AUTHORIZATION;
        } else {
            kind = Kind.UNKNOWN;
        }
        return new MessagingException(kind, operation + " failed: " + desc + " (JetStream error " + api + ")", e, api);
    }

    private static Throwable unwrap(Throwable t) {
        Throwable cur = t;
        while ((cur instanceof CompletionException || cur instanceof ExecutionException) && cur.getCause() != null) {
            cur = cur.getCause();
        }
        return cur;
    }
}
