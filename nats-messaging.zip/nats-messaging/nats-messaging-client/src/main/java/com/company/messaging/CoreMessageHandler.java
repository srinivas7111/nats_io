package com.company.messaging;

/** Receives plain NATS messages. Runs on a dedicated thread per subscription; exceptions are logged and swallowed. */
@FunctionalInterface
public interface CoreMessageHandler {
    void handle(CoreMessage message) throws Exception;
}
