package com.company.messaging;

/**
 * Optional callbacks for connection lifecycle and asynchronous errors. All methods are no-ops by default.
 * <p>
 * Callbacks run on a library thread: keep them fast and non-blocking (set a flag, bump a metric, log).
 * Exceptions thrown from a callback are caught and logged; they never affect the connection.
 */
public interface ConnectionEventListener {

    default void onConnected() {
    }

    /** The connection was lost; the client will try to reconnect automatically. */
    default void onDisconnected() {
    }

    default void onReconnected() {
    }

    /** The connection is permanently closed (explicit close, or reconnect attempts exhausted). */
    default void onClosed() {
    }

    /** The server announced it is shutting down; clients are expected to move to another server. */
    default void onLameDuck() {
    }

    /** Asynchronous error (permission violation, slow consumer, ...). {@code cause} may be null. */
    default void onError(String description, Throwable cause) {
    }
}
