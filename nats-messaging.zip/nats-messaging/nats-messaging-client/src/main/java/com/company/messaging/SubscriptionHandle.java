package com.company.messaging;

import io.nats.client.Connection;
import io.nats.client.Dispatcher;
import java.time.Duration;
import java.util.Set;

/** Handle to a core NATS subscription. Close it to unsubscribe. */
public final class SubscriptionHandle implements AutoCloseable, ManagedResource {

    private final Connection connection;
    private final Dispatcher dispatcher;
    private final Set<ManagedResource> registry;
    private volatile boolean closed;

    SubscriptionHandle(Connection connection, Dispatcher dispatcher, Set<ManagedResource> registry) {
        this.connection = connection;
        this.dispatcher = dispatcher;
        this.registry = registry;
        registry.add(this);
    }

    public boolean isClosed() {
        return closed;
    }

    /** Internal: used by {@link MessagingClient#close()}. Use {@link #close()} instead. */
    @Override
    public void stopResource() {
        if (closed) {
            return;
        }
        closed = true;
        registry.remove(this);
        try {
            connection.closeDispatcher(dispatcher);
        } catch (RuntimeException ignored) {
            // connection already closed
        }
    }

    /** Internal. */
    @Override
    public boolean drain(Duration timeout) {
        return true; // closeDispatcher is synchronous
    }

    @Override
    public void close() {
        stopResource();
    }
}
