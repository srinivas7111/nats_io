package com.company.messaging;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import com.company.messaging.MessagingException.Kind;
import com.company.messaging.admin.ConsumerSpec;
import com.company.messaging.admin.MessagingAdmin;
import com.company.messaging.admin.StreamSpec;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.CountDownLatch;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * Runs against a real JetStream-enabled server. Start one with {@code nats-server -js} and run with
 * {@code NATS_URL=nats://localhost:4222}. Skipped automatically when NATS_URL is not set.
 */
@SuppressWarnings("try")
class JetStreamIntegrationTest {

    private static MessagingClient client;
    private static JetStreamClient js;
    private static MessagingAdmin admin;
    private static String url;
    private static final AtomicInteger SEQ = new AtomicInteger();
    private static final String RUN = Long.toString(System.nanoTime(), 36).toUpperCase();

    @BeforeAll
    static void connect() {
        url = System.getenv("NATS_URL");
        assumeTrue(url != null && !url.isBlank(), "NATS_URL not set; skipping integration tests");
        client = MessagingClient.connect(MessagingConfig.builder().server(url).connectionName("integration-test").build());
        js = client.jetStream();
        // provisioning goes through the separate admin artifact, exactly as the platform team would do it
        admin = MessagingAdmin.connect(MessagingConfig.builder().server(url).connectionName("integration-admin").build());
    }

    @AfterAll
    static void close() {
        if (client != null) {
            client.close();
        }
        if (admin != null) {
            admin.close();
        }
    }

    /** Unique stream + subject so tests never interfere. */
    private record Fixture(String stream, String subject) {
    }

    private static Fixture fixture() {
        String id = RUN + SEQ.incrementAndGet();
        Fixture f = new Fixture("S" + id, "it." + id + ".events");
        admin.createStreamIfAbsent(StreamSpec.builder(f.stream(), f.subject()).storage(StreamSpec.Storage.MEMORY).build());
        return f;
    }

    private static void awaitTrue(java.util.function.BooleanSupplier cond, long timeoutMs) throws InterruptedException {
        long end = System.currentTimeMillis() + timeoutMs;
        while (!cond.getAsBoolean() && System.currentTimeMillis() < end) {
            Thread.sleep(25);
        }
    }

    @Test
    void publishReturnsAckAndDetectsDuplicates() {
        Fixture f = fixture();
        JetStreamPublisher pub = js.publisher();
        PublishResult r1 = pub.publish(PublishRequest.builder(f.subject()).payload("hello").messageId("m-1").build());
        assertEquals(f.stream(), r1.stream());
        assertEquals(1L, r1.sequence());
        assertFalse(r1.duplicate());
        PublishResult r2 = pub.publish(PublishRequest.builder(f.subject()).payload("hello").messageId("m-1").build());
        assertTrue(r2.duplicate());
        assertEquals(1L, r2.sequence());
        assertEquals(1L, admin.streamInfo(f.stream()).orElseThrow().messages());
    }

    @Test
    void publishWithoutMatchingStreamFailsWithClearKind() {
        MessagingException e = assertThrows(MessagingException.class,
                () -> js.publisher().publish("no.stream.for." + RUN, new byte[]{1}));
        assertTrue(e.kind() == Kind.STREAM_NOT_FOUND || e.kind() == Kind.UNAVAILABLE, "kind=" + e.kind() + " " + e.getMessage());
    }

    @Test
    void expectationFailureIsPublishRejectedAndNotRetried() {
        Fixture f = fixture();
        MessagingException e = assertThrows(MessagingException.class, () -> js.publisher().publish(
                PublishRequest.builder(f.subject()).payload("x").messageId("id-9").expectedLastSequence(99).build()));
        assertEquals(Kind.PUBLISH_REJECTED, e.kind(), e.getMessage());
        assertFalse(e.isRetryable());
    }

    @Test
    void asyncPublishAcknowledgesEverything() throws Exception {
        Fixture f = fixture();
        List<CompletableFuture<PublishResult>> futures = new ArrayList<>();
        for (int i = 0; i < 25; i++) {
            futures.add(js.publisher().publishAsync(PublishRequest.of(f.subject(), "m" + i)));
        }
        List<Long> seqs = new ArrayList<>();
        for (var fut : futures) {
            seqs.add(fut.get(5, TimeUnit.SECONDS).sequence());
        }
        Collections.sort(seqs);
        assertEquals(1L, seqs.get(0).longValue());
        assertEquals(25L, seqs.get(24).longValue());
    }

    @Test
    void consumeDeliversHeadersMetadataAndAcks() throws Exception {
        Fixture f = fixture();
        admin.createOrUpdateConsumer(ConsumerSpec.builder(f.stream(), "worker").build());
        for (int i = 0; i < 5; i++) {
            js.publisher().publish(PublishRequest.builder(f.subject()).payload("p" + i).header("trace-id", "t-" + i).build());
        }
        BlockingQueue<ReceivedMessage> got = new LinkedBlockingQueue<>();
        PullConsumer consumer = js.consumer(f.stream(), "worker");
        try (ConsumerHandle h = consumer.consume(got::add)) {
            for (int i = 0; i < 5; i++) {
                ReceivedMessage m = got.poll(10, TimeUnit.SECONDS);
                assertNotNull(m, "message " + i + " not delivered");
                assertEquals("p" + i, m.text());
                assertEquals("t-" + i, m.header("trace-id").orElseThrow());
                assertEquals(i + 1L, m.metadata().streamSequence());
                assertEquals(1L, m.metadata().deliveredCount());
                assertEquals(f.stream(), m.metadata().stream());
            }
            awaitTrue(() -> consumer.info().ackPending() == 0 && consumer.info().pending() == 0, 5000);
            assertEquals(0L, consumer.info().ackPending());
            assertEquals(0L, consumer.info().pending());
        }
    }


    @Test
    void concurrentPublishersAreThreadSafe() throws Exception {
        Fixture f = fixture();
        int threads = 8;
        int perThread = 100;
        java.util.Set<Long> sequences = java.util.concurrent.ConcurrentHashMap.newKeySet();
        List<Thread> workers = new ArrayList<>();
        List<Throwable> errors = new CopyOnWriteArrayList<>();
        CountDownLatch go = new CountDownLatch(1);
        for (int t = 0; t < threads; t++) {
            final int id = t;
            Thread w = new Thread(() -> {
                try {
                    go.await();
                    for (int i = 0; i < perThread; i++) {
                        PublishResult r = js.publisher().publish(PublishRequest.builder(f.subject())
                                .payload("t" + id + "-" + i).messageId("c-" + id + "-" + i).build());
                        sequences.add(r.sequence());
                    }
                } catch (Throwable e) {
                    errors.add(e);
                }
            });
            w.start();
            workers.add(w);
        }
        go.countDown();
        for (Thread w : workers) {
            w.join(60_000);
        }
        assertEquals(List.of(), errors);
        assertEquals(threads * perThread, sequences.size()); // every publish got its own sequence
        assertEquals((long) threads * perThread, admin.streamInfo(f.stream()).orElseThrow().messages());
    }

    @Test
    void handlerRunsOneMessageAtATimeInStreamOrder() throws Exception {
        Fixture f = fixture();
        admin.createOrUpdateConsumer(ConsumerSpec.builder(f.stream(), "serial").build());
        int total = 300;
        for (int i = 0; i < total; i++) {
            js.publisher().publishAsync(PublishRequest.of(f.subject(), "n" + i));
        }
        awaitTrue(() -> admin.streamInfo(f.stream()).orElseThrow().messages() == total, 10_000);

        AtomicInteger running = new AtomicInteger();
        AtomicInteger maxRunning = new AtomicInteger();
        AtomicLong lastSeq = new AtomicLong();
        AtomicInteger outOfOrder = new AtomicInteger();
        AtomicInteger done = new AtomicInteger();
        try (ConsumerHandle h = js.consumer(f.stream(), "serial").consume(m -> {
            maxRunning.accumulateAndGet(running.incrementAndGet(), Math::max);
            if (m.metadata().streamSequence() <= lastSeq.get()) {
                outOfOrder.incrementAndGet();
            }
            lastSeq.set(m.metadata().streamSequence());
            Thread.sleep(1);
            running.decrementAndGet();
            done.incrementAndGet();
        })) {
            awaitTrue(() -> done.get() == total, 30_000);
        }
        assertEquals(total, done.get());
        assertEquals(1, maxRunning.get(), "a consumer must never run its handler concurrently");
        assertEquals(0, outOfOrder.get());
    }

    @Test
    void sameMessageIdOutsideTheDuplicateWindowIsStoredAgain() throws Exception {
        // Documents why retry time must stay below the stream's duplicate window.
        String id = RUN + SEQ.incrementAndGet();
        String stream = "W" + id;
        String subject = "it." + id + ".win";
        admin.createStreamIfAbsent(StreamSpec.builder(stream, subject).storage(StreamSpec.Storage.MEMORY)
                .duplicateWindow(Duration.ofSeconds(1)).build());
        PublishRequest req = PublishRequest.builder(subject).payload("x").messageId("same-id").build();
        assertFalse(js.publisher().publish(req).duplicate());
        assertTrue(js.publisher().publish(req).duplicate(), "inside the window the server drops it");
        Thread.sleep(1600);
        PublishResult late = js.publisher().publish(req);
        assertFalse(late.duplicate(), "outside the window the same id is accepted again");
        assertEquals(2L, admin.streamInfo(stream).orElseThrow().messages());
    }

    @Test
    void failingHandlerIsRedeliveredWithIncreasingDeliveryCount() throws Exception {
        Fixture f = fixture();
        admin.createOrUpdateConsumer(ConsumerSpec.builder(f.stream(), "retry").build());
        js.publisher().publish(f.subject(), "boom".getBytes());
        List<Long> deliveries = new CopyOnWriteArrayList<>();
        ConsumeOptions opts = ConsumeOptions.builder().retryDelay(Duration.ofMillis(100), Duration.ofSeconds(1)).build();
        try (ConsumerHandle h = js.consumer(f.stream(), "retry").consume(opts, m -> {
            deliveries.add(m.metadata().deliveredCount());
            if (m.metadata().deliveredCount() < 3) {
                throw new IllegalStateException("transient failure");
            }
        })) {
            awaitTrue(() -> deliveries.size() >= 3, 10_000);
        }
        assertEquals(List.of(1L, 2L, 3L), deliveries.subList(0, 3));
    }

    @Test
    void poisonMessageIsTerminatedAfterLimit() throws Exception {
        Fixture f = fixture();
        admin.createOrUpdateConsumer(ConsumerSpec.builder(f.stream(), "poison").build());
        js.publisher().publish(f.subject(), "bad".getBytes());
        AtomicInteger attempts = new AtomicInteger();
        List<Throwable> failures = new CopyOnWriteArrayList<>();
        ConsumeOptions opts = ConsumeOptions.builder()
                .retryDelay(Duration.ofMillis(50), Duration.ofMillis(200))
                .terminateAfterDeliveries(3)
                .onFailure((m, t) -> failures.add(t))
                .build();
        PullConsumer consumer = js.consumer(f.stream(), "poison");
        try (ConsumerHandle h = consumer.consume(opts, m -> {
            attempts.incrementAndGet();
            throw new RuntimeException("always fails");
        })) {
            awaitTrue(() -> attempts.get() >= 3, 10_000);
            Thread.sleep(1500); // would have been redelivered again if not terminated
            assertEquals(3, attempts.get());
            assertEquals(3, failures.size());
            assertEquals(0L, consumer.info().ackPending());
        }
    }

    @Test
    void handlerCanSettleManuallyWithoutAutoAck() throws Exception {
        Fixture f = fixture();
        admin.createOrUpdateConsumer(ConsumerSpec.builder(f.stream(), "manual").build());
        js.publisher().publish(f.subject(), "x".getBytes());
        BlockingQueue<Boolean> settledInHandler = new LinkedBlockingQueue<>();
        PullConsumer consumer = js.consumer(f.stream(), "manual");
        try (ConsumerHandle h = consumer.consume(ConsumeOptions.builder().autoAck(false).build(), m -> {
            m.ackSync(Duration.ofSeconds(2));
            settledInHandler.add(m.isSettled());
        })) {
            assertEquals(Boolean.TRUE, settledInHandler.poll(10, TimeUnit.SECONDS));
            awaitTrue(() -> consumer.info().ackPending() == 0, 3000);
            assertEquals(0L, consumer.info().ackPending());
        }
    }

    @Test
    void fetchReturnsBatchThenEmpty() throws Exception {
        Fixture f = fixture();
        admin.createOrUpdateConsumer(ConsumerSpec.builder(f.stream(), "batch").build());
        for (int i = 0; i < 3; i++) {
            js.publisher().publish(f.subject(), ("b" + i).getBytes());
        }
        PullConsumer c = js.consumer(f.stream(), "batch");
        List<ReceivedMessage> first = c.fetch(10, Duration.ofSeconds(1));
        assertEquals(3, first.size());
        first.forEach(m -> m.ackSync(Duration.ofSeconds(2)));
        assertTrue(c.fetch(10, Duration.ofSeconds(1)).isEmpty());
        assertTrue(c.next(Duration.ofSeconds(1)).isEmpty());
        assertThrows(IllegalArgumentException.class, () -> c.next(Duration.ofMillis(300)));
        assertThrows(IllegalArgumentException.class, () -> c.fetch(1, Duration.ofMillis(100)));
    }

    @Test
    void bindingToMissingConsumerOrStreamFailsFast() {
        Fixture f = fixture();
        MessagingException noConsumer = assertThrows(MessagingException.class, () -> js.consumer(f.stream(), "does-not-exist"));
        assertEquals(Kind.CONSUMER_NOT_FOUND, noConsumer.kind(), noConsumer.getMessage());
        assertTrue(noConsumer.getMessage().contains("does not create consumers"));
        MessagingException noStream = assertThrows(MessagingException.class, () -> js.consumer("NOPE" + RUN, "x"));
        assertTrue(noStream.kind() == Kind.STREAM_NOT_FOUND || noStream.kind() == Kind.CONSUMER_NOT_FOUND, noStream.kind() + "");
        // and the library did not create it behind our back
        assertTrue(admin.consumerInfo(f.stream(), "does-not-exist").isEmpty());
    }

    @Test
    void adminIsIdempotent() {
        Fixture f = fixture();
        assertEquals(f.stream(), admin.createStreamIfAbsent(StreamSpec.builder(f.stream(), f.subject()).build()).name());
        ConsumerSpec spec = ConsumerSpec.builder(f.stream(), "idem").filterSubject(f.subject()).build();
        admin.createOrUpdateConsumer(spec);
        admin.createOrUpdateConsumer(spec);
        assertTrue(admin.deleteConsumer(f.stream(), "idem"));
        assertFalse(admin.deleteConsumer(f.stream(), "idem"));
        assertTrue(admin.deleteStream(f.stream()));
        assertFalse(admin.deleteStream(f.stream()));
        assertTrue(admin.streamInfo(f.stream()).isEmpty());
    }

    @Test
    void coreRequestReplyTimeoutAndNoResponders() throws Exception {
        CoreClient core = client.core();
        String subject = "it.core." + RUN + SEQ.incrementAndGet();
        try (SubscriptionHandle sub = core.subscribe(subject, m -> core.publish(m.replyTo(), ("echo:" + m.text()).getBytes()))) {
            CoreMessage reply = core.request(subject, "ping".getBytes(), Duration.ofSeconds(2));
            assertEquals("echo:ping", reply.text());
        }
        MessagingException none = assertThrows(MessagingException.class,
                () -> core.request("it.nobody." + RUN, new byte[0], Duration.ofMillis(500)));
        assertEquals(Kind.UNAVAILABLE, none.kind(), none.getMessage());

        String silent = "it.silent." + RUN;
        try (SubscriptionHandle sub = core.subscribe(silent, m -> { })) {
            MessagingException timeout = assertThrows(MessagingException.class,
                    () -> core.request(silent, new byte[0], Duration.ofMillis(300)));
            assertEquals(Kind.TIMEOUT, timeout.kind(), timeout.getMessage());
        }
    }

    @Test
    void queueGroupSharesMessages() throws Exception {
        CoreClient core = client.core();
        String subject = "it.queue." + RUN + SEQ.incrementAndGet();
        AtomicInteger a = new AtomicInteger();
        AtomicInteger b = new AtomicInteger();
        try (SubscriptionHandle s1 = core.subscribe(subject, "workers", m -> a.incrementAndGet());
             SubscriptionHandle s2 = core.subscribe(subject, "workers", m -> b.incrementAndGet())) {
            for (int i = 0; i < 50; i++) {
                core.publish(subject, new byte[]{1});
            }
            awaitTrue(() -> a.get() + b.get() == 50, 5000);
        }
        assertEquals(50, a.get() + b.get()); // each message delivered once across the group
    }

    @Test
    void healthStatusAndGracefulClose() throws Exception {
        Fixture f = fixture();
        admin.createOrUpdateConsumer(ConsumerSpec.builder(f.stream(), "closing").build());
        MessagingClient c2 = MessagingClient.connect(MessagingConfig.builder().server(url).build());
        assertEquals(ConnectionStatus.CONNECTED, c2.status());
        assertTrue(c2.healthCheck(Duration.ofSeconds(2)));

        js.publisher().publish(f.subject(), "slow".getBytes());
        AtomicInteger finished = new AtomicInteger();
        java.util.concurrent.CountDownLatch started = new java.util.concurrent.CountDownLatch(1);
        ConsumerHandle h = c2.jetStream().consumer(f.stream(), "closing").consume(m -> {
            started.countDown();
            Thread.sleep(700);       // in-flight work when close() is called
            finished.incrementAndGet();
        });
        assertTrue(started.await(10, TimeUnit.SECONDS));
        long t0 = System.currentTimeMillis();
        c2.close();
        long took = System.currentTimeMillis() - t0;
        assertEquals(1, finished.get(), "close() must wait for the in-flight handler");
        assertTrue(took < 3000, "close() should return as soon as the handler is done, took " + took + " ms");
        assertTrue(h.isStopped());
        assertEquals(ConnectionStatus.CLOSED, c2.status());
        assertFalse(c2.healthCheck(Duration.ofSeconds(1)));
        c2.close(); // idempotent
        assertEquals(0L, admin.consumerInfo(f.stream(), "closing").orElseThrow().ackPending());
    }
}
