package com.company.messaging;

import com.company.messaging.admin.ConsumerSpec;
import com.company.messaging.admin.MessagingAdmin;
import com.company.messaging.admin.StreamSpec;
import java.time.Duration;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Runnable end-to-end example (also the source of the README snippets).
 * Start a server with {@code nats-server -js}, then run this class's main method.
 */
@SuppressWarnings("try")
public final class QuickStartExample {

    private QuickStartExample() {
    }

    public static void main(String[] args) throws Exception {
        MessagingConfig config = MessagingConfig.builder()
                .server(System.getenv().getOrDefault("NATS_URL", "nats://localhost:4222"))
                .connectionName("quickstart")
                .build();

        // 1. Platform / dev bootstrap only (separate nats-messaging-admin artifact). In production the platform team
        //    provisions streams and consumers; applications never include this dependency.
        try (MessagingAdmin admin = MessagingAdmin.connect(config)) {
            admin.createStreamIfAbsent(StreamSpec.builder("ORDERS", "orders.>").build());
            admin.createOrUpdateConsumer(ConsumerSpec.builder("ORDERS", "billing")
                    .filterSubject("orders.created").ackWait(Duration.ofSeconds(30)).build());
        }

        try (MessagingClient client = MessagingClient.connect(config)) {

            // 2. Consume. Returning normally acks; throwing naks with backoff; poison messages are terminated.
            CountDownLatch received = new CountDownLatch(1);
            ConsumeOptions options = ConsumeOptions.builder()
                    .terminateAfterDeliveries(5)
                    .onFailure((msg, error) -> System.err.println("failed " + msg.metadata().streamSequence() + ": " + error))
                    .build();
            try (ConsumerHandle consumer = client.jetStream().consumer("ORDERS", "billing").consume(options, msg -> {
                System.out.println("got " + msg.subject() + " seq=" + msg.metadata().streamSequence()
                        + " attempt=" + msg.metadata().deliveredCount() + " body=" + msg.text());
                received.countDown();
            })) {

                // 3. Publish with a message id so the call is idempotent and safely retried.
                PublishResult ack = client.jetStream().publisher().publish(
                        PublishRequest.builder("orders.created")
                                .payload("{\"orderId\":\"o-1001\"}")
                                .header("trace-id", "abc-123")
                                .messageId("order-o-1001-created")
                                .build());
                System.out.println("stored in " + ack.stream() + " at sequence " + ack.sequence()
                        + (ack.duplicate() ? " (duplicate ignored)" : ""));

                received.await(10, TimeUnit.SECONDS);
            } // closing the handle waits for the running handler

            // 4. Health probe for readiness endpoints.
            System.out.println("healthy=" + client.healthCheck(Duration.ofSeconds(1)) + " status=" + client.status());
        }
        try (MessagingAdmin admin = MessagingAdmin.connect(config)) {
            admin.deleteStream("ORDERS");
        }
    }
}
