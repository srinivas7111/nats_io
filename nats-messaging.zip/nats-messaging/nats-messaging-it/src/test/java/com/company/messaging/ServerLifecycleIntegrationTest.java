package com.company.messaging;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import com.company.messaging.MessagingException.Kind;
import com.company.messaging.admin.ConsumerSpec;
import com.company.messaging.admin.MessagingAdmin;
import com.company.messaging.admin.StreamSpec;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * Starts and stops its own nats-server processes, so it can test restarts and authentication.
 * Enabled only when {@code NATS_SERVER_BIN} points to a nats-server executable.
 */
@SuppressWarnings("try")
class ServerLifecycleIntegrationTest {

    private static String bin;

    @BeforeAll
    static void requireServerBinary() {
        bin = System.getenv("NATS_SERVER_BIN");
        assumeTrue(bin != null && new File(bin).canExecute(), "NATS_SERVER_BIN not set; skipping server lifecycle tests");
    }

    private static Process start(String... args) throws Exception {
        List<String> cmd = new ArrayList<>(List.of(bin));
        cmd.addAll(List.of(args));
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true)
                .redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
        Thread.sleep(1200);
        assertTrue(p.isAlive(), "nats-server failed to start: " + cmd);
        return p;
    }

    private static void stop(Process p) throws Exception {
        p.destroy();
        p.waitFor();
    }

    @Test
    void consumerAndPublisherSurviveServerRestart() throws Exception {
        Path dir = Files.createTempDirectory("nats-restart");
        Process server = start("-js", "-sd", dir.toString(), "-p", "4401");
        List<String> events = new CopyOnWriteArrayList<>();
        ConnectionEventListener listener = new ConnectionEventListener() {
            @Override public void onConnected() { events.add("connected"); }
            @Override public void onDisconnected() { events.add("disconnected"); }
            @Override public void onReconnected() { events.add("reconnected"); }
            @Override public void onClosed() { events.add("closed"); }
        };
        MessagingConfig cfg = MessagingConfig.builder().server("nats://127.0.0.1:4401")
                .reconnectWait(Duration.ofMillis(200)).jetStreamRequestTimeout(Duration.ofSeconds(2))
                .publishRetry(10, Duration.ofMillis(200), Duration.ofSeconds(1)).listener(listener).build();
        try (MessagingClient c = MessagingClient.connect(cfg)) {
            try (MessagingAdmin admin = MessagingAdmin.connect(MessagingConfig.builder().server("nats://127.0.0.1:4401").build())) {
                admin.createStreamIfAbsent(StreamSpec.builder("RC", "rc.>").build());
                admin.createOrUpdateConsumer(ConsumerSpec.builder("RC", "w").ackWait(Duration.ofSeconds(5)).build());
            }
            BlockingQueue<String> got = new LinkedBlockingQueue<>();
            // short pull expiry => the consumer notices a lost pull request sooner after the restart
            ConsumerHandle handle = c.jetStream().consumer("RC", "w")
                    .consume(ConsumeOptions.builder().pullExpiry(Duration.ofSeconds(4)).build(), m -> got.add(m.text()));

            c.jetStream().publisher().publish(PublishRequest.builder("rc.a").payload("m1").messageId("id1").build());
            assertEquals("m1", got.poll(5, TimeUnit.SECONDS));

            stop(server);
            long t0 = System.currentTimeMillis();
            while (c.status() == ConnectionStatus.CONNECTED && System.currentTimeMillis() - t0 < 5000) {
                Thread.sleep(50);
            }
            assertTrue(c.status() != ConnectionStatus.CONNECTED);
            assertFalse(c.healthCheck(Duration.ofMillis(500)));

            // a publish started during the outage must succeed once the server is back, and be stored once
            CompletableFuture<PublishResult> pending = CompletableFuture.supplyAsync(() -> c.jetStream().publisher()
                    .publish(PublishRequest.builder("rc.a").payload("m2").messageId("id2").build()));
            Thread.sleep(1500);
            server = start("-js", "-sd", dir.toString(), "-p", "4401");
            PublishResult r2 = pending.get(30, TimeUnit.SECONDS);
            assertFalse(r2.duplicate());

            assertEquals("m2", got.poll(40, TimeUnit.SECONDS), "consumer should resume by itself after the restart");
            c.jetStream().publisher().publish(PublishRequest.builder("rc.a").payload("m3").messageId("id3").build());
            assertEquals("m3", got.poll(10, TimeUnit.SECONDS));
            assertEquals(null, got.poll(1, TimeUnit.SECONDS), "no duplicates");
            assertEquals(ConnectionStatus.CONNECTED, c.status());
            handle.close();
        } finally {
            stop(server);
        }
        // one event per transition, not one per failed reconnect attempt
        assertEquals(List.of("connected", "disconnected", "reconnected", "closed"), events);
    }

    @Test
    void authenticationFailuresAreClassifiedAndPermissionsAreReported() throws Exception {
        Path dir = Files.createTempDirectory("nats-auth");
        Path conf = dir.resolve("server.conf");
        Files.writeString(conf, "port: 4402\njetstream { store_dir: \"" + dir + "/js\" }\n"
                + "authorization { users = [\n"
                + " {user: alice, password: secret, permissions: {publish: \">\", subscribe: \">\"}},\n"
                + " {user: bob, password: bobpw, permissions: {publish: {allow: [\"x.>\", \"$JS.API.>\"]}, subscribe: \">\"}}\n"
                + "] }\n");
        Process server = start("-c", conf.toString());
        try {
            MessagingException wrong = null;
            try {
                MessagingClient.connect(MessagingConfig.builder().server("nats://127.0.0.1:4402").userPassword("alice", "WRONG").build());
            } catch (MessagingException e) {
                wrong = e;
            }
            assertNotNull(wrong);
            assertEquals(Kind.AUTHORIZATION, wrong.kind());
            assertFalse(wrong.isRetryable());
            assertFalse(wrong.getMessage().contains("WRONG"), "secrets must not leak into messages");

            try (MessagingAdmin alice = MessagingAdmin.connect(
                    MessagingConfig.builder().server("nats://127.0.0.1:4402").userPassword("alice", "secret").build())) {
                alice.createStreamIfAbsent(StreamSpec.builder("AUTHS", "y.>", "x.>").build());
                alice.createOrUpdateConsumer(ConsumerSpec.builder("AUTHS", "app").filterSubject("x.>").build());
            }
            List<String> asyncErrors = new CopyOnWriteArrayList<>();
            ConnectionEventListener listener = new ConnectionEventListener() {
                @Override public void onError(String description, Throwable cause) { asyncErrors.add(description); }
            };
            try (MessagingClient bob = MessagingClient.connect(MessagingConfig.builder().server("nats://127.0.0.1:4402")
                    .userPassword("bob", "bobpw").jetStreamRequestTimeout(Duration.ofSeconds(1)).listener(listener).build())) {
                assertTrue(bob.jetStream().publisher().publish("x.fine", new byte[]{1}).sequence() >= 1);
                MessagingException denied = null;
                try {
                    bob.jetStream().publisher().publish("y.forbidden", new byte[]{1});
                } catch (MessagingException e) {
                    denied = e;
                }
                assertNotNull(denied, "publish without permission must fail");
                Thread.sleep(300);
                assertTrue(asyncErrors.stream().anyMatch(e -> e.toLowerCase().contains("permission")), asyncErrors.toString());
            }
        } finally {
            stop(server);
        }
    }

    @Test
    void anApplicationUserCanPublishAndConsumeButCannotProvision() throws Exception {
        Path dir = Files.createTempDirectory("nats-gov");
        Path conf = dir.resolve("server.conf");
        Files.writeString(conf, "port: 4403\njetstream { store_dir: \"" + dir + "/js\" }\n"
                + "authorization { users = [\n"
                + " {user: platform, password: adminpw, permissions: {publish: \">\", subscribe: \">\"}},\n"
                + " {user: app, password: apppw, permissions: {publish: {allow: [\"x.>\", \"$JS.API.STREAM.INFO.>\", \"$JS.API.CONSUMER.INFO.>\","
                + " \"$JS.API.CONSUMER.MSG.NEXT.>\", \"$JS.ACK.>\"]}, subscribe: \">\"}}\n"
                + "] }\n");
        Process server = start("-c", conf.toString());
        try {
            try (MessagingAdmin platform = MessagingAdmin.connect(
                    MessagingConfig.builder().server("nats://127.0.0.1:4403").userPassword("platform", "adminpw").build())) {
                platform.createStreamIfAbsent(StreamSpec.builder("GOV", "x.>").build());
                platform.createOrUpdateConsumer(ConsumerSpec.builder("GOV", "app-worker").build());
            }
            MessagingConfig appConfig = MessagingConfig.builder().server("nats://127.0.0.1:4403")
                    .userPassword("app", "apppw").jetStreamRequestTimeout(Duration.ofSeconds(1)).build();
            // the application can do its job ...
            try (MessagingClient app = MessagingClient.connect(appConfig)) {
                app.jetStream().publisher().publish(PublishRequest.builder("x.event").payload("hello").messageId("g1").build());
                BlockingQueue<String> got = new LinkedBlockingQueue<>();
                try (ConsumerHandle h = app.jetStream().consumer("GOV", "app-worker").consume(m -> got.add(m.text()))) {
                    assertEquals("hello", got.poll(10, TimeUnit.SECONDS));
                }
            }
            // ... but the server refuses it every provisioning operation, even if it used the admin artifact
            try (MessagingAdmin asApp = MessagingAdmin.connect(appConfig)) {
                MessagingException create = null;
                try {
                    asApp.createStreamIfAbsent(StreamSpec.builder("ROGUE", "rogue.>").build());
                } catch (MessagingException e) {
                    create = e;
                }
                assertNotNull(create, "the server must refuse stream creation for an application user");
                MessagingException delete = null;
                try {
                    asApp.deleteStream("GOV");
                } catch (MessagingException e) {
                    delete = e;
                }
                assertNotNull(delete, "the server must refuse stream deletion for an application user");
            }
            try (MessagingAdmin platform = MessagingAdmin.connect(
                    MessagingConfig.builder().server("nats://127.0.0.1:4403").userPassword("platform", "adminpw").build())) {
                assertTrue(platform.streamInfo("GOV").isPresent(), "GOV must have survived the rogue delete");
                assertTrue(platform.streamInfo("ROGUE").isEmpty(), "ROGUE must not exist");
            }
        } finally {
            stop(server);
        }
    }
}
