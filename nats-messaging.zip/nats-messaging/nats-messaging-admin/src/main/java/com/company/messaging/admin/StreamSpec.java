package com.company.messaging.admin;

import java.time.Duration;
import java.util.List;
import java.util.Objects;

/** Desired stream configuration for {@link MessagingAdmin#createStreamIfAbsent(StreamSpec)}. */
public final class StreamSpec {

    public enum Retention { LIMITS, INTEREST, WORK_QUEUE }

    public enum Storage { FILE, MEMORY }

    private final String name;
    private final List<String> subjects;
    private final Retention retention;
    private final Storage storage;
    private final int replicas;
    private final Duration maxAge;
    private final long maxMessages;
    private final long maxBytes;
    private final Duration duplicateWindow;

    private StreamSpec(Builder b) {
        this.name = b.name;
        this.subjects = List.copyOf(b.subjects);
        this.retention = b.retention;
        this.storage = b.storage;
        this.replicas = b.replicas;
        this.maxAge = b.maxAge;
        this.maxMessages = b.maxMessages;
        this.maxBytes = b.maxBytes;
        this.duplicateWindow = b.duplicateWindow;
    }

    public static Builder builder(String name, String... subjects) {
        return new Builder(name, subjects);
    }

    String name() { return name; }
    List<String> subjects() { return subjects; }
    Retention retention() { return retention; }
    Storage storage() { return storage; }
    int replicas() { return replicas; }
    Duration maxAge() { return maxAge; }
    long maxMessages() { return maxMessages; }
    long maxBytes() { return maxBytes; }
    Duration duplicateWindow() { return duplicateWindow; }

    public static final class Builder {
        private final String name;
        private final List<String> subjects;
        private Retention retention = Retention.LIMITS;
        private Storage storage = Storage.FILE;
        private int replicas = 1;
        private Duration maxAge = Duration.ZERO; // unlimited
        private long maxMessages = -1;
        private long maxBytes = -1;
        private Duration duplicateWindow = Duration.ofMinutes(2);

        private Builder(String name, String... subjects) {
            Objects.requireNonNull(name, "name");
            if (name.isBlank()) throw new IllegalArgumentException("stream name must not be blank");
            if (subjects == null || subjects.length == 0) throw new IllegalArgumentException("at least one subject is required");
            this.name = name;
            this.subjects = List.of(subjects);
        }

        public Builder retention(Retention retention) { this.retention = Objects.requireNonNull(retention); return this; }
        public Builder storage(Storage storage) { this.storage = Objects.requireNonNull(storage); return this; }
        public Builder replicas(int replicas) {
            if (replicas < 1 || replicas > 5) throw new IllegalArgumentException("replicas must be 1..5");
            this.replicas = replicas;
            return this;
        }
        /** Messages older than this are removed. Default: keep forever. */
        public Builder maxAge(Duration maxAge) { this.maxAge = Objects.requireNonNull(maxAge); return this; }
        public Builder maxMessages(long maxMessages) { this.maxMessages = maxMessages; return this; }
        public Builder maxBytes(long maxBytes) { this.maxBytes = maxBytes; return this; }
        /** Window in which duplicate message ids are detected. Default 2 minutes. */
        public Builder duplicateWindow(Duration window) { this.duplicateWindow = Objects.requireNonNull(window); return this; }
        public StreamSpec build() { return new StreamSpec(this); }
    }
}
