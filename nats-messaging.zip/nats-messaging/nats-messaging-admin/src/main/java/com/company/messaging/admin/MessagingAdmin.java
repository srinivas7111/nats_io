package com.company.messaging.admin;

import com.company.messaging.ConsumerSummary;
import com.company.messaging.MessagingConfig;
import com.company.messaging.MessagingException;
import com.company.messaging.spi.ErrorMapper;
import com.company.messaging.spi.NatsConnections;
import io.nats.client.Connection;
import io.nats.client.JetStreamApiException;
import io.nats.client.JetStreamManagement;
import io.nats.client.api.AckPolicy;
import io.nats.client.api.ConsumerConfiguration;
import io.nats.client.api.ConsumerInfo;
import io.nats.client.api.DeliverPolicy;
import io.nats.client.api.RetentionPolicy;
import io.nats.client.api.StorageType;
import io.nats.client.api.StreamConfiguration;
import io.nats.client.api.StreamInfo;
import java.util.Optional;

/**
 * Platform-side provisioning of streams and durable consumers.
 * <p>
 * <b>This artifact is for the platform / SRE team, for CI bootstrap and for tests. It is deliberately not part of
 * {@code nats-messaging-client}</b>, so application services do not ship with the ability to create or delete
 * streams. The real enforcement belongs on the NATS server: application users should not be granted the
 * {@code $JS.API.STREAM.CREATE/UPDATE/DELETE.>} and {@code $JS.API.CONSUMER.CREATE/DELETE.>} permissions.
 * <p>
 * Methods are idempotent where noted. Thread-safe. Close it when done.
 */
public final class MessagingAdmin implements AutoCloseable {

    private static final int STREAM_NOT_FOUND = 10059;
    private static final int CONSUMER_NOT_FOUND = 10014;

    private final Connection connection;
    private final JetStreamManagement jsm;

    private MessagingAdmin(Connection connection, JetStreamManagement jsm) {
        this.connection = connection;
        this.jsm = jsm;
    }

    /**
     * Connects with the same {@link MessagingConfig} (servers, auth, TLS, domain) the client uses, typically with
     * administrator credentials.
     *
     * @throws MessagingException {@code CONNECTION}, {@code AUTHORIZATION} or {@code CONFIGURATION}
     */
    public static MessagingAdmin connect(MessagingConfig config) {
        Connection connection = NatsConnections.connect(config);
        try {
            return new MessagingAdmin(connection, connection.jetStreamManagement(NatsConnections.jetStreamOptions(config)));
        } catch (Exception e) {
            try {
                connection.close();
            } catch (Exception ignored) {
                // best effort
            }
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            throw ErrorMapper.map("open JetStream management", e);
        }
    }

    @Override
    public void close() {
        try {
            connection.close();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception ignored) {
            // nothing more to do
        }
    }

    /** Creates the stream if it does not exist; returns the existing stream untouched otherwise. Idempotent. */
    public StreamSummary createStreamIfAbsent(StreamSpec spec) {
        try {
            return summarize(jsm.getStreamInfo(spec.name()));
        } catch (JetStreamApiException e) {
            if (e.getApiErrorCode() != STREAM_NOT_FOUND) {
                throw ErrorMapper.map("look up stream '" + spec.name() + "'", e);
            }
        } catch (Exception e) {
            throw ErrorMapper.map("look up stream '" + spec.name() + "'", e);
        }
        try {
            StreamConfiguration.Builder b = StreamConfiguration.builder()
                    .name(spec.name())
                    .subjects(spec.subjects())
                    .retentionPolicy(switch (spec.retention()) {
                        case LIMITS -> RetentionPolicy.Limits;
                        case INTEREST -> RetentionPolicy.Interest;
                        case WORK_QUEUE -> RetentionPolicy.WorkQueue;
                    })
                    .storageType(spec.storage() == StreamSpec.Storage.FILE ? StorageType.File : StorageType.Memory)
                    .replicas(spec.replicas())
                    .maxMessages(spec.maxMessages())
                    .maxBytes(spec.maxBytes())
                    .duplicateWindow(spec.duplicateWindow());
            if (!spec.maxAge().isZero()) {
                b.maxAge(spec.maxAge());
            }
            return summarize(jsm.addStream(b.build()));
        } catch (Exception e) {
            throw ErrorMapper.map("create stream '" + spec.name() + "'", e);
        }
    }

    public Optional<StreamSummary> streamInfo(String name) {
        try {
            return Optional.of(summarize(jsm.getStreamInfo(name)));
        } catch (JetStreamApiException e) {
            if (e.getApiErrorCode() == STREAM_NOT_FOUND) {
                return Optional.empty();
            }
            throw ErrorMapper.map("stream info '" + name + "'", e);
        } catch (Exception e) {
            throw ErrorMapper.map("stream info '" + name + "'", e);
        }
    }

    /** @return true if the stream existed and was deleted. */
    public boolean deleteStream(String name) {
        try {
            return jsm.deleteStream(name);
        } catch (JetStreamApiException e) {
            if (e.getApiErrorCode() == STREAM_NOT_FOUND) {
                return false;
            }
            throw ErrorMapper.map("delete stream '" + name + "'", e);
        } catch (Exception e) {
            throw ErrorMapper.map("delete stream '" + name + "'", e);
        }
    }

    /** Creates or updates a durable pull consumer with explicit acks. Idempotent. */
    public ConsumerSummary createOrUpdateConsumer(ConsumerSpec spec) {
        try {
            ConsumerConfiguration.Builder b = ConsumerConfiguration.builder()
                    .durable(spec.durable())
                    .ackPolicy(AckPolicy.Explicit)
                    .ackWait(spec.ackWait())
                    .maxDeliver(spec.maxDeliver())
                    .maxAckPending(spec.maxAckPending())
                    .deliverPolicy(switch (spec.startPosition()) {
                        case ALL -> DeliverPolicy.All;
                        case NEW -> DeliverPolicy.New;
                        case LAST -> DeliverPolicy.Last;
                    });
            if (spec.filterSubject() != null) {
                b.filterSubject(spec.filterSubject());
            }
            ConsumerInfo ci = jsm.addOrUpdateConsumer(spec.stream(), b.build());
            return new ConsumerSummary(ci.getStreamName(), ci.getName(), ci.getNumPending(),
                    ci.getNumAckPending(), ci.getRedelivered());
        } catch (Exception e) {
            throw ErrorMapper.map("create consumer '" + spec.durable() + "'", e);
        }
    }

    public Optional<ConsumerSummary> consumerInfo(String stream, String durable) {
        try {
            ConsumerInfo ci = jsm.getConsumerInfo(stream, durable);
            return Optional.of(new ConsumerSummary(ci.getStreamName(), ci.getName(), ci.getNumPending(),
                    ci.getNumAckPending(), ci.getRedelivered()));
        } catch (JetStreamApiException e) {
            if (e.getApiErrorCode() == CONSUMER_NOT_FOUND || e.getApiErrorCode() == STREAM_NOT_FOUND) {
                return Optional.empty();
            }
            throw ErrorMapper.map("consumer info '" + durable + "'", e);
        } catch (Exception e) {
            throw ErrorMapper.map("consumer info '" + durable + "'", e);
        }
    }

    /** @return true if the consumer existed and was deleted. */
    public boolean deleteConsumer(String stream, String durable) {
        try {
            return jsm.deleteConsumer(stream, durable);
        } catch (JetStreamApiException e) {
            if (e.getApiErrorCode() == CONSUMER_NOT_FOUND || e.getApiErrorCode() == STREAM_NOT_FOUND) {
                return false;
            }
            throw ErrorMapper.map("delete consumer '" + durable + "'", e);
        } catch (Exception e) {
            throw ErrorMapper.map("delete consumer '" + durable + "'", e);
        }
    }

    private static StreamSummary summarize(StreamInfo info) {
        var state = info.getStreamState();
        return new StreamSummary(info.getConfiguration().getName(), info.getConfiguration().getSubjects(),
                state.getMsgCount(), state.getByteCount(), state.getFirstSequence(), state.getLastSequence(),
                state.getConsumerCount());
    }
}
