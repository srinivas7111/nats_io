package com.company.messaging.admin;

import java.time.Duration;
import java.util.Objects;

/** Desired durable pull-consumer configuration for {@link MessagingAdmin#createOrUpdateConsumer(ConsumerSpec)}. */
public final class ConsumerSpec {

    public enum StartPosition { ALL, NEW, LAST }

    private final String stream;
    private final String durable;
    private final String filterSubject;
    private final Duration ackWait;
    private final long maxDeliver;
    private final long maxAckPending;
    private final StartPosition startPosition;

    private ConsumerSpec(Builder b) {
        this.stream = b.stream;
        this.durable = b.durable;
        this.filterSubject = b.filterSubject;
        this.ackWait = b.ackWait;
        this.maxDeliver = b.maxDeliver;
        this.maxAckPending = b.maxAckPending;
        this.startPosition = b.startPosition;
    }

    public static Builder builder(String stream, String durable) {
        return new Builder(stream, durable);
    }

    String stream() { return stream; }
    String durable() { return durable; }
    String filterSubject() { return filterSubject; }
    Duration ackWait() { return ackWait; }
    long maxDeliver() { return maxDeliver; }
    long maxAckPending() { return maxAckPending; }
    StartPosition startPosition() { return startPosition; }

    public static final class Builder {
        private final String stream;
        private final String durable;
        private String filterSubject;
        private Duration ackWait = Duration.ofSeconds(30);
        private long maxDeliver = -1;
        private long maxAckPending = 1000;
        private StartPosition startPosition = StartPosition.ALL;

        private Builder(String stream, String durable) {
            Objects.requireNonNull(stream, "stream");
            Objects.requireNonNull(durable, "durable");
            if (stream.isBlank() || durable.isBlank()) throw new IllegalArgumentException("stream and durable must not be blank");
            this.stream = stream;
            this.durable = durable;
        }

        /** Only deliver messages on this subject (may include wildcards). */
        public Builder filterSubject(String subject) { this.filterSubject = subject; return this; }
        /** How long the server waits for an ack before redelivering. Default 30s. */
        public Builder ackWait(Duration ackWait) { this.ackWait = Objects.requireNonNull(ackWait); return this; }
        /** Server-side delivery limit per message; -1 (default) = unlimited. */
        public Builder maxDeliver(long maxDeliver) { this.maxDeliver = maxDeliver; return this; }
        public Builder maxAckPending(long maxAckPending) { this.maxAckPending = maxAckPending; return this; }
        public Builder startPosition(StartPosition p) { this.startPosition = Objects.requireNonNull(p); return this; }
        public ConsumerSpec build() { return new ConsumerSpec(this); }
    }
}
