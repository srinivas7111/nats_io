package com.company.messaging.admin;

import java.util.List;

/** Read-only view of a stream's configuration and state. */
public record StreamSummary(String name, List<String> subjects, long messages, long bytes,
                            long firstSequence, long lastSequence, long consumerCount) {
}
