# nats-messaging

Platform-owned Java messaging library over [JNATS](https://github.com/nats-io/nats.java) (NATS core + JetStream).
Application teams depend on **one artifact** and write business logic; SRE owns the NATS infrastructure; the Platform
team owns this library.

| Module | Audience | Contents |
|---|---|---|
| `nats-messaging-client` | **Application services** | Connection, JetStream publish/consume, core NATS. **No admin API of any kind.** |
| `nats-messaging-admin` | Platform / SRE / CI bootstrap / tests | `MessagingAdmin`: create/inspect/delete streams and consumers. Not a dependency of services. |
| `nats-messaging-it` | Platform team (not published) | Integration tests against a real server; runnable examples. |

Java 17+. JNATS **2.26.4** is pinned once in the parent `pom.xml` (`jnats.version`) and arrives transitively; it is a
**platform decision** that needs formal approval and a full test run before it changes.
The code is compiled and tested against 2.26.4 only; older JNATS versions are not supported.

No `io.nats.*` type appears in any public or protected signature of `com.company.messaging` (enforced by
`ApiBoundaryTest`). Package `com.company.messaging` is a placeholder; rename it before publishing.

## What it covers

| Area | Provided |
|---|---|
| Connection | Multi-server URLs, user/password, token, `.creds` file, TLS and mutual TLS (key/trust stores or `SSLContext`), unlimited auto-reconnect, lifecycle events (one per real transition), health check, graceful shutdown |
| JetStream publish | Sync and async publish returning the server ack (stream, sequence, duplicate flag), idempotent publish via message id, headers, optimistic-concurrency preconditions, automatic retry for idempotent publishes |
| JetStream consume | Bind to an **existing** durable pull consumer; `consume(handler)` with auto-ack / backoff-nak / poison-message termination; `fetch` and `next`; delivery metadata; explicit `ack/ackSync/nak/nakWithDelay/term/inProgress` |
| Core NATS | `publish`, `request` (timeout vs. no-responders distinguished), `subscribe` with optional queue group |
| Errors | One runtime exception, `MessagingException`, with a `Kind` and `isRetryable()` |
| Admin (separate artifact) | `createStreamIfAbsent`, `createOrUpdateConsumer`, info, delete |

**Not covered (yet):** Key-Value, Object Store, push consumers, ordered consumers, service framework.
Core NATS is included in `CoreClient`; if the first release should be JetStream-only, delete `CoreClient`,
`CoreMessage`, `CoreMessageHandler`, `SubscriptionHandle` and the `core()` accessor.

## Quick start (application service)

```java
MessagingConfig config = MessagingConfig.builder()
        .server("tls://nats.internal:4222")
        .connectionName("billing-service")
        .userPassword(user, password)            // or .token(..) / .credentialsFile(..)
        .tlsTrustStore("/etc/ssl/nats-ca.p12", trustPass)
        .build();                                // or MessagingConfig.fromEnvironment().build()

try (MessagingClient client = MessagingClient.connect(config)) {

    // consume: return normally = ack, throw = nak with exponential backoff
    ConsumeOptions options = ConsumeOptions.builder().terminateAfterDeliveries(5).build();
    ConsumerHandle consumer = client.jetStream().consumer("PAYMENT_NOTIFICATIONS", "payment-worker")
            .consume(options, msg -> process(msg.text(), msg.metadata().deliveredCount()));

    // publish: the message id makes it idempotent and safe to retry
    client.jetStream().publisher().publish(PublishRequest.builder("payments.settled")
            .payload("{\"paymentId\":\"p-1\"}").messageId("payment-p-1-settled").build());
}   // close(): stops consumers, waits for the running handler, flushes, disconnects
```

Runnable end-to-end version (including provisioning via the admin artifact):
`nats-messaging-it/src/test/java/com/company/messaging/QuickStartExample.java`.

Environment variables for `MessagingConfig.fromEnvironment()`: `NATS_URL` (comma-separated), `NATS_USERNAME`,
`NATS_PASSWORD`, `NATS_TOKEN`, `NATS_CREDS_FILE`, `NATS_TLS_TRUSTSTORE[_PASSWORD]`, `NATS_TLS_KEYSTORE[_PASSWORD]`
(PKCS12), `NATS_CONNECTION_NAME`, `NATS_JS_DOMAIN` / `NATS_JS_PREFIX` (mutually exclusive). Use `tls://` URLs when the
server requires TLS. Only one auth method may be configured.

## Platform ownership and governance

* Applications get `MessagingClient`, which can **only publish and consume**. `jetStream().consumer(stream, durable)`
  fails fast with `CONSUMER_NOT_FOUND` / `STREAM_NOT_FOUND`; nothing is created implicitly.
* Provisioning lives in `nats-messaging-admin` (`MessagingAdmin.connect(config)`), used by the platform team and CI.
* **Code separation is hygiene; the server is the enforcement.** Anyone can add the JNATS or admin jar to a classpath.
  Give application users only the permissions they need and withhold `$JS.API.STREAM.CREATE/UPDATE/DELETE.>` and
  `$JS.API.CONSUMER.CREATE/DELETE.>`. `ServerLifecycleIntegrationTest.anApplicationUserCanPublishAndConsumeButCannotProvision`
  proves the server refuses an application user's create/delete even through the admin artifact. A consuming application
  user needs publish permission on its subjects plus `$JS.API.STREAM.INFO.>`, `$JS.API.CONSUMER.INFO.>`,
  `$JS.API.CONSUMER.MSG.NEXT.>` and `$JS.ACK.>`.
* `com.company.messaging.spi` (connection building, error mapping) is shared by the client and admin artifacts and is
  **not for application use**; it is the only package that exposes JNATS types.

## Behaviour you should know about

**Delivery is at-least-once.** Handlers must be idempotent; `deliveredCount() > 1` marks a redelivery.

**Settlement is truthful.** A message counts as settled only after `ack/nak/term` actually succeeded. A failed settling
call throws and leaves the message unsettled so you can retry or choose another outcome. If a handler succeeded but the
ack then failed, the library only logs a warning (the server redelivers after `ackWait`); it never naks a message whose
ack may have reached the server.

**Handler failures.** Throwing naks with delay `retryBase * 2^(attempt-1)` (default 1s .. 30s).
`terminateAfterDeliveries(n)` terminates a message that failed `n` times; the consumer's server-side `maxDeliver` still
applies. `onFailure(..)` is the hook for metrics and dead-letter publishing. JVM-fatal errors (`OutOfMemoryError`,
`StackOverflowError`, `LinkageError`) are **not** swallowed: they propagate and the message is left unacknowledged.

**Unreadable deliveries.** A delivery whose JetStream metadata cannot be parsed can never be processed, so the policy is:
**terminate it, log ERROR, and call `onUnreadable(subject, cause)`** so the platform can alert. (A payload your handler
cannot parse is different: that is a handler failure and follows the normal retry/terminate path.)

**Idempotent publishing and retries.** Give every logical event a stable `messageId`. The server drops duplicates within
the stream's duplicate window (default 2 min). Only publishes with a message id are retried (default 3 attempts, 100 ms .. 2 s);
without one a lost ack plus a retry would store the event twice. `publish(..)` **blocks the calling thread**, retries
included: worst case `attempts x jetStreamRequestTimeout + back-offs` (defaults: about 15 s). Use `publishAsync(..)` on
latency-sensitive threads. Keep total retry time below the stream's duplicate window; a retry after the window is stored
again (`sameMessageIdOutsideTheDuplicateWindowIsStoredAgain` demonstrates it, and the config logs a warning when the
worst case exceeds 2 minutes).

**One handler at a time.** A continuous consumer runs its handler on a single thread, one message at a time (verified
by a test); first deliveries arrive in stream order, redeliveries can interleave. Scale by running more instances or
more consumers.

**Shutdown.** `MessagingClient.close()` stops consumers/subscriptions, waits (default up to 10 s, `shutdownTimeout`) for
handlers that are running, drains and closes. `ConsumerHandle.close()` waits up to 5 s. A consumer is **always released**,
even if its handler is stuck (a warning is logged; the in-flight message is redelivered). `stop()` alone only stops pulling.

**Recovery after a server restart** is automatic. A consumer notices a lost pull request after about 1 to 2 times
`pullExpiry` (default 10 s; measured about 12 s). Lower it (min 1 s) for faster recovery at slightly more idle traffic.

**Credential rotation.** `.creds` files are re-read by JNATS on every authentication, so a rotated file is picked up on
the next (re)connect (source-verified, not exercised against a real account). Passwords/tokens are immutable in a config:
rotate by creating a new `MessagingClient` and closing the old one.

**Permission errors** are reported by the server asynchronously: the synchronous call fails with `TIMEOUT` after the
JetStream request timeout and the reason arrives in `ConnectionEventListener.onError` ("Permissions Violation ..."). Wire
the listener to your logs.

**Logging** goes through `System.Logger`; add `slf4j-jdk-platform-logging` (or the Log4j/Logback equivalent) to route it.
Secrets are never logged or included in `toString()`.

## Error handling

```java
try {
    client.jetStream().publisher().publish(request);
} catch (MessagingException e) {
    if (e.isRetryable()) { /* CONNECTION, TIMEOUT, UNAVAILABLE: back off and try again */ }
    switch (e.kind()) {
        case STREAM_NOT_FOUND, CONSUMER_NOT_FOUND -> { /* provisioning problem */ }
        case PUBLISH_REJECTED -> { /* expected-sequence / expected-stream precondition failed */ }
        case AUTHORIZATION -> { /* bad credentials or missing permission */ }
        default -> { }
    }
}
```
Programming errors (blank subject, wildcard in a publish subject, `fetch`/`next` wait under 1 s, bad builder values)
throw `IllegalArgumentException` immediately.

## Build and test

```bash
mvn verify                                   # unit tests (client) ; integration tests skip themselves

nats-server -js &                            # JetStream-enabled server
NATS_URL=nats://localhost:4222 mvn verify    # + JetStream, core and concurrency integration tests

NATS_URL=nats://localhost:4222 NATS_SERVER_BIN=$(which nats-server) mvn verify
                                             # + server restart, authentication and governance tests
                                             #   (these spawn their own nats-server processes on ports 4401-4403)
```

Test inventory: client module (`UnitTest`, `SettlementTest`, `DispatchTest`, `ConsumerHandleTest`, `ApiBoundaryTest`;
no server needed) and integration module (`JetStreamIntegrationTest`, `ServerLifecycleIntegrationTest`).

## Design decisions

* **Flat package `com.company.messaging`.** Public classes construct each other through package-private constructors that
  take JNATS objects. Splitting into `jetstream/`, `model/`, `connection/` sub-packages would force those constructors to
  be public and put JNATS types in the public API. The way to have sub-packages without that is public interfaces plus
  hidden implementations; do that refactor deliberately if the API grows, not for appearance.
* **JNATS is a compile dependency** owned by the wrapper, so services do not manage or conflict on its version.
* **Upgrading JNATS:** change `jnats.version` in the parent pom, run all three test modes above, release a new version.
