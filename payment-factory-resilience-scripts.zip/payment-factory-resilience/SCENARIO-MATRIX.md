# Payment Factory resilience matrix

| ID | Scenario | Script | Automation style | Required evidence |
|---|---|---|---|---|
| JR-01 | Stream replication baseline | 01 | Automated inspection + publish | Stream info, replicas, sequence |
| JR-02 | Stream leader failure | 02 | Disruptive automated + inspect | Before/after leader, publish result |
| JR-03 | Follower failure | 03 | Disruptive automated + inspect | Node health, stream replica state |
| JR-04 | Node rejoin/catch-up | 04 | Disruptive automated + inspect | Replica state and sequence after recovery |
| JR-05 | Pull cursor persistence | 05 | Operator-assisted | Consumer delivered/ACK floor before and after Java restart |
| JR-06 | Pull unacked redelivery | 06 | Operator-assisted | Event ID, redelivery, ACK pending |
| JR-07 | Pull consumer leader failure | 07 | Disruptive; leader must be identified first | Consumer leader/replicas and cursor |
| JR-08 | Push cursor while subscriber offline | 08 | Operator-assisted | Pending events, ACK floor and event IDs |
| JR-09 | Push subscriber reconnect | 09 | Operator-assisted | Notification event IDs and cursor |
| JR-10 | Push consumer leader failure | 10 | Disruptive; leader must be identified first | Consumer leader/replicas and cursor |
| JR-11 | Two-node quorum loss | 11 | Highly disruptive | Publish failure/acceptance, health and quorum state |
| JR-12 | Quorum restoration | 12 | Operator-assisted recovery | Healthy nodes, successful publish, replicas |
| JR-13 | HAProxy backend failure | 13 | Disruptive automated + inspect | HAProxy backend state and publish path |
| JR-14 | HAProxy process failure | 14 | Disruptive automated + inspect | Endpoint failure then recovery |
| JR-15 | Duplicate delivery/idempotency | 15 | Operator-assisted | Same event redelivered; one business effect |
| JR-16 | End-to-end one-node failure | 16 | Disruptive + Java workload validation | Reconcile published IDs against processing and notification results |

## Reporting rules

- Every run writes `run.log`, per-node `/varz` and `/jsz` snapshots where available, stream/consumer JSON, and `summary.txt`.
- `SUCCESS` on an operator-assisted script means evidence capture completed; it does not replace manual validation of the scenario's acceptance criteria.
- Do not treat missing stream/consumer information as success. Check WARN lines and the raw `.err`/`.json` evidence files.
