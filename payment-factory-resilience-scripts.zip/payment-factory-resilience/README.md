# Payment Factory — NATS/JetStream resilience test scripts

## Environment assumptions

Defaults match the current local Podman setup:
- NATS containers: `nats-1`, `nats-2`, `nats-3`
- HAProxy container: `nats-lb`
- Podman network: `nats-net`
- HAProxy client endpoint inside the Podman network: `nats://nats-lb:4222`
- Host client endpoint: `nats://nats.local.test:4222`
- HAProxy stats URL: `http://localhost:8404/stats`
- Stream: `PAYMENT_EVENTS`
- Pull durable: `PAYMENT_PROCESSORS`
- Push durable: `PAYMENT_NOTIFICATIONS`

Override settings through environment variables, for example:
```bash
export STREAM=PAYMENT_EVENTS
export PROCESSOR_CONSUMER=PAYMENT_PROCESSORS
export NOTIFICATION_CONSUMER=PAYMENT_NOTIFICATIONS
export NODES_CSV="nats-1 nats-2 nats-3"
export REPORT_DIR="./evidence-run-001"
```

## Before running

1. Run from a machine with Podman and permission to inspect/stop/start these containers.
2. Confirm all three NATS servers are configured for JetStream and use persistent storage.
3. Confirm `PAYMENT_EVENTS` exists and has `num_replicas=3`.
4. Confirm the two durable consumers exist and their configuration matches the design.
5. Ensure the NATS CLI command options supported by the installed `nats-box` image match the scripts. If your CLI version differs, adjust `nats stream info ... --json` and `nats consumer info ... --json` invocations.
6. Run a safe scenario first:
   ```bash
   chmod +x scripts/*.sh
   ./scripts/01-baseline-stream-replication.sh
   ```
7. Run each disruptive test only in a disposable/demo environment. Type `YES` at prompts to proceed.

## Run scenarios

```bash
./scripts/01-baseline-stream-replication.sh
./scripts/02-stream-leader-failover.sh
./scripts/03-follower-failure-recovery.sh
./scripts/04-stream-rejoin-catchup.sh
./scripts/05-pull-cursor-resume.sh
./scripts/06-pull-unacked-redelivery.sh
./scripts/07-pull-consumer-leader-failover.sh
./scripts/08-push-cursor-offline-catchup.sh
./scripts/09-push-subscriber-reconnect.sh
./scripts/10-push-consumer-leader-failover.sh
./scripts/11-two-node-quorum-loss.sh
./scripts/12-quorum-restoration.sh
./scripts/13-haproxy-backend-failure.sh
./scripts/14-haproxy-process-failure.sh
./scripts/15-idempotency-duplicate-delivery.sh
./scripts/16-end-to-end-one-node-failure.sh
```

Each script prints:
- Step headings and commands for its own actions
- Per-node container state and monitoring endpoint data (`/varz`, `/jsz`)
- HAProxy stats endpoint status and a NATS client-path probe
- Stream count (approximate), stream messages/sequences, configured replicas, leader and replica details where exposed
- Consumer delivered sequence, ACK floor, pending/ACK-pending/redelivery counts, leader and replica details where exposed
- Final SUCCESS/FAIL/WARN/SKIP counts and a timestamped evidence directory

## Interpreting outcomes

- `SUCCESS` means a script step completed; it is not always an assertion that the entire scenario passed. For manual scenarios, the operator must validate the event IDs, ACK floor, and business effect.
- `WARN` and `SKIP` are not passes.
- A successful TCP/NATS reconnect alone does not prove data durability.
- A single node failure should be tolerated by a healthy three-replica stream while quorum remains. Two of three nodes down normally prevents replicated JetStream writes.
- Stream/consumer JSON fields vary across NATS CLI versions; inspect raw JSON files in the evidence directory if a parsed field prints `?`.
- The HAProxy stats URL must be configured to expose stats in the format expected by your HAProxy setup. The endpoint may be reachable but not provide CSV.
- Scripts do not automatically create or change streams/consumers, inject firewall faults, delete data, or configure Java worker crash points. Those actions are deliberately left explicit because they depend on your actual deployment and application.

## Important design points

- `PAYMENT_PROCESSORS` should be a single durable pull consumer shared by Java Subscribers 1 and 2 to distribute processing.
- `PAYMENT_NOTIFICATIONS` should be a separate durable push consumer for Java Subscriber 3, with its own cursor.
- Use explicit ACK after successful handling and idempotency keyed by `eventId`/`paymentId`.
- Verify `PAYMENT_EVENTS` has file storage and three replicas if persistence across node restarts is part of the acceptance target.
