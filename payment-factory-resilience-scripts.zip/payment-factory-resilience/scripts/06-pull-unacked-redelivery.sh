#!/usr/bin/env bash
# JR-06: Pull worker crash before ACK and redelivery
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-06 - Pull worker crash before ACK and redelivery"
info "MODE=manual"
section "STEP 1 - Capture baseline"; snapshot
info "ACTION REQUIRED: configure Subscriber 1 to pause after receiving one event but before ACK; then terminate it."
info "Publish one uniquely identified event and verify Subscriber 2 receives it after AckWait expires."
read -r -p "After observing the redelivery, press Enter to capture state..."
section "STEP 2 - Inspect cursor, ACK pending, redelivery"; snapshot
pass "Evidence captured; PASS requires same event ID redelivered and no lost event, with business idempotency verified"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
