#!/usr/bin/env bash
# JR-01: Baseline: stream replica count and publish
# Mode: safe. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-01 - Baseline: stream replica count and publish"
info "MODE=safe"
section "STEP 1 - Baseline health"; snapshot
section "STEP 2 - Publish a uniquely identified probe"
publish_probe "PF-JR01-$(date +%s)"
section "STEP 3 - Verify stream and replica state"; print_stream_consumer_status
pass "Baseline stream/replica inspection completed; verify configured replicas equal 3 in captured stream info"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
