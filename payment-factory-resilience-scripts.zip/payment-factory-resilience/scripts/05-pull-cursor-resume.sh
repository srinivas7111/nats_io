#!/usr/bin/env bash
# JR-05: Pull durable cursor persistence after Java client restart
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-05 - Pull durable cursor persistence after Java client restart"
info "MODE=manual"
section "STEP 1 - Capture consumer cursor baseline"; snapshot
info "ACTION REQUIRED: stop and restart Subscriber 1 Java process only; do not delete its durable consumer."
read -r -p "After restarting Subscriber 1, press Enter to continue..."
section "STEP 2 - Publish a marker event"; publish_probe "PF-JR05-$(date +%s)"
section "STEP 3 - Inspect durable cursor and pending counts"; snapshot
pass "Cursor report captured; compare ACK floor with the pre-restart report and verify the app resumes from durable state"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
