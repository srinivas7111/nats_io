#!/usr/bin/env bash
# JR-02: Stream leader failure and recovery
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-02 - Stream leader failure and recovery"
info "MODE=disruptive"
section "STEP 1 - Identify current stream leader"
nats_cli stream info "$STREAM" --json > "$REPORT_DIR/stream-before.json" || { fail "Cannot inspect stream"; finish; exit 1; }
LEADER="$(python3 - "$REPORT_DIR/stream-before.json" <<'PY'
import json,sys
d=json.load(open(sys.argv[1])); print((d.get("cluster") or {}).get("leader",""))
PY
)"
printf 'STREAM_LEADER=%s\n' "$LEADER"
[[ -n "$LEADER" && "$LEADER" != "None" ]] || { fail "Could not identify stream leader; do not guess which node to stop"; finish; exit 1; }
section "STEP 2 - Confirm disruptive action"
confirm "This stops stream leader $LEADER and may interrupt publishing briefly." || { skip "Operator cancelled"; finish; exit 0; }
section "STEP 3 - Stop leader and probe through LB"
stop_node "$LEADER"
sleep 8
publish_probe "PF-JR02-during-$(date +%s)" || warn "Publish interrupted as expected during leader election"
section "STEP 4 - Inspect leader election and stream state"; snapshot
section "STEP 5 - Restore original node"; start_node "$LEADER"; wait_node "$LEADER"; sleep 10; snapshot
pass "Failover steps completed; inspect saved before/after leader and message sequence evidence"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
