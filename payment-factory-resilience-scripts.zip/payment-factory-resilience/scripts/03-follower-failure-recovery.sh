#!/usr/bin/env bash
# JR-03: Follower failure and recovery
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-03 - Follower failure and recovery"
info "MODE=disruptive"
section "STEP 1 - Capture baseline"; snapshot
section "STEP 2 - Select a running node that is not the stream leader"
nats_cli stream info "$STREAM" --json > "$REPORT_DIR/stream-before.json" || { fail "Cannot inspect stream"; finish; exit 1; }
LEADER="$(python3 - "$REPORT_DIR/stream-before.json" <<'PY'
import json,sys
print((json.load(open(sys.argv[1])).get("cluster") or {}).get("leader",""))
PY
)"
TARGET=""
for n in "${NODES[@]}"; do [[ "$n" != "$LEADER" ]] && is_running "$n" && { TARGET="$n"; break; }; done
[[ -n "$TARGET" ]] || { fail "Could not find running follower"; finish; exit 1; }
printf 'STREAM_LEADER=%s FOLLOWER_TARGET=%s\n' "$LEADER" "$TARGET"
section "STEP 3 - Stop follower and publish probe"
confirm "This stops follower $TARGET. Continue?" || { skip "Operator cancelled"; finish; exit 0; }
stop_node "$TARGET"; sleep 5; publish_probe "PF-JR03-$(date +%s)"
section "STEP 4 - Verify stream/LB/nodes"; snapshot
section "STEP 5 - Restore follower"; start_node "$TARGET"; wait_node "$TARGET"; sleep 10; snapshot
pass "Follower outage and recovery steps completed; validate replica catch-up in reports"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
