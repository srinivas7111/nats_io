#!/usr/bin/env bash
# JR-04: Restart node and verify replica catch-up
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-04 - Restart node and verify replica catch-up"
info "MODE=disruptive"
section "STEP 1 - Baseline snapshot"; snapshot
section "STEP 2 - Select node to restart"
TARGET="${TARGET_NODE:-${NODES[2]}}"
printf 'TARGET_NODE=%s\n' "$TARGET"
confirm "This restarts $TARGET; choose a non-leader if you do not intend a leader test." || { skip "Operator cancelled"; finish; exit 0; }
section "STEP 3 - Stop node"; stop_node "$TARGET"; sleep 5
section "STEP 4 - Publish while node is absent"; publish_probe "PF-JR04-$(date +%s)" || warn "Publish may be temporarily unavailable"
section "STEP 5 - Restart and inspect catch-up"; start_node "$TARGET"; wait_node "$TARGET"; sleep 15; snapshot
pass "Rejoin check completed; compare replica state and last sequence before/after"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
