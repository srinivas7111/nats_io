#!/usr/bin/env bash
# JR-12: Quorum restoration after node recovery
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-12 - Quorum restoration after node recovery"
info "MODE=manual"
section "STEP 1 - Current cluster snapshot"; snapshot
info "If a previous quorum test left nodes stopped, restore them before proceeding."
for n in "${NODES[@]}"; do if ! is_running "$n"; then warn "$n is stopped"; fi; done
read -r -p "Restore all expected nodes manually if needed, then press Enter..."
for n in "${NODES[@]}"; do wait_node "$n" || true; done
section "STEP 2 - Test JetStream publish after quorum returns"; publish_probe "PF-JR12-$(date +%s)"
section "STEP 3 - Verify stream and consumer replicas"; snapshot
pass "Recovery evidence captured; PASS requires healthy cluster, successful JetStream publish, and expected replica count"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
