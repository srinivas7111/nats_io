#!/usr/bin/env bash
# JR-15: Duplicate delivery and idempotent business processing
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-15 - Duplicate delivery and idempotent business processing"
info "MODE=manual"
section "STEP 1 - Baseline"; snapshot
info "ACTION REQUIRED: configure processor to commit business effect, then crash before ACK."
info "Redelivery is expected; the application must deduplicate by eventId/paymentId."
read -r -p "After observing the same event ID on redelivery, press Enter..."
section "STEP 2 - Capture cursor and redelivery counters"; snapshot
pass "Evidence captured; PASS requires redelivery may occur but business side effect occurs once"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
