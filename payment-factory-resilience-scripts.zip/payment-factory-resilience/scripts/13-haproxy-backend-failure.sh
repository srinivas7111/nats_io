#!/usr/bin/env bash
# JR-13: HAProxy backend failure
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-13 - HAProxy backend failure"
info "MODE=disruptive"
section "STEP 1 - Baseline LB and cluster"; snapshot
TARGET="${TARGET_NODE:-${NODES[2]}}"
confirm "Stop backend $TARGET while Java/NATS clients use HAProxy." || { skip "Operator cancelled"; finish; exit 0; }
section "STEP 2 - Stop backend and probe via LB"; stop_node "$TARGET"; sleep 5; print_lb_status; publish_probe "PF-JR13-$(date +%s)" || warn "Client may need reconnect/retry"; snapshot
section "STEP 3 - Restore backend"; start_node "$TARGET"; wait_node "$TARGET"; sleep 10; snapshot
pass "Backend failover steps completed; verify HAProxy marks failed backend down and traffic uses healthy nodes"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
