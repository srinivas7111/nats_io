#!/usr/bin/env bash
# JR-14: HAProxy process/container failure
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-14 - HAProxy process/container failure"
info "MODE=disruptive"
section "STEP 1 - Baseline"; snapshot
confirm "Stop HAProxy container $LB_CONTAINER. Client endpoint will be unavailable until it returns." || { skip "Operator cancelled"; finish; exit 0; }
section "STEP 2 - Stop HAProxy"; cmd podman stop "$LB_CONTAINER"; podman stop "$LB_CONTAINER"; sleep 3
print_lb_status
if nats_cli pub "$SUBJECT" "PF-JR14-expected-failure-$(date +%s)" >/dev/null 2>&1; then warn "LB endpoint unexpectedly still reachable (check alternate path/DNS)"; else pass "NATS client path through HAProxy failed while proxy is stopped"; fi
section "STEP 3 - Restore HAProxy"; cmd podman start "$LB_CONTAINER"; podman start "$LB_CONTAINER"; sleep 5; print_lb_status; snapshot
pass "Proxy recovery steps completed; verify client reconnect and publish after recovery"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
