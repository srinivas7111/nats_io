#!/usr/bin/env bash
# JR-09: Push subscriber disconnect/reconnect
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-09 - Push subscriber disconnect/reconnect"
info "MODE=manual"
section "STEP 1 - Baseline"; snapshot
info "ACTION REQUIRED: stop only the Java notification process, publish events, then restart it."
read -r -p "Press Enter after restart and after the notification process has drained pending events..."
section "STEP 2 - Verify notification durable consumer"; snapshot
pass "Reconnect evidence captured; validate expected event IDs and no unexplained gaps"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
