#!/usr/bin/env bash
# JR-11: Two-node outage and expected quorum loss
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-11 - Two-node outage and expected quorum loss"
info "MODE=disruptive"
section "STEP 1 - Baseline snapshot"; snapshot
section "STEP 2 - Confirm two-node outage"
info "This is intentionally disruptive. Do not run against shared or production environments."
confirm "Stop TWO NATS nodes. JetStream writes should fail without quorum." || { skip "Operator cancelled"; finish; exit 0; }
read -r -p "Enter first node to stop: " N1
read -r -p "Enter second node to stop: " N2
[[ "$N1" != "$N2" && " ${NODES[*]} " == *" $N1 "* && " ${NODES[*]} " == *" $N2 "* ]] || { fail "Invalid node selection"; finish; exit 1; }
stop_node "$N1"; stop_node "$N2"; sleep 5
section "STEP 3 - Observe node/LB/JetStream status"; snapshot
if publish_probe "PF-JR11-quorum-check-$(date +%s)"; then warn "Publish succeeded; verify whether JetStream accepted it and inspect quorum/configuration"; else pass "Publish failed while two of three nodes are down, consistent with loss of quorum"; fi
section "STEP 4 - Restore both nodes"; start_node "$N1"; start_node "$N2"; wait_node "$N1"; wait_node "$N2"; sleep 20; snapshot
pass "Quorum restoration steps completed; verify leaders and replicas returned healthy"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
