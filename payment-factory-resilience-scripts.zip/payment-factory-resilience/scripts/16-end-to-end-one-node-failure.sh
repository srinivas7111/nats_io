#!/usr/bin/env bash
# JR-16: End-to-end publish/process/notification during one-node failure
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-16 - End-to-end publish/process/notification during one-node failure"
info "MODE=disruptive"
section "STEP 1 - Baseline snapshot"; snapshot
info "Start both Java publishers, both pull processors, and the push notification client."
info "Record event IDs and business outcomes before disruption."
TARGET="${TARGET_NODE:-${NODES[2]}}"
confirm "Stop one NATS node ($TARGET) while all Java clients are active." || { skip "Operator cancelled"; finish; exit 0; }
section "STEP 2 - Stop node, keep workload running"; stop_node "$TARGET"; sleep 8; publish_probe "PF-JR16-during-$(date +%s)" || warn "Publish failed during transition; retry behavior must be checked"; snapshot
read -r -p "Wait for all Java clients to reconnect and drain, then press Enter..."
section "STEP 3 - Restore node and capture final evidence"; start_node "$TARGET"; wait_node "$TARGET"; sleep 15; snapshot
pass "End-to-end evidence captured; PASS requires reconcile all published IDs against processor and notification outcomes"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
