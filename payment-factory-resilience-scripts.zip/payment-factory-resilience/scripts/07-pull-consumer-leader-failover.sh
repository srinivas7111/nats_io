#!/usr/bin/env bash
# JR-07: Pull durable consumer leader failover
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-07 - Pull durable consumer leader failover"
info "MODE=disruptive"
section "STEP 1 - Capture consumer cluster state"; snapshot
info "Use the consumer info JSON to identify PAYMENT_PROCESSORS cluster leader and replicas."
info "This scenario must stop the actual consumer leader, not an arbitrary NATS node."
TARGET="${TARGET_NODE:-}"
if [[ -z "$TARGET" ]]; then
  read -r -p "Enter the confirmed PAYMENT_PROCESSORS consumer leader container name: " TARGET
fi
[[ " ${NODES[*]} " == *" $TARGET "* ]] || { fail "Target is not in NODES_CSV"; finish; exit 1; }
confirm "Stop consumer leader $TARGET, then test pull processing." || { skip "Operator cancelled"; finish; exit 0; }
stop_node "$TARGET"; sleep 8; snapshot
publish_probe "PF-JR07-$(date +%s)" || warn "Publish interruption may occur during election"
section "STEP 2 - Restore node"; start_node "$TARGET"; wait_node "$TARGET"; sleep 10; snapshot
pass "Consumer leader failover steps completed; confirm durable cursor and pending counts recover"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
