#!/usr/bin/env bash
# JR-10: Push durable consumer leader failover
# Mode: disruptive. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-10 - Push durable consumer leader failover"
info "MODE=disruptive"
section "STEP 1 - Inspect consumer state"; snapshot
TARGET="${TARGET_NODE:-}"
if [[ -z "$TARGET" ]]; then read -r -p "Enter the confirmed PAYMENT_NOTIFICATIONS consumer leader node: " TARGET; fi
[[ " ${NODES[*]} " == *" $TARGET "* ]] || { fail "Target is not in NODES_CSV"; finish; exit 1; }
confirm "Stop consumer leader $TARGET; notification delivery may pause." || { skip "Operator cancelled"; finish; exit 0; }
section "STEP 2 - Stop leader, publish probe, inspect"; stop_node "$TARGET"; sleep 8; publish_probe "PF-JR10-$(date +%s)" || warn "Publish interrupted"; snapshot
section "STEP 3 - Restore node"; start_node "$TARGET"; wait_node "$TARGET"; sleep 10; snapshot
pass "Push consumer leader failover steps completed; verify notification catch-up and cursor continuity"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
