#!/usr/bin/env bash
# JR-08: Push durable cursor while notification client is offline
# Mode: manual. Read each STEP and review the confirmation prompt before disruption.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib.sh"
preflight || { finish; exit 1; }
section "SCENARIO JR-08 - Push durable cursor while notification client is offline"
info "MODE=manual"
section "STEP 1 - Baseline notification cursor"; snapshot
info "ACTION REQUIRED: stop Subscriber 3 process only; keep NATS and JetStream running."
read -r -p "After Subscriber 3 is stopped, press Enter to publish offline events..."
section "STEP 2 - Publish three uniquely identified notification events"
for i in 1 2 3; do publish_probe "PF-JR08-$i-$(date +%s)" || warn "Publish $i failed"; done
read -r -p "Restart Subscriber 3 and wait for it to process pending events, then press Enter..."
section "STEP 3 - Inspect notification cursor and pending counts"; snapshot
pass "Evidence captured; PASS requires offline events delivered after restart and notification ACK floor to advance"
section "FINAL HEALTH SNAPSHOT"; snapshot
finish
