# NATS Local Production-Like Environment (Podman Compose)

A local single-host simulation with three NATS servers, JetStream, HAProxy TCP load balancing, a stable client DNS name, TLS on client connections, and mutually authenticated TLS on cluster routes.

> **Scope and safety:** `scripts/setup.sh` and `scripts/cleanup.sh` only remove resources belonging to this Compose project and the three image tags used by it. They do not run `podman system prune` and do not delete unrelated Podman containers, images, volumes, or networks. Cleanup deletes this project's JetStream volumes and therefore destroys its local stream data.
>
> `podman pull --tls-verify=false` disables TLS certificate verification for registry downloads only. It does not configure NATS client TLS. Use it only if required by your local registry/proxy environment; normal verified pulls are safer.

## Components

- NATS Server: `docker.io/library/nats:2.15.1-alpine`
- HAProxy: `docker.io/library/haproxy:3.2-alpine`
- NATS CLI toolbox: `docker.io/natsio/nats-box:latest`
- Client endpoint: `nats.local.test:4222`
- HAProxy stats: `http://localhost:8404/stats`
- Cluster routes: port `6222` on the private Compose network
- JetStream volumes: separate volume for each NATS node

## Prerequisites

- Podman
- A working `podman compose` provider
- OpenSSL
- A shell compatible with POSIX `sh` (Linux/macOS, WSL, or Git Bash)

## Quick start

From the extracted `nats-local-prod` directory:

```sh
chmod +x scripts/*.sh
./scripts/setup.sh
```

The script clears the terminal, asks whether to remove this project's previous containers/network/volumes/images, pulls the required images using `--tls-verify=false`, generates local development certificates if they do not already exist, validates Compose, and starts the stack.

**Important:** answer `y` to cleanup only if you want to delete this project's JetStream data and recreate the environment from scratch. Answer `n` to retain existing resources; however, old containers or data can affect a clean reinstall.

## Manual steps

### Pull images first

```sh
podman pull --tls-verify=false docker.io/library/nats:2.15.1-alpine
podman pull --tls-verify=false docker.io/library/haproxy:3.2-alpine
podman pull --tls-verify=false docker.io/natsio/nats-box:latest
podman images
```

`--tls-verify=false` is for registry TLS verification only. Avoid it when the registry certificate chain can be verified normally.

### Generate local TLS certificates

```sh
./scripts/generate-certs.sh
```

The script creates a local test CA and a server certificate with SANs for `nats.local.test`, `nats-1`, `nats-2`, `nats-3`, and `nats-lb`. The generated `certs/ca-key.pem` is private and must never be mounted into containers or committed to source control.

### Configure host DNS

Add this line to the machine's hosts file:

```text
127.0.0.1 nats.local.test
```

- Windows: `C:\Windows\System32\drivers\etc\hosts`
- Linux/macOS: `/etc/hosts`

Inside the Compose network, the `nats.local.test` alias resolves to HAProxy.

### Start and inspect

```sh
podman compose config
podman compose up -d
podman ps
podman logs nats-1
podman logs nats-2
podman logs nats-3
podman logs nats-lb
```

### Validate TLS

```sh
openssl s_client -connect 127.0.0.1:4222 \
  -servername nats.local.test -CAfile certs/ca.pem
```

Configure the client SDK to trust `certs/ca.pem` and connect to `nats://nats.local.test:4222` with TLS enabled. Client certificates are not required on the client-facing listener in this configuration.

### NATS CLI toolbox

```sh
podman compose --profile tools run --rm nats-box
```

The toolbox has the CA mounted at `/certs`. Check the installed CLI's supported TLS flags with `nats --help`, then test a connection, publish, and subscribe using `nats.local.test:4222`.

### Test a node failure

```sh
podman stop nats-2
# Test client reconnect and stream behavior.
podman start nats-2
```

For meaningful JetStream replication tests, create streams with `num_replicas: 3`. A three-node cluster does not automatically replicate every stream.

## Cleanup

Interactive project-scoped cleanup:

```sh
./scripts/cleanup.sh
```

It removes this Compose project's containers, network, JetStream volumes, and the three image tags used by this project. **It destroys this project's local JetStream data.** Other Podman resources are not touched.

To stop containers while preserving data:

```sh
podman compose down
```

## Production-parity limitations

- This is a single-host simulation, not a production deployment. It does not reproduce multi-zone failure isolation, Kubernetes Services/StatefulSets, cloud load balancers, or production certificate lifecycle management.
- HAProxy uses TLS passthrough. NATS terminates TLS.
- The shared test certificate is for local use only. Production should use node-specific certificates and managed keys from an approved CA.
- HAProxy TCP checks verify port reachability, not NATS protocol readiness or JetStream leadership.
- Validate `client_advertise` behavior with the exact SDK used by your applications. A shared LB endpoint can be convenient, but a list of reachable NATS endpoints may provide more resilient discovery for some clients.
