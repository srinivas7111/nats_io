#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p certs

# Local development CA. Keep ca-key.pem private and never mount it into containers.
openssl req -x509 -newkey rsa:3072 -sha256 -nodes \
  -keyout certs/ca-key.pem -out certs/ca.pem -days 365 \
  -subj "/CN=NATS Local Development CA"

openssl req -new -newkey rsa:3072 -sha256 -nodes \
  -keyout certs/server-key.pem -out certs/server.csr \
  -subj "/CN=nats.local.test"

openssl x509 -req -sha256 -in certs/server.csr \
  -CA certs/ca.pem -CAkey certs/ca-key.pem -CAcreateserial \
  -out certs/server.pem -days 90 \
  -extfile cert-generation/server-ext.cnf

chmod 600 certs/ca-key.pem certs/server-key.pem
rm -f certs/server.csr
printf '\nGenerated certs/ca.pem, certs/server.pem, certs/server-key.pem\n'
printf 'Keep certs/ca-key.pem private; do not mount it into containers.\n'
