#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."

printf '%s\n' 'NATS local environment cleanup'
printf '%s\n' 'This cleanup is scoped to this Compose project only.'
printf '%s\n' 'It removes this project containers, network, images, and JetStream volumes (all local stream data will be lost).'
printf '%s' 'Continue? [y/N] '
read answer
case "$answer" in
  y|Y|yes|YES)
    ;;
  *)
    printf '%s\n' 'Cleanup cancelled.'
    exit 0
    ;;
esac

if podman compose version >/dev/null 2>&1; then
  podman compose down --volumes --remove-orphans || true
else
  printf '%s\n' 'Compose provider not available; removing known project containers individually.'
  for name in nats-lb nats-1 nats-2 nats-3; do
    podman rm -f "$name" >/dev/null 2>&1 || true
  done
  podman volume rm nats-local-prod_nats1-data nats-local-prod_nats2-data nats-local-prod_nats3-data >/dev/null 2>&1 || true
  podman network rm nats-net >/dev/null 2>&1 || true
fi

# Remove only the images used by this project. Other Podman images are untouched.
for image in \
  docker.io/library/nats:2.15.1-alpine \
  docker.io/library/haproxy:3.2-alpine \
  docker.io/natsio/nats-box:latest
do
  podman image rm "$image" >/dev/null 2>&1 || true
done

printf '%s\n' 'Project cleanup complete. Other Podman containers, images, volumes, and networks were not touched.'
