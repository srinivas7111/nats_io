#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."

# Clear the terminal first, if supported.
if [ -t 1 ]; then
  clear 2>/dev/null || printf '\033[2J\033[H'
fi

printf '%s\n' '=================================================='
printf '%s\n' ' NATS local production-like environment setup'
printf '%s\n' '=================================================='
printf '%s\n' 'Step 1/5: Clean up this project before reinstalling.'
printf '%s\n' 'WARNING: this removes this project JetStream volumes and data.'
printf '%s' 'Run project-scoped cleanup now? [y/N] '
read answer
case "$answer" in
  y|Y|yes|YES)
    # Cleanup script asks for its own confirmation; pass an affirmative response.
    printf 'y\n' | ./scripts/cleanup.sh
    ;;
  *)
    printf '%s\n' 'Cleanup skipped. Existing containers/volumes may affect setup.'
    ;;
esac

printf '\n%s\n' 'Step 2/5: Pull all required images from the registry.'
printf '%s\n' 'NOTE: --tls-verify=false disables registry certificate verification for these pulls only.'
podman pull --tls-verify=false docker.io/library/nats:2.15.1-alpine
podman pull --tls-verify=false docker.io/library/haproxy:3.2-alpine
podman pull --tls-verify=false docker.io/natsio/nats-box:latest

printf '\n%s\n' 'Step 3/5: Generate local development TLS certificates.'
if [ -f certs/ca.pem ] || [ -f certs/server.pem ] || [ -f certs/server-key.pem ]; then
  printf '%s\n' 'Existing certificate files detected; not overwriting them.'
  printf '%s\n' 'Delete the files in certs/ manually if you want to regenerate the local CA and certificates.'
else
  ./scripts/generate-certs.sh
fi

printf '\n%s\n' 'Step 4/5: Validate Compose configuration.'
podman compose config

printf '\n%s\n' 'Step 5/5: Start the stack.'
podman compose up -d

printf '\n%s\n' 'Setup command completed. Check the containers and logs:'
printf '%s\n' '  podman ps'
printf '%s\n' '  podman logs nats-1'
printf '%s\n' '  podman logs nats-2'
printf '%s\n' '  podman logs nats-3'
printf '%s\n' '  podman logs nats-lb'
printf '%s\n' 'HAProxy stats: http://localhost:8404/stats'
printf '%s\n' 'Client endpoint: nats.local.test:4222 (add 127.0.0.1 nats.local.test to hosts file)'
