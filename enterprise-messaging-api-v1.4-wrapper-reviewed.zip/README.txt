Enterprise Messaging Platform API v1.4 — reviewed for wrapper generation

Use Applications/openapi.yaml for application client generation and Admin/openapi.yaml for privileged administration. The unified YAML/JSON are included as well.

Swagger groups:
Applications: Publish, Consume, Subscriptions, Streams, Key Value, Object Store, Operations, Health.
Admin: Streams, Consumers, Tenants, Identities, Authorization, Platform, Audit, Observability, Backup & Recovery, Maintenance, Operations.

Review updates:
- Replaced RFC 9457 about:blank examples with named illustrative problem-type URIs.
- Added concrete examples to scalar schema fields that lacked examples, and request examples for common create/publish/pull/backup/restore/maintenance operations.
- Kept descriptions concise and focused on wrapper behavior.
- Added separate Application and Admin Swagger groupings.

Important: example identity/secret/token values are illustrative only. Configure the OAuth token URL for the target environment. This is a contract review, not proof that every endpoint is implemented by the service; validate operations against the actual facade before code generation.
